import React from 'react';
import {Composition} from 'remotion';
import {Animacao, DURACAO} from './Animacao';

export const RemotionRoot: React.FC = () => (
  <Composition id="Animacao" component={Animacao} durationInFrames={DURACAO} fps={30} width={1080} height={1920} />
);
