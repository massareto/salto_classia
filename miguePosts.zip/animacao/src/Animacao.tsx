import React from 'react';
import {AbsoluteFill, Sequence, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import dados from './dados.json';
import {Ilustracao} from './Ilustracao';
import {FM, Legenda} from './texto';

type Plano = {inicio: number; visual: string};
type Cena = {from: number; to: number; planos: Plano[]; chamada_final?: string};
type Texto = {from: number; to: number; texto: string; hl?: string};

const D = dados as {total: number; cenas: Cena[]; legendas: Texto[]; acento?: string; cores?: Record<string, string>};
export const DURACAO = D.total;

const Chamada: React.FC<{texto: string}> = ({texto}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const entrada = spring({frame, fps, config: {damping: 21}});
  return (
    <div style={{
      position: 'absolute', bottom: 100, left: 84, right: 84, padding: '20px 28px',
      textAlign: 'center', borderRadius: 28, background: D.acento ?? '#DDBB77', color: '#141d18',
      fontFamily: FM, fontSize: 54, fontWeight: 800, transform: `translateY(${(1 - entrada) * 28}px)`,
    }}>{texto}</div>
  );
};

export const Animacao: React.FC = () => (
  <AbsoluteFill style={{background: D.cores?.fundo ?? '#111114'}}>
    {D.cenas.map((cena, i) => (
      <Sequence key={cena.from} from={cena.from} durationInFrames={cena.to - cena.from} name={`Motion ${i + 1}`}>
        {cena.planos.map((plano, j) => {
          const fim = cena.planos[j + 1]?.inicio ?? cena.to - cena.from;
          return (
            <Sequence key={plano.inicio} from={plano.inicio} durationInFrames={fim - plano.inicio} name={plano.visual}>
              <Ilustracao c={{...plano, from: plano.inicio, to: fim}} dados={D} />
            </Sequence>
          );
        })}
        {cena.chamada_final && (
          <Sequence from={Math.max(0, cena.to - cena.from - 45)}>
            <Chamada texto={cena.chamada_final} />
          </Sequence>
        )}
      </Sequence>
    ))}
    {D.legendas.map((l, i) => (
      <Sequence key={i} from={l.from} durationInFrames={Math.max(1, l.to - l.from)} name={`Legenda ${i + 1}`}>
        <Legenda text={l.texto.replace(/-/g, '\u2011')} hl={(l.hl ?? '').replace(/-/g, '\u2011')} top={1360} dur={l.to - l.from} />
      </Sequence>
    ))}
  </AbsoluteFill>
);
