import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame} from 'remotion';
import {FP} from './texto';
type Any = Record<string, any>;
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// Biblioteca editorial temática. Desenhos genéricos, sem personagens ou marcas reais.
export const Ilustracao: React.FC<{c: Any; dados: Any}> = ({c, dados}) => {
  const f = useCurrentFrame();
  const dur = c.to - c.from;
  const ac = dados.acento || '#DDBB77';
  const paper = dados.cores?.texto || '#F5F4EF';
  const bg = dados.cores?.fundo || '#111114';
  const p = spring({frame: f, fps: 30, config: {damping: 23, stiffness: 95}});
  const giro = interpolate(f, [0, Math.max(1,dur)], [-18, 14], clamp);
  const rise = 24 * (1-p);
  const line = interpolate(f, [0, Math.max(1, Math.min(dur - 1, 42))], [0, 1], clamp);
  const pulse = 1+Math.sin(f/24)*.025;
  const paths = ['M460 660 C460 520 250 470 190 210','M460 660 C460 460 460 390 460 160','M460 660 C460 510 700 440 740 210'];
  const ink = '#24232A';
  const brush: React.CSSProperties = {stroke: ac, strokeWidth: 7, strokeLinecap:'round',strokeLinejoin:'round',fill:'none'};
  const visual = c.visual;
  return (
    <AbsoluteFill style={{background:bg,color:paper,fontFamily:FP,overflow:'hidden'}}>
      <AbsoluteFill style={{background:`radial-gradient(ellipse at 50% 45%, ${ac}17 0%, transparent 60%)`}} />
      <svg width="1080" height="1920" style={{position:'absolute',opacity:.2}}>
        <defs><pattern id="dots" width="48" height="48" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="1" fill={ac}/></pattern></defs>
        <rect width="1080" height="1920" fill="url(#dots)" />
        <path d="M80 110 H1000 M80 1640 H1000" stroke={ac} strokeWidth="1"/>
      </svg>
      <div style={{position:'absolute',left:84,right:84,top:145,fontSize:26,letterSpacing:'.16em',textTransform:'uppercase',color:ac}}>{c.rotulo?.texto || c.rotulo || dados.nome || ''}</div>
      <div style={{position:'absolute',left:84,right:84,top:220,fontSize:c.tamanhoTitulo || 68,transform:`translateY(${10 * (1 - p)}px)`,fontWeight:800,lineHeight:1.13,letterSpacing:'-.035em',whiteSpace:'pre-line'}}>{c.titulo}</div>
      {c.subtitulo ? <div style={{position:'absolute',left:86,right:86,top:405,fontSize:31,lineHeight:1.3,color:paper,opacity:.7}}>{c.subtitulo}</div> : null}
      <svg width="920" height="780" viewBox="0 0 920 780" style={{position:'absolute',left:80,top:500,transform:`translateY(${rise}px)`,overflow:'visible'}}>
        <defs>
          <linearGradient id="gold" x1="0" y1="0" x2="1" y2="1"><stop stopColor={paper}/><stop offset="1" stopColor={ac}/></linearGradient>
          <linearGradient id="slate" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#39363D"/><stop offset="1" stopColor="#1B1A20"/></linearGradient>
        </defs>
        {visual==='indicador' && <g>
          <path d="M96 130 H824 M96 635 H824" stroke={ac} strokeWidth="2" opacity=".5"/>
          <text x="460" y="228" textAnchor="middle" fill={paper} fontSize="38">{c.medida}</text>
          <text x="460" y="477" textAnchor="middle" fill={ac} fontSize="180" fontWeight="800" style={{transformOrigin:'460px 420px',transform:`scale(${.95+p*.05})`}}>{c.numero}</text>
          <text x="460" y="570" textAnchor="middle" fill={paper} opacity=".78" fontSize="31">{c.periodo}</text>
        </g>}
        {visual==='relacao' && <g>
          <path d="M145 350 H775" fill="none" stroke={ac} strokeWidth="3" strokeOpacity=".4" strokeDasharray="5 12"/>
          <circle cx={275+370*line} cy="350" r="9" fill={ac}/>
          {[{x:246, title:c.origem, detail:c.origem_dado, glyph:c.origem_glyph},{x:674, title:c.destino, detail:c.destino_dado, glyph:c.destino_glyph}].map(({x,title,detail,glyph})=><g key={title}>
            <circle cx={x} cy="350" r="127" fill={dados.cores?.cartao || bg} stroke={ac} strokeWidth="3"/>
            <circle cx={x} cy="350" r="109" fill="none" stroke={ac} strokeOpacity=".32"/>
            <text x={x} y="380" textAnchor="middle" fill={paper} fontSize="86" fontWeight="600">{glyph}</text>
            <text x={x} y="546" textAnchor="middle" fill={paper} fontSize="47" fontWeight="700">{title}</text>
            <text x={x} y="600" textAnchor="middle" fill={ac} fontSize="31">{detail}</text>
          </g>)}
        </g>}
        {visual === 'barras' && (() => {
          const barras = c.barras as {rotulo: string; valor: number; exibicao?: string}[];
          const maximo = Math.max(1, ...barras.map(({valor}) => valor));
          const largura = 760 / barras.length;
          return <g>
            <path d="M80 600 H840" stroke={paper} strokeOpacity=".5" strokeWidth="3" />
            {barras.map(({rotulo, valor, exibicao}, i) => {
              const x = 80 + largura * (i + .5);
              const escala = interpolate(f, [i * 4, i * 4 + 23], [0, 1], clamp);
              const altura = 360 * valor / maximo * escala;
              return <g key={i}>
                <rect x={x - largura * .29} y={600 - altura} width={largura * .58} height={altura} rx="12" fill={i === barras.length - 1 ? ac : paper} />
                <text x={x} y={575 - altura} textAnchor="middle" fill={paper} fontWeight="800" fontSize="47" opacity={escala}>{exibicao ?? valor}</text>
                <text x={x} y="655" textAnchor="middle" fill={paper} fontSize="29">{rotulo}</text>
              </g>;
            })}
          </g>;
        })()}
        {visual === 'processo' && (() => {
          const itens = c.itens as string[];
          return <g>
            <path d={`M185 140 V${140 + 150 * (itens.length - 1)}`} style={brush}
              pathLength="1" strokeDasharray="1" strokeDashoffset={1 - line} />
            {itens.map((texto, i) => {
              const entrada = interpolate(f, [i * 8, i * 8 + 15], [0, 1], clamp);
              return <g key={i} opacity={entrada} transform={`translate(${-24 * (1 - entrada)} ${140 + 150 * i})`}>
                <circle cx="185" r="36" fill={ac} />
                <text x="185" y="12" textAnchor="middle" fill={bg} fontSize="34" fontWeight="800">{i + 1}</text>
                <text x="252" y="12" fill={paper} fontSize="41" fontWeight="800">{texto}</text>
              </g>;
            })}
          </g>;
        })()}
        {visual==='universidade' && <g>
          <circle cx="460" cy="345" r="280" fill="none" stroke={ac} strokeOpacity=".14" strokeWidth="1"/>
          <circle cx="460" cy="345" r="310" fill="none" stroke={ac} strokeOpacity=".14" strokeDasharray="2 18" strokeWidth="3" transform={`rotate(${f/5} 460 345)`}/>
          <g transform={`translate(0 ${20*(1-p)})`}>
            <path d="M125 305 L460 125 L795 305 Z" fill="url(#slate)" stroke={ac} strokeWidth="8"/>
            <path d="M185 285 L460 178 L735 285" {...{style:brush}} strokeOpacity=".45"/>
            <circle cx="460" cy="247" r="22" fill={ac}/>
            <rect x="150" y="310" width="620" height="42" rx="7" fill={ac}/>
            {[205,325,445,565,685].map((x,i)=><g key={x} style={{opacity:interpolate(f,[5+i*5,25+i*5],[.15,1],clamp)}}>
              <rect x={x-20} y="363" width="40" height="226" rx="6" fill="url(#gold)"/>
              <path d={`M${x-35} 365 H${x+35} M${x-35} 590 H${x+35}`} stroke={ac} strokeWidth="14"/>
              <path d={`M${x-4} 380 V572`} stroke={ink} strokeOpacity=".3" strokeWidth="4"/>
            </g>)}
            {[0,1,2].map(i=><rect key={i} x={145-i*22} y={605+i*30} width={630+i*44} height="24" rx="4" fill={i===0?ac:'#45404A'}/>)}
          </g>
          <path d="M100 720 H820" stroke={ac} strokeOpacity=".3" strokeWidth="2"/>
        </g>}
        {(visual==='bussola'||visual==='constelacao') && <g>
          {[275,235,180].map((r,i)=><circle key={r} cx="460" cy="360" r={r} fill={i===1?'url(#slate)':'none'} stroke={ac} strokeWidth={i===1?5:1} strokeOpacity={i===0?.25:.7}/>)}
          {Array.from({length:48},(_,i)=>{const a=i*Math.PI/24;return <line key={i} x1={460+Math.cos(a)*217} y1={360+Math.sin(a)*217} x2={460+Math.cos(a)*(i%4?207:195)} y2={360+Math.sin(a)*(i%4?207:195)} stroke={paper} strokeOpacity={i%4?.25:.7} strokeWidth={i%4?2:4}/>;})}
          <g transform={`rotate(${giro} 460 360)`}>
            <path d="M460 165 L515 360 L460 555 L405 360 Z" fill={ac} stroke={paper} strokeWidth="3"/>
            <path d="M460 165 L460 555 L405 360 Z" fill={ink}/>
            <circle cx="460" cy="360" r="19" fill={paper}/>
          </g>
          <path d="M150 590 C300 680 620 680 775 550" {...{style:brush}} strokeOpacity=".25" strokeDasharray="5 15"/>
          {[[c.rotulos?.[0] || 'sentido',460,60],[c.rotulos?.[1] || 'escolhas',790,368],[c.rotulos?.[2] || 'valores',460,680]].map(([t,x,y])=><text key={String(t)} x={Number(x)} y={Number(y)} fill={paper} fontSize="27" textAnchor="middle" opacity=".75">{t}</text>)}
          {visual==='constelacao' && [[160,160],[760,145],[170,570],[735,600]].map(([x,y],i)=><g key={i} transform={`translate(${x} ${y}) scale(${pulse})`}><path d="M0 -16 L4 -4 L16 0 L4 4 L0 16 L-4 4 L-16 0 L-4 -4Z" fill={ac}/></g>)}
        </g>}
        {(visual==='caminhos'||visual==='pergunta') && <g>
          <circle cx="460" cy="660" r="45" fill={ac} fillOpacity=".1"/>
          {paths.map((d,i)=><g key={d}><path d={d} {...{style:brush}} strokeOpacity=".18" strokeWidth="17"/><path d={d} {...{style:brush}} pathLength="1" strokeDasharray="1" strokeDashoffset={1-line} stroke={i===1?paper:ac}/></g>)}
          {[[190,210],[460,160],[740,210]].map(([x,y],i)=><g key={i} transform={`translate(${x} ${y}) scale(${.9+.1*p})`}>
            <circle r="61" fill="url(#slate)" stroke={i===1?paper:ac} strokeWidth="3"/>
            <text y="15" textAnchor="middle" fill={paper} fontSize="46">{visual==='pergunta'?'?':String(i+1)}</text>
          </g>)}
          <circle cx="460" cy={660-150*line} r="14" fill={paper}/>
          <text x="460" y="740" textAnchor="middle" fill={paper} opacity=".6" fontSize="28">{c.rodapeVisual || 'A escolha continua com você'}</text>
        </g>}
        {(visual==='caderno'||visual==='valores') && <g transform={`rotate(-4 460 370)`}>
          <rect x="188" y="85" width="564" height="610" rx="23" fill="#09090D" transform="translate(18 18)" opacity=".6"/>
          <rect x="170" y="70" width="564" height="610" rx="23" fill={ac}/>
          <path d="M212 70 H714 Q735 70 735 96 V655 Q735 680 710 680 H212Z" fill={paper}/>
          <path d="M240 96 V651" stroke={ac} strokeWidth="3"/>
          {[0,1,2,3,4,5].map(i=><path key={i} d={`M280 ${180+i*75} H665`} stroke="#AAA3A0" strokeWidth="2" strokeOpacity=".4"/>)}
          {(c.itens || ['O que importa','O que preservar','Um próximo passo']).map((v,i)=><g key={v} style={{opacity:interpolate(f,[8+i*22,23+i*22],[0,1],clamp)}}>
            <rect x="280" y={145+i*150} width="25" height="25" rx="4" fill="none" stroke="#39323A" strokeWidth="3"/>
            <path d={`M285 ${157+i*150} l6 6 l12 -17`} fill="none" stroke="#9A713D" strokeWidth="4"/>
            <text x="326" y={167+i*150} fill="#28232A" fontSize="27">{v}</text>
          </g>)}
          <g transform={`translate(${700+Math.sin(f/20)*10} ${480+Math.cos(f/24)*8}) rotate(33)`}><rect x="0" y="-135" width="25" height="235" rx="7" fill="#29242C"/><rect x="4" y="-95" width="4" height="150" fill={ac}/><path d="M0 100 L25 100 L13 133Z" fill={ac}/></g>
          {[0,1,2,3,4,5].map(i=><rect key={i} x="151" y={125+i*90} width="57" height="11" rx="5" fill="#48404A"/>)}
        </g>}
        {visual==='convite' && <g>
          <circle cx="460" cy="340" r={240*p} stroke={ac} strokeOpacity=".2" strokeWidth="2" fill="none"/>
          <path d="M210 145 H710 Q755 145 755 190 V452 Q755 497 710 497 H420 L290 595 V497 H210 Q165 497 165 452 V190 Q165 145 210 145Z" fill="url(#slate)" stroke={ac} strokeWidth="6"/>
          {c.chamada ? (
            <foreignObject x="183" y="175" width="554" height="296">
              <div style={{height:'100%',display:'grid',placeItems:'center',padding:'30px',
                textAlign:'center',color:ac,fontSize:49,lineHeight:1.15,fontWeight:800}}>
                {c.chamada}
              </div>
            </foreignObject>
          ) : <>
            <text x="460" y="270" textAnchor="middle" fill={paper} fontSize="33" letterSpacing="6">COMENTA</text>
            <text x="460" y="390" textAnchor="middle" fill={ac} fontSize="100" fontWeight="800">{c.palavra}</text>
          </>}
          <g transform={`translate(740 145) scale(${pulse})`}><circle r="48" fill={ac}/><path d="M-18 0 l12 12 l25 -28" stroke={bg} strokeWidth="9" strokeLinecap="round" strokeLinejoin="round" fill="none"/></g>
          <text x="460" y="700" textAnchor="middle" fill={paper} opacity=".65" fontSize="29">{c.informacao || ''}</text>
        </g>}
      </svg>
      <div style={{position:'absolute',left:85,right:85,top:1685,display:'flex',justifyContent:'space-between',alignItems:'center',fontSize:25,color:paper,opacity:.6}}><span>{dados.instagram || ''}</span><span>{c.assinatura || dados.nome || ''}</span></div>
    </AbsoluteFill>
  );
};
