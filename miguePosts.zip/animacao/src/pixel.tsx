// Pixel art: paleta do jogo, primitivas e o personagem montado a partir de marca/personagem.json.
import React from 'react';

export const C = {
  ink: '#232036', ink2: '#2E2A45', papel: '#F2F0EA', preto: '#050508',
  wall: '#C9B3C1', wall2: '#BBA3B5', dado: '#7A6582', dado2: '#6A5672',
  floorA: '#D9CABA', floorB: '#C2AFB4',
  wood: '#3A2F4A', wood2: '#4C3D5E', frame: '#7A6582',
  glass: '#A9C3D6', glass2: '#CFE0EA',
  sky1: '#B7A6D3', sky2: '#CDB5D8', sky3: '#E3C3D4', sky4: '#F2D6CF',
  bld1: '#9C88B0', bld2: '#8A769F', bldWin: '#C7B8D6',
  facade: '#D9C0A9', facade2: '#C4A890', roof: '#6E5675',
  door: '#4D6A8F', door2: '#3E5677',
  side: '#A898AE', side2: '#BCAEC1', street: '#4E4560', dash: '#B9ACC2',
  red: '#C8584F', blue: '#5C7BB0', white: '#F4EEE6',
  chair: '#8E3B4A', chair2: '#6E2C3A', metal: '#A3A1AE', metal2: '#55545F',
  cream: '#F3EDE1', creamCirc: '#FBF0DA', coral: '#E39A8E',
  panel1: '#86BAD6', panel2: '#5A5C78',
  board: '#2D3142', boardFrame: '#8A6A4F', chalk: '#E9E6DC',
  amber: '#E7B65A', sun: '#F6D58E',
  desk: '#8A6A4F', desk2: '#6E523C', screen: '#9FD0E0',
};

export const R: React.FC<{x: number; y: number; w: number; h: number; c: string; o?: number}> = ({x, y, w, h, c, o}) => (
  <rect x={x} y={y} width={w} height={h} fill={c} opacity={o} />
);

export const PxCircle: React.FC<{cx: number; cy: number; r: number; c: string}> = ({cx, cy, r, c}) => {
  const rows = [];
  for (let dy = -r; dy <= r; dy++) {
    const half = Math.floor(Math.sqrt(r * r - dy * dy));
    rows.push(<rect key={dy} x={cx - half} y={cy + dy} width={half * 2} height={1} fill={c} />);
  }
  return <>{rows}</>;
};

export const Glyph: React.FC<{g: string[]; x: number; y: number; s?: number; c: string}> = ({g, x, y, s = 1, c}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    {g.flatMap((row, yy) => [...row].map((ch, xx) => (ch === '#' ? <rect key={`${xx}-${yy}`} x={xx} y={yy} width={1} height={1} fill={c} /> : null)))}
  </g>
);
export const Q_GLYPH = ['.###.', '#...#', '....#', '...#.', '..#..', '.....', '..#..'];
export const EXC_GLYPH = ['#', '#', '#', '#', '.', '#'];

export const Sparkle: React.FC<{x: number; y: number; t: number; c?: string}> = ({x, y, t, c = C.papel}) => {
  const k = Math.floor(t / 4) % 3;
  if (k === 2) return null;
  const a = k === 0 ? 1 : 2;
  return (
    <g>
      <rect x={x} y={y - a} width={1} height={a * 2 + 1} fill={c} />
      <rect x={x - a} y={y} width={a * 2 + 1} height={1} fill={c} />
    </g>
  );
};

// ---------------- personagem ----------------
// Grade-base 16 x 30 (cabelo comprido, óculos, barba cheia). Os traços do personagem.json mudam a grade.
const BASE = [
  '.....HHHHHH.....',
  '...HHHHHHHHHH...',
  '..HHHHHHHHHHHH..',
  '..HHHSSSSSSSHH..',
  '.HHhSSSSSSSSSHH.',
  '.HHhGGGGSGGGGHH.',
  '.HHhGWEGSGWEGHH.',
  '.HHhGWWGSGWWGHH.',
  '.HHhGGGGsGGGGHH.',
  '.HHhSSSSsSSSSHH.',
  '.HHhBSSSSSSSBHH.',
  '.HHhBBBBBBBBBHH.',
  '.HHhBBBbbbBBBHH.',
  '.HH.BBBBBBBBB.H.',
  '.HH..BBBBBBB..H.',
  '..HH.KKKKKKK.HH.',
  '..KKKKKKKKKKKKK.',
  '..KkKKKKKKKKKkK.',
  '..KkKKKKkKKKKkK.',
  '..KkKKKKKKKKKkK.',
  '..KkKKKKkKKKKkK.',
  '..KkKKKKKKKKKkV.',
  '..SPPPPPPPPPPPS.',
  '...PPPPPPPPPP...',
  '...PPPPppPPPP...',
  '...PPPP..PPPP...',
  '...PPPP..PPPP...',
  '...PPPP..PPPP...',
  '..ZZZZZ..ZZZZZ..',
  '..zzzzz..zzzzz..',
];
export const OFF = 3; // colunas livres à esquerda
export const TOP = 2; // linhas livres acima (coque, cacheado)
export const CW = 22;
export const CH = 32;

export type Tracos = {
  cabelo?: 'comprido' | 'medio' | 'curto' | 'careca' | 'cacheado' | 'coque' | 'rabo';
  cor_cabelo?: string;
  pele?: string;
  oculos?: boolean;
  cor_oculos?: string;
  formato_oculos?: 'redondo' | 'quadrado';
  barba?: 'cheia' | 'curta' | 'bigode' | 'nenhuma';
  cor_barba?: string;
  camisa?: string;
  calca?: string;
  sapato?: string;
  acessorio?: {tipo?: string; cor?: string} | null;
};

const ajusta = (hex: string, k: number) => {
  const n = parseInt(hex.replace('#', ''), 16);
  const f = (v: number) => Math.max(0, Math.min(255, Math.round(v + (k > 0 ? (255 - v) * k : v * k))));
  return '#' + [f((n >> 16) & 255), f((n >> 8) & 255), f(n & 255)].map((v) => v.toString(16).padStart(2, '0')).join('');
};

export function paleta(tr: Tracos): Record<string, string> {
  const cab = tr.cor_cabelo ?? '#2E2133';
  const pele = tr.pele ?? '#E8B48F';
  const barba = tr.cor_barba ?? ajusta(cab, 0.12);
  const camisa = tr.camisa ?? '#1C2033';
  const calca = tr.calca ?? '#3A3448';
  return {
    H: cab, h: ajusta(cab, 0.22), S: pele, s: ajusta(pele, -0.12), G: tr.cor_oculos ?? '#2A1E2E', W: '#F1E3C6', E: '#1B1622',
    B: barba, b: ajusta(barba, 0.3), K: camisa, k: ajusta(camisa, 0.12), P: calca, p: ajusta(calca, -0.2),
    V: tr.acessorio?.cor ?? camisa, Z: tr.sapato ?? '#1E1A28', z: '#EDE3D2', R: '#D5D8E0', r: '#55545F', M: '#B5707A', O: '#3A1F2A',
  };
}

// figurantes prontos (sem acessório de cor de marca)
export const FIGURANTES: Record<string, Tracos> = {
  figurante1: {cabelo: 'curto', cor_cabelo: '#6B4A2E', pele: '#E8B48F', oculos: false, barba: 'cheia', cor_barba: '#7A5634', camisa: '#8E5A7A', calca: '#4F6FA0'},
  figurante2: {cabelo: 'curto', cor_cabelo: '#9A97A6', pele: '#D9A07A', oculos: false, barba: 'curta', cor_barba: '#A5A2B0', camisa: '#4F6FA0', calca: '#5A4A3E'},
  figurante3: {cabelo: 'rabo', cor_cabelo: '#3B2A22', pele: '#B9825E', oculos: false, barba: 'nenhuma', camisa: '#C8584F', calca: '#3A3448'},
  figurante4: {cabelo: 'coque', cor_cabelo: '#C99A5B', pele: '#F0C6A4', oculos: true, cor_oculos: '#5A4A3E', barba: 'nenhuma', camisa: '#E7B65A', calca: '#4E4560'},
};

export type Pose = 'idle' | 'hand' | 'wave' | 'point' | 'up' | 'segura' | 'cruzado';
export type MOpts = {
  pose?: Pose;
  blink?: boolean;
  look?: number;
  walk?: number;
  wave?: number;
  falando?: boolean;
  item?: 'celular' | 'xicara' | 'caneta' | 'nenhum';
};

export function buildChar(tr: Tracos, o: MOpts): string[][] {
  const g: string[][] = Array.from({length: CH}, () => Array(CW).fill('.'));
  const set = (x: number, y: number, c: string) => {
    const yy = y + TOP;
    if (yy >= 0 && yy < CH && x + OFF >= 0 && x + OFF < CW) g[yy][x + OFF] = c;
  };
  const get = (x: number, y: number) => g[y + TOP]?.[x + OFF] ?? '.';
  BASE.forEach((row, y) => [...row].forEach((c, x) => c !== '.' && set(x, y, c)));

  const cab = tr.cabelo ?? 'comprido';
  const tira = (y0: number, y1: number, cols: number[]) => {
    for (let y = y0; y <= y1; y++) for (const x of cols) if ('Hh'.includes(get(x, y))) set(x, y, '.');
  };
  if (cab === 'medio') tira(11, 15, [0, 1, 2, 3, 13, 14, 15]);
  if (cab === 'curto' || cab === 'careca' || cab === 'coque' || cab === 'rabo' || cab === 'cacheado') {
    tira(9, 15, [0, 1, 2, 3, 13, 14, 15]);
    tira(4, 8, [1, 14]);
  }
  if (cab === 'careca') {
    for (let y = 0; y <= 2; y++) for (let x = 0; x < 16; x++) if ('Hh'.includes(get(x, y))) set(x, y, y === 2 && x >= 3 && x <= 12 ? 'S' : '.');
    for (let y = 3; y <= 8; y++) for (const x of [2, 3, 12, 13]) if ('Hh'.includes(get(x, y))) set(x, y, y < 5 ? 'S' : 'H');
    set(4, 1, '.'); set(11, 1, '.');
    for (let x = 4; x <= 11; x++) set(x, 1, 'S');
    for (let x = 5; x <= 10; x++) set(x, 0, '.');
  }
  if (cab === 'cacheado') {
    for (let x = 3; x <= 12; x++) set(x, -1, (x % 2 ? 'H' : 'h'));
    for (const [x, y] of [[1, 1], [14, 1], [1, 2], [14, 2], [0, 3], [15, 3], [0, 4], [15, 4], [2, 0], [13, 0]]) set(x, y, (x + y) % 2 ? 'H' : 'h');
  }
  if (cab === 'coque') {
    for (let x = 6; x <= 9; x++) { set(x, -2, 'H'); set(x, -1, 'H'); }
    set(7, -2, 'h');
  }
  if (cab === 'rabo') {
    for (let y = 3; y <= 11; y++) set(14, y, 'H');
    for (let y = 5; y <= 10; y++) set(15, y, 'h');
  }
  if (tr.oculos === false) {
    for (let y = 5; y <= 8; y++) for (let x = 4; x <= 12; x++) if ('GW'.includes(get(x, y))) set(x, y, 'S');
    set(5, 5, 'H'); set(6, 5, 'H'); set(10, 5, 'H'); set(11, 5, 'H');
  }
  // aro redondo: tira os cantos da armação
  if (tr.oculos !== false && (tr.formato_oculos ?? 'quadrado') === 'redondo') {
    for (const [x, y] of [[4, 5], [7, 5], [9, 5], [12, 5], [4, 8], [7, 8], [9, 8], [12, 8]]) set(x, y, 'S');
    set(8, 6, 'G');
  }
  // olhos
  const look = o.look ?? 1;
  if (tr.oculos !== false) {
    for (const lx of [5, 10]) {
      set(lx, 6, 'W'); set(lx + 1, 6, 'W'); set(lx, 7, 'W'); set(lx + 1, 7, 'W');
      if (o.blink) { set(lx, 7, 'E'); set(lx + 1, 7, 'E'); }
      else set(look < 0 ? lx : lx + 1, 6, 'E');
    }
  } else {
    for (const lx of [6, 11]) set(lx, 6, o.blink ? 'S' : 'E');
  }
  // barba
  const barba = tr.barba ?? 'cheia';
  const limpa = (y0: number) => {
    for (let y = y0; y <= 14; y++) for (let x = 3; x <= 13; x++) {
      const c = get(x, y);
      if (c === 'B') set(x, y, y >= 14 ? 's' : 'S');
      if (c === 'b') set(x, y, 'S');
    }
  };
  if (barba === 'nenhuma') limpa(10);
  if (barba === 'bigode') { limpa(10); for (let x = 6; x <= 10; x++) set(x, 11, 'B'); }
  if (barba === 'curta') { limpa(13); }
  // boca: sem barba aparece em rosa; falando abre e fecha
  const temBarba = barba === 'cheia' || barba === 'curta';
  const bocaY = 12;
  if (!temBarba) { set(7, bocaY, 'M'); set(8, bocaY, 'M'); set(9, bocaY, 'M'); }
  if (o.falando) { set(7, bocaY, 'O'); set(8, bocaY, 'O'); set(9, bocaY, 'O'); if (!temBarba) set(8, bocaY + 1, 'O'); }
  // pernas andando
  if (o.walk) {
    for (let y = 25; y <= 29; y++) for (let x = 0; x <= 15; x++) set(x, y, '.');
    for (let y = 25; y <= 27; y++) { for (let x = 2; x <= 5; x++) set(x, y, 'P'); for (let x = 10; x <= 13; x++) set(x, y, 'P'); }
    for (let x = 1; x <= 5; x++) { set(x, 28, 'Z'); set(x, 29, 'z'); }
    for (let x = 10; x <= 14; x++) { set(x, 28, 'Z'); set(x, 29, 'z'); }
  }
  // braço do lado direito de quem assiste (o do acessório)
  const pose = o.pose ?? 'idle';
  if (pose === 'cruzado') {
    for (let x = 4; x <= 12; x++) set(x, 19, 'k');
    set(3, 19, 'S'); set(13, 19, 'S');
  } else if (pose !== 'idle') {
    for (let y = 17; y <= 22; y++) set(14, y, '.');
    set(14, 16, 'K');
    if (pose === 'hand') { set(15, 15, 'K'); set(15, 14, 'K'); set(15, 13, 'V'); set(14, 12, 'S'); set(15, 12, 'S'); set(13, 11, 'S'); set(14, 11, 'S'); }
    if (pose === 'wave') {
      const w = o.wave ? 1 : 0;
      set(15, 15, 'K'); set(15, 14, 'K'); set(15, 13, 'K'); set(15 + w, 12, 'V'); set(15 + w, 11, 'S'); set(15 + w, 10, 'S'); set(16 + w, 10, 'S');
    }
    if (pose === 'up') { set(15, 15, 'K'); set(15, 14, 'K'); set(15, 13, 'K'); set(15, 12, 'V'); set(15, 11, 'S'); set(15, 10, 'S'); }
    if (pose === 'point') { set(15, 16, 'K'); set(16, 16, 'K'); set(17, 16, 'V'); set(18, 16, 'S'); set(18, 15, 'S'); }
    if (pose === 'segura') {
      set(15, 17, 'K'); set(15, 18, 'V'); set(15, 19, 'S'); set(16, 19, 'S');
      const it = o.item ?? 'celular';
      if (it === 'celular') { for (let y = 15; y <= 19; y++) { set(16, y, 'E'); set(17, y, 'E'); } set(16, 16, 'W'); set(17, 16, 'W'); set(16, 17, 'W'); set(17, 17, 'W'); }
      if (it === 'xicara') { set(16, 17, 'z'); set(17, 17, 'z'); set(16, 18, 'z'); set(17, 18, 'z'); set(18, 17, 'z'); }
      if (it === 'caneta') { set(16, 16, 'M'); set(16, 17, 'M'); set(16, 18, 'M'); }
    }
  }
  return g;
}

export const Sprite: React.FC<{g: string[][]; pal: Record<string, string>; x: number; y: number; s?: number; flip?: boolean; rows?: [number, number]}> = ({g, pal, x, y, s = 1, flip, rows}) => {
  const rects: React.ReactNode[] = [];
  const [y0, y1] = rows ?? [0, g.length];
  for (let yy = y0; yy < y1; yy++) {
    const row = g[yy];
    let xx = 0;
    while (xx < row.length) {
      const c = row[xx];
      if (c === '.') { xx++; continue; }
      let e = xx;
      while (e < row.length && row[e] === c) e++;
      rects.push(<rect key={`${yy}-${xx}`} x={xx} y={yy} width={e - xx} height={1} fill={pal[c]} />);
      xx = e;
    }
  }
  const tr = flip ? `translate(${x + CW * s},${y}) scale(${-s},${s})` : `translate(${x},${y}) scale(${s})`;
  return <g transform={tr}>{rects}</g>;
};

// Personagem ancorado no centro dos pés (x, y em pixels da cena).
export const Char: React.FC<MOpts & {tr: Tracos; x: number; y: number; s: number; t: number; flip?: boolean; seed?: number; busto?: boolean}> = ({tr, x, y, s, t, flip, seed = 0, busto, ...o}) => {
  const blink = o.blink ?? ((t + seed * 23) % 78 < 4);
  const falando = o.falando ? Math.floor(t / 4) % 2 === 0 : false;
  const g = buildChar(tr, {...o, blink, falando});
  const rows: [number, number] = busto ? [0, TOP + 18] : [0, CH];
  const yTop = busto ? y - (TOP + 18) * s : y - CH * s;
  return <Sprite g={g} pal={paleta(tr)} x={x - (OFF + 8) * s} y={yTop} s={s} flip={flip} rows={rows} />;
};
