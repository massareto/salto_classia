// Textos em resolução cheia: legenda falada, rótulo de jogo, carimbo, etiqueta, cartão e digitação.
import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont as poppins} from '@remotion/google-fonts/Poppins';
import {loadFont as mono} from '@remotion/google-fonts/SpaceMono';
import {C} from './pixel';

export const FP = poppins('normal', {weights: ['800'], subsets: ['latin', 'latin-ext']}).fontFamily;
export const FM = mono('normal', {weights: ['700'], subsets: ['latin', 'latin-ext']}).fontFamily;
const mola = {damping: 13, mass: 0.6, stiffness: 200};

export const Legenda: React.FC<{text: string; hl: string; top: number; dur: number}> = ({text, hl, top, dur}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pop = spring({frame: f, fps, config: {damping: 14, mass: 0.6, stiffness: 180}});
  const out = interpolate(f, [dur - 4, dur], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const wipe = interpolate(f, [5, 15], [0, 100], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const i = hl ? text.indexOf(hl) : -1;
  const base: React.CSSProperties = {color: C.papel, WebkitTextStroke: '7px #0A0A0F', paintOrder: 'stroke fill', textShadow: '0 5px 0 rgba(5,5,8,.55)'};
  return (
    <div style={{position: 'absolute', left: 110, right: 190, top, textAlign: 'center', opacity: out, transform: `translateY(${(1 - pop) * 18}px) scale(${0.94 + pop * 0.06})`}}>
      <span style={{fontFamily: FP, fontWeight: 800, fontSize: 52, lineHeight: 1.2, letterSpacing: '-0.01em', ...base}}>
        {i < 0 ? text : (
          <>
            {text.slice(0, i)}
            <span style={{
              background: C.papel, whiteSpace: 'nowrap',
              color: C.preto, WebkitTextStroke: '0px transparent',
              padding: '0 8px', margin: '0 -2px', borderRadius: 4, boxDecorationBreak: 'clone', WebkitBoxDecorationBreak: 'clone', textShadow: 'none',
            }}>{hl}</span>
            {text.slice(i + hl.length)}
          </>
        )}
      </span>
    </div>
  );
};

export const Rotulo: React.FC<{children: React.ReactNode; top: number; delay?: number; bg?: string; fg?: string}> = ({children, top, delay = 0, bg = C.ink, fg = C.papel}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (f < delay) return null;
  const p = spring({frame: f - delay, fps, config: mola});
  return (
    <div style={{position: 'absolute', top, left: 0, right: 0, display: 'flex', justifyContent: 'center'}}>
      <div style={{background: bg, color: fg, fontFamily: FM, fontWeight: 700, fontSize: 36, letterSpacing: '0.06em', textTransform: 'uppercase', padding: '12px 26px', boxShadow: '8px 8px 0 rgba(35,32,54,.28)', transform: `scale(${0.6 + 0.4 * p})`, opacity: p, whiteSpace: 'pre', textAlign: 'center', lineHeight: 1.25, maxWidth: 860}}>{children}</div>
    </div>
  );
};

export const Carimbo: React.FC<{children: React.ReactNode; x: number; y: number; delay: number; color?: string; rot?: number}> = ({children, x, y, delay, color = C.red, rot = -8}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (f < delay) return null;
  const p = spring({frame: f - delay, fps, config: {damping: 11, mass: 0.5, stiffness: 220}});
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${2.2 - 1.2 * p})`, opacity: Math.min(1, p * 1.6)}}>
      <div style={{border: `8px solid ${color}`, color, fontFamily: FM, fontWeight: 700, fontSize: 54, padding: '6px 22px', letterSpacing: '0.04em', background: 'rgba(242,240,234,.92)', whiteSpace: 'pre', textAlign: 'center', lineHeight: 1.15}}>{children}</div>
    </div>
  );
};

export const Etiqueta: React.FC<{x: number; y: number; delay: number; children: React.ReactNode; bg?: string; fg?: string}> = ({x, y, delay, children, bg = C.papel, fg = C.ink}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (f < delay) return null;
  const p = spring({frame: f - delay, fps, config: {damping: 12, mass: 0.5, stiffness: 220}});
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-100%) scale(${0.5 + 0.5 * p})`, transformOrigin: '50% 100%'}}>
      <div style={{background: bg, color: fg, fontFamily: FM, fontWeight: 700, fontSize: 32, padding: '8px 18px', border: `5px solid ${C.ink}`, whiteSpace: 'pre', letterSpacing: '0.04em', boxShadow: '6px 6px 0 rgba(35,32,54,.3)', textAlign: 'center'}}>{children}</div>
      <div style={{width: 0, height: 0, margin: '0 auto', borderLeft: '14px solid transparent', borderRight: '14px solid transparent', borderTop: `14px solid ${C.ink}`}} />
    </div>
  );
};

export const Cartao: React.FC<{children: React.ReactNode; delay: number; top?: number}> = ({children, delay, top = 352}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (f < delay) return null;
  const p = spring({frame: f - delay, fps, config: {damping: 15, mass: 0.7, stiffness: 160}});
  return (
    <div style={{position: 'absolute', top, left: 0, right: 0, display: 'flex', justifyContent: 'center', transform: `translateY(${(1 - p) * -60}px)`, opacity: p}}>
      <div style={{background: C.wood, border: `6px solid ${C.frame}`, color: C.papel, fontFamily: FM, fontWeight: 700, fontSize: 38, padding: '18px 30px', whiteSpace: 'pre', lineHeight: 1.3, boxShadow: '10px 10px 0 rgba(35,32,54,.3)', maxWidth: 860}}>{children}</div>
    </div>
  );
};

export const Digitado: React.FC<{texto: string; start: number; cps?: number; style?: React.CSSProperties}> = ({texto, start, cps = 1.1, style}) => {
  const f = useCurrentFrame();
  const n = Math.max(0, Math.floor((f - start) * cps));
  const cursor = n < texto.length && f >= start && Math.floor(f / 8) % 2 === 0;
  if (f < start) return null;
  return (
    <div style={style}>
      {texto.slice(0, n)}
      {cursor ? <span style={{opacity: 0.8}}>▌</span> : null}
    </div>
  );
};
