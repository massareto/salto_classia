"""Lê o CONTEXTO.md do coach: cores por papel, fonte, contatos, chamada, selo e avatar.

Uso como módulo:  from contexto import ler_contexto
Uso direto:       python3 contexto.py [/caminho/CONTEXTO.md]   -> imprime o JSON
"""
import json
import os
import re
import sys
from pathlib import Path

def _achar_raiz() -> Path:
    """Pasta do projeto (a que tem o CONTEXTO.md). Ordem: variável MARKETING_COACHES_PROJETO;
    instalação local (<projeto>/habilidades/migueposts/scripts); a própria habilidade
    (Manus: o CONTEXTO.md fica dentro da habilidade); a pasta atual; por fim, a habilidade."""
    aqui = Path(__file__).resolve()
    env = os.environ.get('MARKETING_COACHES_PROJETO')
    candidatos = ([Path(env).expanduser()] if env else []) + [aqui.parents[3], aqui.parents[1], Path.cwd()]
    for p in candidatos:
        if (p / 'CONTEXTO.md').exists():
            return p
    return aqui.parents[1]


RAIZ = _achar_raiz()


def para_voz(texto: str) -> str:
    """Expande siglas conhecidas. A revisão editorial deve expandir também siglas específicas do assunto."""
    mapa = {
        r'(?<!\w)(?:I\.A\.?|IA|A\.I\.?|AI)(?!\w)': 'inteligência artificial',
        r'\bCEO\b': 'diretor executivo', r'\bRH\b': 'recursos humanos',
        r'\bCRM\b': 'gestão de relacionamento com clientes',
        r'\bROI\b': 'retorno sobre o investimento',
        r'\bB2B\b': 'entre empresas', r'\bB2C\b': 'para consumidores',
    }
    for padrao, expansao in mapa.items():
        texto = re.sub(padrao, expansao, texto)
    return texto


def chave_api(variavel: str, servico: str) -> str:
    """Chave de API: variável de ambiente (ex.: segredo do Manus) ou ~/.config/<servico>/api_key. Nunca imprimir."""
    v = os.environ.get(variavel, '').strip()
    if v:
        return v
    arq = Path.home() / '.config' / servico / 'api_key'
    if arq.exists():
        return arq.read_text().strip()
    sys.exit(f'Falta a chave do {servico}: defina {variavel} ou grave em ~/.config/{servico}/api_key.')


CHAMADA_DIRECT = 'Me chama no Direct'
CONVITE_DIRECT = 'Quer resolver esse problema? Me chama no Direct.'

CONTEXTO_PADRAO = RAIZ / 'CONTEXTO.md'

# Valores por omissão (identidade neutra): o CONTEXTO.md do coach sempre tem prioridade.
CORES_PADRAO = {
    'fundo': '#111114',
    'cartao': '#1C1C22',
    'texto': '#F5F4EF',
    'marca-texto': '#F5F4EF',
    'texto-marca-texto': '#111114',
    'acento': '#2FBF71',
}
FONTES = ('Poppins', 'Montserrat', 'Inter')


def _campo(t: str, nome: str) -> str | None:
    m = re.search(rf'\*\*{re.escape(nome)}:\*\*\s*(.+)', t)
    return m.group(1).strip() if m else None


def _opcao(t: str, nome: str, padrao: str) -> str:
    """Lê a opção mesmo quando o modelo tem uma explicação entre parênteses."""
    return (_campo(t, nome) or padrao).split('(', 1)[0].strip('` ').lower()


def _caminho_opcional(t: str, nome: str) -> str:
    valor = (_campo(t, nome) or '').strip('` ')
    return '' if valor.startswith(('[', '<')) else valor


def _cores(t: str) -> dict:
    cores = dict(CORES_PADRAO)
    # Linhas da tabela de cores: | `papel` | nome | `#HEX` | uso |
    for papel, hexa in re.findall(r'^\|\s*`?([a-z-]+)`?\s*\|[^|\n]*\|\s*`?(#[0-9A-Fa-f]{6})`?', t, re.M):
        if papel in cores:
            cores[papel] = hexa.upper()
    return cores


def ler_contexto(caminho: Path = CONTEXTO_PADRAO) -> dict:
    if not Path(caminho).exists():
        sys.exit(f'Falta o CONTEXTO.md ({caminho}). É a primeira vez: a Helena (equipe/22_helena_prado.md) pergunta ao dono '
                 'apenas as lacunas de serviço e público, confere avatar e voz HeyGen, cria o CONTEXTO.md a partir de '
                 'CONTEXTO-modelo.md e só então a equipe segue.')
    t = Path(caminho).read_text(encoding='utf-8')
    insta = re.search(r'\*\*Instagram:\*\*\s*\[?(@[\w.]+)', t)
    def identificador(campo: str) -> str | None:
        valor = (_campo(t, campo) or '').strip('` ')
        return valor if re.fullmatch(r'[A-Za-z0-9_-]{8,128}', valor) else None

    avatar = identificador('Avatar HeyGen (avatar_id)')
    voz = identificador('Voz HeyGen (voice_id)')
    fonte = (_campo(t, 'Fonte de título') or 'Poppins').split()[0].strip('`*')
    selo = (_campo(t, 'Selo') or '').strip('`')
    return {
        'nome': _campo(t, 'Nome') or '',
        'nicho': _campo(t, 'Nicho') or '',
        'cores': _cores(t),
        'fonte': fonte if fonte in FONTES else 'Poppins',
        'instagram': insta.group(1) if insta else '',
        'contato': CHAMADA_DIRECT,
        'cta': CHAMADA_DIRECT,
        'selo': str(RAIZ / selo) if selo and (RAIZ / selo).exists() else None,
        'avatar_look': avatar if avatar and _opcao(t, 'Usar avatar no Reels', 'sim') not in ('não', 'nao', 'pular', 'sem avatar', 'false') else None,
        # 16:9 = avatar horizontal sem recorte (ex.: estúdio), pedido em MP4; 9:16 = vertical com recorte, em WebM.
        'avatar_formato': '16:9' if '16:9' in (_campo(t, 'Formato do avatar') or '') else '9:16',
        'cta_animacao': CONVITE_DIRECT,
        'voz': voz,
        'provedor_voz': _opcao(t, 'Provedor de voz', 'heygen'),
        'modelo_voz_local': _caminho_opcional(t, 'Modelo de voz local'),
        'python_voz_local': _caminho_opcional(t, 'Python da voz local'),
    }


if __name__ == '__main__':
    print(json.dumps(ler_contexto(Path(sys.argv[1]) if len(sys.argv) > 1 else CONTEXTO_PADRAO),
                     ensure_ascii=False, indent=2))


def esperar_instalacao(modelo: Path, limite_s: int = 600) -> None:
    """Se scripts/aquecer.py está instalando o Remotion em segundo plano, espera acabar (em vez de instalar duas vezes)."""
    import time
    marca = modelo / '.instalando'
    t0 = time.time()
    while marca.exists() and time.time() - t0 < limite_s and time.time() - marca.stat().st_mtime < limite_s:
        time.sleep(3)
