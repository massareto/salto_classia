"""Abre configuração no Chrome e recebe chaves somente em terminal interativo oculto."""
import argparse
import getpass
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

PAGINAS = {
    'heygen': ['https://platform.heygen.com/api-keys', 'https://app.heygen.com/avatars'],
}


def comando_chrome(urls):
    if sys.platform == 'darwin':
        return ['open', '-a', 'Google Chrome', *urls]
    if os.name == 'nt':
        candidatos = [Path(os.environ.get(x, '')) / 'Google/Chrome/Application/chrome.exe' for x in ('PROGRAMFILES', 'PROGRAMFILES(X86)', 'LOCALAPPDATA')]
        exe = next((str(p) for p in candidatos if p.is_file()), None)
    else:
        exe = next((shutil.which(x) for x in ('google-chrome', 'google-chrome-stable') if shutil.which(x)), None)
    if not exe:
        raise RuntimeError('Google Chrome não encontrado. Abra manualmente os links apresentados; nenhum navegador foi aberto.')
    return [exe, *urls]


def guardar(servico, substituir=False):
    if not sys.stdin.isatty():
        raise RuntimeError('Execute guardar-chave no seu terminal interativo. Não envie a chave como argumento nem no chat.')
    destino = Path.home() / '.config' / servico / 'api_key'
    if destino.exists() and not substituir:
        raise RuntimeError('Já existe chave. Não foi alterada. Use --substituir somente se você decidiu substituí-la.')
    segredo = getpass.getpass('Cole a chave aqui (entrada oculta): ').strip()
    if not segredo or '\n' in segredo:
        raise RuntimeError('Chave vazia ou inválida; nada foi gravado.')
    destino.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(destino, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w') as f:
        f.write(segredo)
    os.chmod(destino, 0o600)
    print('Chave guardada em arquivo local restrito. Valor não exibido.')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='acao', required=True)
    abrir = sub.add_parser('abrir'); abrir.add_argument('servico', choices=PAGINAS); abrir.add_argument('--dry-run', action='store_true')
    chave = sub.add_parser('guardar-chave'); chave.add_argument('servico', choices=PAGINAS); chave.add_argument('--substituir', action='store_true')
    sub.add_parser('diagnostico')
    a = p.parse_args()
    if a.acao == 'abrir':
        urls = PAGINAS[a.servico]
        print('\n'.join(urls))
        if not a.dry_run:
            subprocess.run(comando_chrome(urls), check=True)
            print('Solicitada abertura das páginas no Google Chrome; confirme a tela antes de orientar cliques.')
    elif a.acao == 'guardar-chave':
        guardar(a.servico, a.substituir)
    else:
        from contexto import CONTEXTO_PADRAO, ler_contexto
        c = ler_contexto() if CONTEXTO_PADRAO.exists() else {}
        print(json.dumps({
            'voz_heygen_selecionada': bool(c.get('voz')), 'provedor_voz': 'heygen',
            'contexto': CONTEXTO_PADRAO.exists(), 'avatar_selecionado': bool(c.get('avatar_look')),
            'heygen_chave_presente': bool(os.environ.get('HEYGEN_API_KEY')) or (Path.home()/'.config/heygen/api_key').is_file(),
        }, ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, subprocess.CalledProcessError) as e:
        sys.exit(str(e))
