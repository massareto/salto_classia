"""Larissa Nunes: monta as cartelas do carrossel (1080x1350) e confere que nada fica cortado.

Uso:
  python3 remotion_cartelas.py "<pasta da peça>"

Precisa de <pasta>/trabalho/cartelas.json (a Juliana escreve), por exemplo:
  [
    {"n": 1, "kicker": "PRODUTIVIDADE", "texto": "Sua agenda é sua ou de quem te manda mensagem?", "destaque": "de quem te manda mensagem?",
     "imagem": "trabalho/imagens/carrossel_01.png"},
    {"n": 2, "kicker": "O DADO", "numero": "23 MIN", "texto": "Uma pesquisa da UC Irvine mediu ...", "destaque": "UC Irvine", "icone": "relogio"},
    ...
    {"n": 5, "texto": "Quer montar a sua semana comigo?", "destaque": "a sua semana", "imagem": "trabalho/imagens/carrossel_05.png"}
  ]
  - kicker, numero e fonte (fonte curta do dado, ex.: "Mark et al., 2005") são opcionais; o destaque tem de existir tal e qual no texto.
  - Cada cartela tem OBRIGATORIAMENTE um visual: "imagem" (caminho dentro da pasta da peça, gerada por IA, de ponta
    a ponta com degradê por baixo do texto), "icone"
    (desenhado em código, ver remotion/src/icones.tsx). Retratos exigem proveniência revisada. focoX = fração da largura.
  - Capa e última cartela exigem retrato do apresentador; a última inclui o botão do Direct.

Entrega: <pasta>/entrega/carrossel/01.png … 07.png
Controle: renderiza também uma máscara só com as letras e confirma que nenhuma letra entra nos 72 px de nenhuma borda.
"""
import json
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
from contexto import RAIZ, ler_contexto  # noqa: E402
from remotion_reels import ICONES, copiar_imagem, nome_selo, preparar_projeto  # noqa: E402

MARGEM_LIVRE = 72


def stills(proj: Path, trabalhos: list[tuple[dict, Path]]) -> None:
    """Renderiza todas as imagens de uma vez (um bundle, um navegador): remotion/stills.mjs."""
    with tempfile.NamedTemporaryFile('w', suffix='.json', delete=False, encoding='utf-8') as f:
        json.dump([{'id': 'Cartela', 'props': p, 'out': str(o)} for p, o in trabalhos], f, ensure_ascii=False)
    subprocess.run(['node', 'stills.mjs', 'src/index.ts', f.name], cwd=proj, check=True)
    Path(f.name).unlink()


def visual(pasta: Path, proj: Path, c: dict, props: dict, nome: str, *, retrato: bool = False) -> None:
    """Põe a imagem, a foto do coach ou o ícone da cartela nas props."""
    if retrato and not c.get('imagem'):
        raise ValueError(f'{nome}: inclua o retrato gerado do apresentador.')
    if c.get('foto'):
        raise ValueError('Foto original não entra na peça. Gere nova imagem a partir da referência e use imagem com proveniência.')
    if c.get('imagem'):
        from imagem_identidade import validar
        caminho = str(validar(pasta, c['imagem'], retrato=retrato))
        arq, ratio = copiar_imagem(pasta, caminho, proj / 'public', nome)
        props.update(foto=arq, focoX=c.get('focoX', 0.5), ratio=ratio)
    elif c.get('icone'):
        if c['icone'] not in ICONES:
            sys.exit(f"{nome}: ícone \"{c['icone']}\" não existe. Use: {', '.join(ICONES)}")
        props['icone'] = c['icone']


def exportar(proj: Path, lote: list[tuple[dict, Path]], tamanho=(1080, 1350)) -> list[bool]:
    """Renderiza as cartelas e, com uma máscara só das letras, confere que nenhuma letra entra nos 72 px da borda."""
    with tempfile.TemporaryDirectory() as tmp:
        mascaras = [Path(tmp) / f'm{i}.png' for i in range(len(lote))]
        stills(proj, [(p, o) for p, o in lote] + [({**p, 'modo': 'mascara'}, m) for (p, _), m in zip(lote, mascaras)])
        ok = []
        for (_, png), m in zip(lote, mascaras):
            assert Image.open(png).size == tamanho, f'{png.name}: tamanho errado'
            a = np.array(Image.open(m).convert('L')) > 60
            b = MARGEM_LIVRE
            ok.append(not (a[:b].any() or a[-b:].any() or a[:, :b].any() or a[:, -b:].any()))
    return ok


def main(pasta: Path) -> None:
    from revisao import checar
    checar(pasta, ['cartelas'])  # nada de "exemplo fictício", travessão, palavra proibida... antes de renderizar
    ctx = ler_contexto()
    cartelas = json.loads((pasta / 'trabalho' / 'cartelas.json').read_text(encoding='utf-8'))
    proj = preparar_projeto(pasta, ctx, 'remotion_carrossel')
    saida = pasta / 'entrega' / 'carrossel'
    saida.mkdir(parents=True, exist_ok=True)
    problemas, lote = [], []
    for index, c in enumerate(cartelas):
        if c['destaque'] not in c['texto']:
            sys.exit(f"Cartela {c['n']}: o destaque \"{c['destaque']}\" não está no texto.")
        props = {'n': c['n'], 'total': len(cartelas), 'texto': c['texto'], 'destaque': c['destaque'],
                 'kicker': c.get('kicker'), 'numero': c.get('numero'), 'fonte': c.get('fonte'), 'cores': ctx['cores'],
                 'fonteTitulo': ctx['fonte'], 'instagram': ctx['instagram'], 'selo': nome_selo(ctx),
                 'contato': ctx['contato'] if index == len(cartelas) - 1 else None}
        if not (c.get('imagem') or c.get('foto') or c.get('icone')):
            sys.exit(f"Cartela {c['n']}: sem imagem, foto nem ícone. Nenhuma cartela fica só com texto em fundo vazio.")
        visual(pasta, proj, c, props, f"carrossel_{c['n']:02d}", retrato=index in (0, len(cartelas) - 1))
        lote.append((props, saida / f"{c['n']:02d}.png"))
    for (_, png), ok in zip(lote, exportar(proj, lote)):
        if not ok:
            problemas.append(png.name)
        print(f'{png.name}: ok' if ok else f'{png.name}: TEXTO NA MARGEM')
    if problemas:
        sys.exit('Texto entrando na margem de 72 px: ' + ', '.join(problemas) + ' (encurtar o texto ou ajustar).')
    print('Carrossel:', saida, '- nada cortado (margens de 72 px livres em todas as cartelas).')


if __name__ == '__main__':
    main(Path(sys.argv[1]).resolve())
