"""Monte o SRT editorial a partir da fala incorporada ao clipe retornado pelo HeyGen.

Use os tempos do SRT do mesmo job quando disponíveis. A duração, a transcrição
ou os silêncios vêm do clipe existente; a legenda usa o roteiro.
"""
import difflib
import re
import shutil
import subprocess
import sys
import tempfile
import unicodedata
from pathlib import Path

MAX_CH = 24  # caracteres por bloco (duas linhas curtas no peito)


def norm(p: str) -> str:
    p = unicodedata.normalize('NFKD', p.lower())
    return re.sub(r'[^a-z0-9]', '', ''.join(c for c in p if not unicodedata.combining(c)))


def duracao(wav: Path) -> float:
    return float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
                                          '-of', 'csv=p=0', str(wav)]).strip())


def de_whisper(wav: Path) -> list[tuple[str, float, float]]:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from animacao import modelo_whisper  # noqa: E402
    m = modelo_whisper()
    if not (m and shutil.which('whisper-cli')):
        return []
    with tempfile.TemporaryDirectory() as tmp:
        w16 = Path(tmp) / 'v.wav'
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(wav), '-ac', '1', '-ar', '16000', str(w16)], check=True)
        subprocess.run(['whisper-cli', '-m', str(m), '-l', 'pt', '-f', str(w16), '-ml', '1', '-sow', '-osrt',
                        '-of', str(Path(tmp) / 'p'), '-np'], capture_output=True, check=True)
        srt = (Path(tmp) / 'p.srt').read_text(encoding='utf-8')
    saida = []
    for b in re.split(r'\n\s*\n', srt.strip()):
        ln = b.split('\n')
        if len(ln) < 3:
            continue
        a, z = ln[1].split(' --> ')
        seg = lambda s: sum(float(x) * k for x, k in zip(s.replace(',', '.').split(':'), (3600, 60, 1)))  # noqa: E731
        t = ' '.join(ln[2:]).strip()
        if t:
            saida.append((t, seg(a), seg(z)))
    return saida


def silencios(wav: Path, minimo: float = 0.2) -> list[tuple[float, float]]:
    dur = duracao(wav)
    log = subprocess.run(['ffmpeg', '-i', str(wav), '-vn', '-af', f'silencedetect=n=-35dB:d={minimo}', '-f', 'null', '-'],
                         capture_output=True, text=True).stderr
    ini = [float(x) for x in re.findall(r'silence_start: ([\d.]+)', log)]
    fim = [float(x) for x in re.findall(r'silence_end: ([\d.]+)', log)]
    return list(zip(ini, fim + [dur] * (len(ini) - len(fim))))


def encaixar(bl: list[tuple[float, float, str]], sil: list[tuple[float, float]]) -> list[tuple[float, float, str]]:
    """Leva cada pausa medida no áudio para o limite de bloco mais próximo (até 0,8 s): o bloco anterior acaba
    quando a voz para e o seguinte entra quando ela volta. Corrige o meio segundo que o reconhecimento erra."""
    bl = [list(b) for b in bl]
    for a, z in sil:
        if a < 0.05 or z - a < 0.25:
            continue
        meio = (a + z) / 2
        k = min(range(1, len(bl)), key=lambda i: abs(bl[i][0] - meio), default=None)
        if k is not None and abs(bl[k][0] - meio) < 0.8:
            bl[k - 1][1], bl[k][0] = a, z
    for i in range(1, len(bl)):  # sem sobreposição nem bloco de duração negativa
        bl[i][0] = max(bl[i][0], bl[i - 1][1])
        bl[i][1] = max(bl[i][1], bl[i][0] + 0.2)
    return [tuple(b) for b in bl]  # type: ignore[misc]


def estimar(palavras: list[str], wav: Path) -> list[tuple[float, float]]:
    """Sem reconhecimento de fala: cada pausa medida no áudio cai numa pontuação do texto (a escolha que melhor
    casa o tamanho das frases com a duração dos trechos de fala) e as palavras se repartem dentro de cada trecho."""
    dur = duracao(wav)
    trechos, cur = [], 0.0
    for a, z in silencios(wav, 0.25):
        if a > cur + 0.05:
            trechos.append([cur, a])
        cur = z
    if cur < dur - 0.05:
        trechos.append([cur, dur])
    trechos = trechos or [[0.0, dur]]
    cand = [i for i, p in enumerate(palavras[:-1]) if re.search(r'[.,?!:;]$', p)]
    while len(trechos) - 1 > len(cand):  # mais pausas do que pontuação: junta pela pausa mais curta
        k = min(range(1, len(trechos)), key=lambda i: trechos[i][0] - trechos[i - 1][1])
        trechos[k - 1][1] = trechos.pop(k)[1]
    peso = [len(p) + 1 for p in palavras]
    acum = [0]
    for w in peso:
        acum.append(acum[-1] + w)
    dur_t = [b - a for a, b in trechos]
    alvo = [sum(dur_t[:k + 1]) / sum(dur_t) for k in range(len(trechos) - 1)]
    # programação dinâmica: a k-ésima pausa entra depois da palavra cand[c]
    n_k, n_c = len(alvo), len(cand)
    custo = lambda k, c: (acum[cand[c] + 1] / acum[-1] - alvo[k]) ** 2  # noqa: E731
    melhor = [[float('inf')] * n_c for _ in range(n_k)]
    de = [[-1] * n_c for _ in range(n_k)]
    for k in range(n_k):
        for c in range(k, n_c - (n_k - 1 - k)):
            if k == 0:
                melhor[k][c] = custo(k, c)
                continue
            j = min(range(k - 1, c), key=lambda j: melhor[k - 1][j])
            melhor[k][c], de[k][c] = melhor[k - 1][j] + custo(k, c), j
    cortes = []
    if n_k:
        c = min(range(n_c), key=lambda c: melhor[n_k - 1][c])
        for k in range(n_k - 1, -1, -1):
            cortes.append(cand[c] + 1)
            c = de[k][c]
        cortes.reverse()
    limites = [0] + cortes + [len(palavras)]
    tempos = []
    for (a, z), i0, i1 in zip(trechos, limites, limites[1:]):
        tot = acum[i1] - acum[i0] or 1
        for i in range(i0, i1):
            tempos.append((a + (z - a) * (acum[i] - acum[i0]) / tot, a + (z - a) * (acum[i + 1] - acum[i0]) / tot - 0.01))
    return tempos


def alinhar(palavras: list[str], fonte: list[tuple[str, float, float]]) -> list[tuple[float, float]]:
    """Põe em cada palavra da fala o tempo da palavra reconhecida correspondente (interpola as que faltam)."""
    a, b = [norm(p) for p in palavras], [norm(t) for t, _, _ in fonte]
    tempos: list[tuple[float, float] | None] = [None] * len(palavras)
    for bl in difflib.SequenceMatcher(None, a, b, autojunk=False).get_matching_blocks():
        for k in range(bl.size):
            _, s, e = fonte[bl.b + k]
            tempos[bl.a + k] = (s, e)
    conhecidos = [i for i, t in enumerate(tempos) if t]
    if not conhecidos:
        return []
    for i, t in enumerate(tempos):
        if t:
            continue
        antes = max((j for j in conhecidos if j < i), default=None)
        depois = min((j for j in conhecidos if j > i), default=None)
        t0 = tempos[antes][1] if antes is not None else 0.0
        t1 = tempos[depois][0] if depois is not None else t0 + 0.4 * (i - (antes or 0))
        n = (depois if depois is not None else i + 1) - (antes if antes is not None else -1)
        k = i - (antes if antes is not None else -1)
        tempos[i] = (t0 + (t1 - t0) * (k - 1) / n, t0 + (t1 - t0) * k / n)
    return tempos  # type: ignore[return-value]


def blocos(palavras: list[str], tempos: list[tuple[float, float]]) -> list[tuple[float, float, str]]:
    saida, cur = [], []
    for i, (p, t) in enumerate(zip(palavras, tempos)):
        texto = ' '.join(x for x, _ in cur + [(p, t)])
        if cur and len(texto) > MAX_CH:
            saida.append(cur)
            cur = []
        cur.append((p, t))
        pausa = i + 1 < len(tempos) and tempos[i + 1][0] - t[1] > 0.35
        if re.search(r'[.?!]$', p) or pausa:
            saida.append(cur)
            cur = []
    if cur:
        saida.append(cur)
    return [(b[0][1][0], b[-1][1][1], ' '.join(p for p, _ in b)) for b in saida]


def srt_tempo(s: float) -> str:
    ms = int(round(max(0, s) * 1000))
    return f'{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d},{ms % 1000:03d}'


def main(pasta: Path, clipe: Path | None = None) -> None:
    from contexto import para_voz
    from heygen_avatar import duracao_clipe
    from remotion_reels import achar_avatar, ler_srt

    clipe = clipe or achar_avatar(pasta / 'entrega' / 'video')
    if clipe is None:
        sys.exit('Importe o vídeo do HeyGen com a fala incorporada antes de fazer as legendas.')
    limite = int(duracao_clipe(clipe) * 30) / 30
    palavras = para_voz((pasta / 'trabalho' / 'fala.txt').read_text(encoding='utf-8')).split()
    srt_heygen = clipe.with_name('avatar.srt')
    fonte = []
    cues = ler_srt(srt_heygen) if srt_heygen.is_file() and srt_heygen.stat().st_size else []
    for cue in cues:
        termos = cue['texto'].split()
        passo = (cue['fim'] - cue['ini']) / max(1, len(termos))
        fonte.extend((palavra, cue['ini'] + i * passo, cue['ini'] + (i + 1) * passo)
                     for i, palavra in enumerate(termos))
    origem = 'SRT do HeyGen'
    tempos = alinhar(palavras, fonte) if fonte else []
    if not tempos:
        tempos = alinhar(palavras, de_whisper(clipe))
        origem = 'transcrição do clipe'
    if not tempos:
        tempos = estimar(palavras, clipe)
        origem = 'estimativa pelos silêncios do clipe'
    bl = blocos(palavras, tempos)
    if origem != 'SRT do HeyGen':
        bl = encaixar(bl, [(a, z) for a, z in silencios(clipe) if z < limite - 0.05])
    limitados = []
    for a, z, texto_bloco in bl:
        inicio = max(a, limitados[-1][1] if limitados else 0)
        fim = min(limite, max(z, inicio + 0.2))
        if fim - inicio < 0.001 and limitados:
            a_ant, z_ant, anterior = limitados[-1]
            limitados[-1] = (a_ant, z_ant, anterior + ' ' + texto_bloco)
            continue
        if fim > inicio:
            limitados.append((inicio, fim, texto_bloco))
    bl = limitados
    texto = '\n'.join(f'{i}\n{srt_tempo(a)} --> {srt_tempo(z)}\n{t}\n' for i, (a, z, t) in enumerate(bl, 1))
    (pasta / 'trabalho' / 'legendas.srt').write_text(texto, encoding='utf-8')
    print(f'Legendas: trabalho/legendas.srt ({len(bl)} blocos, tempo: {origem})')


if __name__ == '__main__':
    main(Path(sys.argv[1]).resolve())
