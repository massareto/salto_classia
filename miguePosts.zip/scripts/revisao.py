"""Vera Azevedo: revisão automática de todo texto que vai para o ar, antes de renderizar e antes de entregar.

Uso:
  python3 revisao.py "<pasta da peça>"            # revisa tudo; sai com erro se achar problema
  python3 revisao.py "<pasta da peça>" cartelas   # só uma parte: cartelas, reels, animacao, estatico, legendas

Lê os textos públicos de trabalho/ (cartelas.json, reels_cenas.json, fala.txt, animacao.json, estatico.json e as
legendas dos posts em 05_carrossel.md e 07_estatico.md) e barra:
  - "exemplo fictício", "fictício", "hipotético", "imagine", "vamos supor", "neste exemplo", "Exemplo:" no começo;
  - travessões (— ou –);
  - qualquer item "[a confirmar]";
  - as "Palavras que nunca usa" do CONTEXTO.md;
  - o que foge do formato "notícia da semana" (ver problemas_roteiro): notícia velha, gancho genérico, número fora da notícia.
A parte "gancho" confere os ganchos das peças. Também aceita o gancho.json legado.
Os renders (cartelas, Reels, animação, estático) chamam esta revisão da sua parte e param se houver problema;
o entrega.py chama a revisão inteira e não gera os links enquanto houver problema. O que é imagem (texto escrito
dentro de uma imagem gerada, rosto deformado) não se revisa por script: a Vera abre cada PNG e fotograma.
"""
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from contexto import CONTEXTO_PADRAO  # noqa: E402

PADROES = [
    (r'exemplo\s+fict[ií]ci', 'anuncia "exemplo fictício"'),
    (r'\bfict[ií]ci[oa]s?\b', 'fala em "fictício"'),
    (r'\bhipot[ée]tic[oa]s?\b', 'fala em "hipotético"'),
    (r'\bimagin[ea]\b', 'pede para imaginar'),
    (r'\bvamos supor\b|\bsuponha\b', 'pede para supor'),
    (r'\b(neste|nesse|num|no) exemplo\b', 'anuncia que é exemplo'),
    (r'(^|[.!?:]\s+)exemplo\s*:', 'começa com "Exemplo:"'),
    (r'[—–]', 'travessão'),
    (r'\bv[ií]rgula\b', 'número dito com "vírgula" (diga como gente: "pouco mais de sete horas e meia")'),
    (r'\[a confirmar\]', 'item [a confirmar] no texto público'),
]


def palavras_proibidas() -> list[str]:
    """As expressões entre aspas da seção "Palavras que nunca usa" do CONTEXTO.md."""
    t = CONTEXTO_PADRAO.read_text(encoding='utf-8') if CONTEXTO_PADRAO.exists() else ''
    m = re.search(r'#+\s*Palavras que nunca usa(.*?)(\n#|\Z)', t, re.S | re.I)
    return [p.strip() for p in re.findall(r'["“]([^"”]{2,40})["”]', m.group(1))] if m else []


def _limpa(t: str) -> str:
    return re.sub(r'\[[^\]]*\]\s*', '', t)  # marcações de voz do ElevenLabs ([storytelling]...)


def _json(arq: Path):
    try:
        return json.loads(arq.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None


def _strings(obj, chaves=('texto', 'rotulo', 'titulo', 'linhas', 'cabecalho', 'rodape', 'de', 'kicker', 'numero', 'destaque')):
    """Todas as strings públicas de um JSON de cenas (rótulos, etiquetas, carimbos, balões, quadros)."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, str) and k in chaves:
                yield v
            elif isinstance(v, (dict, list)):
                yield from _strings(v, chaves)
    elif isinstance(obj, list):
        for v in obj:
            if isinstance(v, str):
                yield v
            else:
                yield from _strings(v, chaves)


def _legenda_post(arq: Path) -> str:
    """O trecho da legenda do post num .md (da linha com "Legenda" até o próximo título)."""
    if not arq.exists():
        return ''
    linhas, dentro = [], False
    for ln in arq.read_text(encoding='utf-8').splitlines():
        if re.match(r'^\s*(#+|\*\*)\s*legenda', ln, re.I):
            dentro = True
            continue
        if dentro and re.match(r'^\s*#+\s', ln):
            break
        if dentro:
            linhas.append(ln)
    return '\n'.join(linhas)


def textos(pasta: Path, partes: list[str] | None = None) -> list[tuple[str, str]]:
    t = pasta / 'trabalho'
    quer = lambda p: not partes or p in partes  # noqa: E731
    saida = []
    if quer('cartelas') and (c := _json(t / 'cartelas.json')):
        for x in c:
            for k in ('kicker', 'numero', 'texto', 'destaque', 'fonte'):
                if x.get(k):
                    saida.append((f"cartela {x.get('n')} ({k})", str(x[k])))
    if quer('reels'):
        if r := _json(t / 'reels_cenas.json'):
            for i, x in enumerate(r.get('cenas', []), 1):
                for k in ('kicker', 'numero', 'texto', 'destaque'):
                    if x.get(k):
                        saida.append((f'Reels cena {i} ({k})', str(x[k])))
            if r.get('cta'):
                saida.append(('Reels (chamada)', r['cta']))
        if (t / 'fala.txt').exists():
            saida.append(('fala do Reels', (t / 'fala.txt').read_text(encoding='utf-8')))
    if quer('animacao') and (a := _json(t / 'animacao.json')):
        for f in a.get('falas', []):
            saida.append((f"animação fala {f.get('id')}", _limpa(f.get('texto', ''))))
        for i, c in enumerate(a.get('cenas', []), 1):
            for s in _strings(c):
                saida.append((f'animação cena {i} (na tela)', s))
    if quer('estatico') and (e := _json(t / 'estatico.json')):
        for k in ('kicker', 'texto', 'destaque'):
            if e.get(k):
                saida.append((f'estático ({k})', str(e[k])))
    for parte, nome, rotulo in (('cartelas', '05_carrossel.md', 'legenda do carrossel'),
                               ('estatico', '07_estatico.md', 'legenda do estático')):
        if quer(parte) or quer('legendas'):
            if txt := _legenda_post(t / nome):
                saida.append((rotulo, txt))
    return saida


VAGO = re.compile(r'\b(a|à|uma|essa|esta|aquela|da|na|dessa|nessa|pela)\s+(ideia|solu[çc][ãa]o|novidade|sacada)\b'
                  r'|\b(o|um|esse|este|aquele|do|no|desse|nesse|pelo)\s+(segredo|truque)\b', re.I)


def campo_briefing(pasta: Path, campo: str) -> str:
    """Um campo de trabalho/00_briefing.md (Helena): "Serviço", "Palavra para comentar", "Autoridade"…"""
    arq = pasta / 'trabalho' / '00_briefing.md'
    if not arq.exists():
        return ''
    m = re.search(r'^\W*' + re.escape(campo) + r'\W*:\W*(.+?)\s*$', arq.read_text(encoding='utf-8'), re.M | re.I)
    v = m.group(1).strip(' *_`"“”.') if m else ''
    return '' if not v or 'confirmar' in v.lower() or v.startswith('<') else v


def _sem_acento(t: str) -> str:
    import unicodedata
    return ''.join(c for c in unicodedata.normalize('NFD', t.lower()) if unicodedata.category(c) != 'Mn')


def _num(p: str) -> str:
    return re.sub(r'[^0-9,]', '', p.replace('.', ',')).rstrip(',')


GENERICO = [
    (r'^\W*(\d+|dois|duas|tr[eê]s|quatro|cinco|seis|sete|oito|nove|dez)\s+(problemas|dicas|erros|coisas|motivos|passos|segredos|maneiras|formas|h[aá]bitos|li[cç][oõ]es)\b', 'é uma lista genérica ("N problemas/dicas…")'),
    (r'^\W*voc[eê] sabia', 'começa com "você sabia"'),
    (r'^\W*(oi|ol[aá]|e a[ií]|fala|bom dia|boa tarde|boa noite|pessoal|gente)\b', 'começa com cumprimento'),
    (r'\b(hoje|aqui) (eu )?(vou|quero|vim|trago)\b|\b(neste|nesse) v[ií]deo\b', 'anuncia o vídeo em vez de começar'),
    (r'\b(vai mudar tudo|muito importante|voc[eê] precisa saber|ningu[eé]m te conta|not[ií]cia (importante|bomb[aá]stica))\b', 'promete sem dizer o fato'),
]
NUM_PALAVRA = re.compile(r'\b(zero|um|uma|dois|duas|tr[eê]s|quatro|cinco|seis|sete|oito|nove|dez|onze|doze|treze|catorze|quatorze|quinze|'
                         r'dezesseis|dezessete|dezoito|dezenove|vinte|trinta|quarenta|cinquenta|sessenta|setenta|oitenta|noventa|cem|cento|'
                         r'duzent\w+|trezent\w+|quatrocent\w+|quinhent\w+|seiscent\w+|setecent\w+|oitocent\w+|novecent\w+|mil|milh[aã]o|milh[oõ]es|'
                         r'bilh[aã]o|bilh[oõ]es|metade|dobro|triplo|ter[cç]o|quarto)\b', re.I)


def _frase1(t: str) -> str:
    t = ' '.join(_limpa(t).split())
    m = re.match(r'(.+?[.!?])(\s|$)', t)
    return (m.group(1) if m else t).strip()


def _norm(t: str) -> str:
    return re.sub(r'[^a-z0-9 ]', '', _sem_acento(t)).strip()


def problemas_gancho(onde: str, g: str, noticia: dict, limite: int = 12) -> list[str]:
    """Um gancho é reprovado se é genérico, comprido ou sem nada específico da notícia."""
    achados = []
    if not g:
        return [f'{onde}: falta o gancho.']
    for padrao, motivo in GENERICO:
        if re.search(padrao, g, re.I):
            achados.append(f'{onde}: gancho genérico, {motivo} -> "{g}". Comece pelo fato da notícia: quem, quanto, quando.')
    n = len(re.findall(r'\w+', g))
    if n > limite:
        achados.append(f'{onde}: gancho com {n} palavras (máximo {limite}) -> "{g}"')
    nomes = [_sem_acento(x) for x in (noticia.get('nomes') or []) if len(x) > 2]
    gs = _sem_acento(g)
    if not (re.search(r'\d', g) or NUM_PALAVRA.search(g) or any(x in gs for x in nomes)):
        achados.append(f'{onde}: gancho sem nada específico (nenhum número e nenhum nome da notícia) -> "{g}"')
    return achados


def problemas_roteiro(pasta: Path, partes: list[str] | None = None) -> list[str]:
    """As regras do formato "notícia da semana":
    - existe a notícia escolhida (noticia.json), com data dentro de 7 dias do pedido (14 se a semana foi fraca e isso está dito);
    - os ganchos de cada peça são específicos e curtos; a 1.ª frase do Reels e da animação é o gancho, tal e qual;
    - todo percentual escrito (47%) ou falado (… por cento) nas peças é um dos de noticia.json;
    - a fala do Reels diz a fonte, tem de 80 a 130 palavras e nenhuma frase com mais de 16;
    - a fala dos vídeos e as legendas dos posts convidam a mandar mensagem no Direct; o dono não aparece em terceira pessoa;
    - nenhuma fala aponta para "a ideia", "a solução"… sem dizer qual; animação com no máximo 12 falas."""
    import datetime as dt
    t = pasta / 'trabalho'
    quer = lambda p: not partes or p in partes  # noqa: E731
    achados = []
    noticia = _json(t / 'noticia.json') or {}
    gancho_legado = _json(t / 'gancho.json') or {}
    formatos = {
        'reels': ('reels_falado', 12, 'fala.txt'),
        'animacao': ('animacao_abertura', 14, 'animacao.json'),
        'cartelas': ('carrossel_capa', 10, 'cartelas.json'),
        'estatico': ('estatico_titulo', 10, 'estatico.json'),
    }
    ganchos = {}
    if (t / '00_briefing.md').exists() and not noticia:
        achados.append('falta trabalho/noticia.json (a notícia escolhida pela Beatriz): sem ela não há peça.')
    if noticia:
        try:
            d = dt.date.fromisoformat(str(noticia.get('data', ''))[:10])
            ini = (t / 'inicio.txt').read_text().strip()[:10] if (t / 'inicio.txt').exists() else ''
            hoje = dt.date.fromisoformat(ini) if ini else dt.date.today()
            idade = (hoje - d).days
            folga = 14 if (_json(t / 'noticias.json') or {}).get('observacao') else 7
            if idade > folga:
                achados.append(f'noticia.json: a notícia é de {d.isoformat()}, {idade} dias antes do pedido. Vale só a dos últimos {folga} dias.')
            if idade < -1:
                achados.append(f'noticia.json: data no futuro ({d.isoformat()}). Confira a data na página.')
        except ValueError:
            achados.append('noticia.json: falta a "data" da notícia no formato AAAA-MM-DD (a que está escrita na página).')
        if not str(noticia.get('link', '')).startswith('http'):
            achados.append('noticia.json: falta o "link" da notícia.')
    for parte, (campo, limite, roteiro) in formatos.items():
        if not (quer(parte) or partes == ['gancho']):
            continue
        arquivo = t / f'gancho_{parte}.json'
        dados = _json(arquivo) or {}
        ganchos[parte] = dados.get(campo, '') if arquivo.exists() else gancho_legado.get(campo, '')
        if noticia and (arquivo.exists() or (t / roteiro).exists() or partes == ['gancho']):
            fonte = arquivo.name if arquivo.exists() or not gancho_legado else 'gancho.json'
            achados += problemas_gancho(f'{fonte} ({campo})', ganchos[parte], noticia, limite)

    numeros = noticia.get('numeros') or []
    escritos = {_num(str(d.get('valor', ''))) for d in numeros if isinstance(d, dict) and '%' in str(d.get('valor', ''))}
    falados = [_sem_acento(d['por_extenso']) for d in numeros if isinstance(d, dict) and d.get('por_extenso')]
    for onde, txt in textos(pasta, partes):
        for m in re.finditer(r'(\d+(?:[.,]\d+)?)\s*%', txt):
            if noticia and _num(m.group(1)) not in escritos:
                achados.append(f'{onde}: percentual {m.group(0)} não está em noticia.json. Use só os números da notícia -> "{_trecho(txt, m.start())}"')
        for m in re.finditer(r'por cento', txt, re.I):
            trecho = _sem_acento(txt[max(0, m.start() - 60):m.end()])
            if noticia and not any(f in trecho for f in falados):
                achados.append(f'{onde}: percentual falado que não bate com o "por_extenso" de noticia.json -> "{_trecho(txt, max(0, m.start() - 30))}"')

    roteiros = []
    if quer('reels') and (t / 'fala.txt').exists():
        fala = (t / 'fala.txt').read_text(encoding='utf-8')
        roteiros.append(('fala do Reels', [('', ln) for ln in fala.splitlines() if ln.strip()]))
        g = ganchos.get('reels', '')
        if g and _norm(_frase1(fala)) != _norm(_frase1(g)) and not _norm(fala).startswith(_norm(g)):
            achados.append(f'fala do Reels: a 1.ª frase difere do gancho registrado. Está "{_frase1(fala)}"; devia ser "{g}".')
        elif not g:
            achados += problemas_gancho('fala do Reels (1.ª frase)', _frase1(fala), noticia, 12)
        n = len(re.findall(r'\w+', fala))
        if n > 130 or n < 80:
            achados.append(f'fala do Reels: {n} palavras. O Reels tem de 100 a 125 (35 a 45 s).')
        for fr in re.split(r'(?<=[.!?])\s+', ' '.join(fala.split())):
            if len(re.findall(r'\w+', fr)) > 18:
                achados.append(f'fala do Reels: frase comprida demais (máximo 16 palavras), parta em duas -> "{fr[:90]}"')
        v = _sem_acento(noticia.get('veiculo', ''))
        ff = _sem_acento(re.sub(r'^\s*segundo\s+(o|a|os|as)?\s*', '', noticia.get('fonte_falada', ''), flags=re.I))
        if noticia and not any(x and x in _sem_acento(fala) for x in (v, ff)):
            achados.append(f'fala do Reels: não diz de onde veio a notícia ("{noticia.get("fonte_falada", "segundo …")}").')
    if quer('animacao') and (a := _json(t / 'animacao.json')):
        falas = [(f.get('id', ''), _limpa(f.get('texto', ''))) for f in a.get('falas', [])]
        roteiros.append(('animação', falas))
        g = ganchos.get('animacao', '')
        if g and falas and not _norm(falas[0][1]).startswith(_norm(_frase1(g))[:40]):
            achados.append(f'animação: a 1.ª fala difere do gancho registrado. Está "{falas[0][1]}"; devia ser "{g}".')
    if quer('cartelas') and (c := _json(t / 'cartelas.json')) and (g := ganchos.get('cartelas')):
        if _norm(str(c[0].get('texto', ''))) != _norm(g):
            achados.append(f'cartela 1: a capa difere do gancho. Está "{c[0].get("texto")}"; devia ser "{g}".')
    if quer('estatico') and (e := _json(t / 'estatico.json')) and (g := ganchos.get('estatico')):
        if _norm(str(e.get('texto', ''))) != _norm(g):
            achados.append(f'estático: o título difere do gancho. Está "{e.get("texto")}"; devia ser "{g}".')

    nome = (ler_nome_dono() or '').split()
    for onde, falas in roteiros:
        tudo = _sem_acento(' '.join(x for _, x in falas))
        if not re.search(r'\bme chama no direct\b', tudo):
            achados.append(f'{onde}: termine com o convite para chamar no Direct.')
        if onde == 'fala do Reels' and nome and re.search(r'\bo ' + re.escape(_sem_acento(nome[0])) + r'\b', tudo):
            achados.append(f'fala do Reels: o dono aparece em terceira pessoa ("o {nome[0]}"). Quem fala é ele: use "eu".')
        for fid, txt in falas:
            if m := VAGO.search(txt):
                achados.append(f'{onde} {fid}: "{m.group(0)}" sem dizer qual. Troque pelo nome e pelo que é -> "{_trecho(txt, m.start())}"')
        if onde == 'animação' and len(falas) > 10:
            achados.append(f'animação: {len(falas)} falas. O máximo é 10 (35 a 50 s): corte enfeite, nunca o fato central nem a fonte.')
    for parte, arquivo in (('cartelas', '05_carrossel.md'), ('estatico', '07_estatico.md')):
        if quer(parte) and (t / arquivo).is_file():
            legenda = _legenda_post(t / arquivo)
            if not re.search(r'\bme chama no direct\b', _sem_acento(legenda)):
                achados.append(f'{arquivo}: inclua “Me chama no Direct” na legenda.')
    return achados


def ler_nome_dono() -> str:
    t = CONTEXTO_PADRAO.read_text(encoding='utf-8') if CONTEXTO_PADRAO.exists() else ''
    m = re.search(r'^\W*Nome\W*:\W*(.+?)\s*$', t, re.M)
    return re.sub(r'\(.*?\)', '', m.group(1)).strip(' *') if m else ''


def problemas(pasta: Path, partes: list[str] | None = None) -> list[str]:
    proibidas = palavras_proibidas()
    achados = problemas_roteiro(pasta, partes)
    for onde, txt in textos(pasta, partes):
        sem_links = re.sub(r'https?://\S+|#[\w]+', '', txt)
        if re.search(r'(?<!\w)(?:IA|I\.A\.?|AI|A\.I\.?|CEO|RH|CRM|ROI|B2B|B2C)(?!\w)', sem_links):
            achados.append(f'{onde}: escrever siglas por extenso antes de gerar voz ou imagem (por exemplo, inteligência artificial).')
        for padrao, motivo in PADROES:
            if m := re.search(padrao, txt, re.I | re.M):
                achados.append(f'{onde}: {motivo} -> "{_trecho(txt, m.start())}"')
        for p in proibidas:
            if re.search(r'(?<!\w)' + re.escape(p) + r'(?!\w)', txt, re.I):
                achados.append(f'{onde}: palavra proibida no CONTEXTO "{p}" -> "{_trecho(txt, txt.lower().find(p.lower()))}"')
    return achados


def _trecho(txt: str, i: int) -> str:
    i = max(0, i)
    return ' '.join(txt[max(0, i - 30):i + 50].split())


def checar(pasta: Path, partes: list[str] | None = None) -> None:
    """Para o script (sys.exit) se houver problema, com a lista do que corrigir."""
    achados = problemas(pasta, partes)
    if achados:
        sys.exit('REVISÃO: corrija o texto em trabalho/ e rode de novo.\n  ' + '\n  '.join(achados))


if __name__ == '__main__':
    pasta = Path(sys.argv[1]).resolve()
    partes = sys.argv[2:] or None
    achados = problemas(pasta, partes)
    if achados:
        print('REVISÃO: corrija o texto em trabalho/ e rode de novo o render da peça afetada.')
        print('\n'.join('  ' + a for a in achados))
        sys.exit(1)
    print('Revisão dos textos: nada a corrigir.')
