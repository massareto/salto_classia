"""Motion graphics narrado em Remotion, com visuais desenhados em código.

Uso: animacao.py voz <pasta> | duracao <pasta> | quadros <pasta> [cena] | render <pasta> | tudo <pasta>
O roteiro usa cenas tipo motion com planos gráficos ou o formato ilustracao de um só plano.
"""
import json
import math
import os
import re
import shutil
import subprocess
import sys
import wave
from pathlib import Path

import numpy as np

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
from contexto import CHAMADA_DIRECT, esperar_instalacao, ler_contexto  # noqa: E402
from trilha_heygen import validar_duracao  # noqa: E402

KIT = AQUI.parent / 'animacao'
MODELO_REMOTION = AQUI.parent / 'remotion'
FPS = 30
SR = 48000
LEAD, GAP, TAIL = 6, 10, 14
MAX_CH = 40
VISUAIS = {
    'universidade', 'bussola', 'caminhos', 'caderno', 'valores', 'constelacao',
    'pergunta', 'convite', 'relacao', 'indicador', 'barras', 'processo',
}
TEXTO_MOTION = {
    'titulo', 'subtitulo', 'rotulo', 'chamada', 'palavra', 'informacao', 'assinatura',
    'rodapeVisual', 'medida', 'numero', 'periodo', 'origem', 'origem_dado', 'origem_glyph',
    'destino', 'destino_dado', 'destino_glyph',
}
CAMPOS_MOTION = TEXTO_MOTION | {'visual', 'tamanhoTitulo', 'rotulos', 'itens', 'barras'}


def limpa(t: str) -> str:
    return re.sub(r'\[[^\]]*\]\s*', '', t).strip()


def preparar(dest: Path, dados: dict) -> Path:
    esperar_instalacao(MODELO_REMOTION)
    if not (MODELO_REMOTION / 'node_modules' / 'remotion').exists():
        subprocess.run(['npm', 'install', '--silent'], cwd=MODELO_REMOTION, check=True)
    proj = dest
    shutil.copytree(KIT / 'src', proj / 'src', dirs_exist_ok=True)
    shutil.copy(MODELO_REMOTION / 'package.json', proj / 'package.json')
    nm = proj / 'node_modules'
    if not nm.exists():
        nm.symlink_to(MODELO_REMOTION / 'node_modules')
    (proj / 'src' / 'dados.json').write_text(json.dumps(dados, ensure_ascii=False), encoding='utf-8')
    return proj


# ---------------------------------------------------------------- voz
def cmd_voz(pasta: Path) -> None:
    from heygen_voz import preparar, validar
    preparar(pasta)
    try: validar(pasta)
    except ValueError as e: sys.exit(str(e) + '\nPedido MCP: trabalho/heygen-pedido-voz.json. Não há fallback para outro provedor.')


def alinhamento_estimado(texto: str, mp3: Path) -> dict:
    """Tempo de cada caractere distribuído pela duração do áudio, com peso maior na pontuação.
    Usado quando a voz veio sem timestamps (ex.: conector do ElevenLabs no Manus)."""
    dur = float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', str(mp3)]).decode().strip())
    chars = list(texto)
    peso = [0] * len(chars)
    dentro = False
    for i, ch in enumerate(chars):
        if ch == '[':
            dentro = True
        peso[i] = 0 if dentro else (6 if ch in '.?!' else 3 if ch in ',:;' else 1)
        if ch == ']':
            dentro = False
    total = sum(peso) or 1
    ini, fim, t = [], [], 0.05
    util = max(0.1, dur - 0.15)
    for w in peso:
        ini.append(round(t, 3)); t += util * w / total; fim.append(round(t, 3))
    return {'characters': chars, 'character_start_times_seconds': ini, 'character_end_times_seconds': fim}


# ---------------------------------------------------------------- linha do tempo
def trechos(al: dict) -> list[dict]:
    """Legendas de até MAX_CH caracteres, equilibradas, sem as marcações [tag]."""
    bruto = ''.join(al['characters'])
    fora = set()
    for m in re.finditer(r'\[[^\]]*\]\s*', bruto):
        fora.update(range(m.start(), m.end()))
    idx = [i for i in range(len(bruto)) if i not in fora]
    txt = ''.join(bruto[i] for i in idx)
    words = [(m.start(), m.end()) for m in re.finditer(r'\S+', txt)]
    if not words:
        return []
    n = max(1, math.ceil(len(txt.strip()) / MAX_CH))
    cortes = []
    for k in range(1, n):
        alvo = len(txt) * k / n
        best = min(range(1, len(words)), key=lambda i: abs(words[i - 1][1] - alvo) - (8 if re.search(r'[.?!:,]$', txt[words[i - 1][0]:words[i - 1][1]]) else 0))
        cortes.append(best)
    grupos, ini = [], 0
    for c in sorted(set(cortes)) + [len(words)]:
        if words[ini:c]:
            grupos.append(words[ini:c])
        ini = c
    return [{'texto': txt[g[0][0]:g[-1][1]], 'ini': al['character_start_times_seconds'][idx[g[0][0]]]} for g in grupos]


PROIBIDO = re.compile(r'\b(neste|nesse|num|no|por) exemplo\b|exemplo fict[ií]cio|\bhipot[ée]tic|\bimagine\b', re.I)
PROIBIDO_TELA = re.compile(r'exemplo|fict[ií]ci|hipot[ée]tic|imagine', re.I)  # em rótulos, etiquetas, carimbos e balões


def conferir_plano(plano: dict) -> list[str]:
    extras = plano.keys() - CAMPOS_MOTION
    if extras:
        return ['Campos sem suporte em motion: ' + ', '.join(sorted(extras))]
    erros = []
    visual = plano.get('visual')
    if not isinstance(visual, str) or visual not in VISUAIS:
        erros.append('Escolha um visual implementado em código.')
    for campo in TEXTO_MOTION & plano.keys():
        valor = plano[campo]
        if campo == 'rotulo' and isinstance(valor, dict) and valor.keys() == {'texto'}:
            valor = valor['texto']
        if not isinstance(valor, str):
            erros.append(f'{campo} precisa ser texto.')
        elif PROIBIDO_TELA.search(valor):
            erros.append(f'{campo}: use texto direto ligado à pauta.')
    titulo = plano.get('titulo')
    if not isinstance(titulo, str) or not titulo.strip() or len(titulo) > 110:
        erros.append('Título obrigatório, de até 110 caracteres.')
    tamanho = plano.get('tamanhoTitulo', 68)
    if not isinstance(tamanho, (int, float)) or not 36 <= tamanho <= 110:
        erros.append('tamanhoTitulo precisa estar entre 36 e 110.')
    if len(str(plano.get('subtitulo', ''))) > 100:
        erros.append('Subtítulo de até 100 caracteres.')
    if visual == 'convite' and not (plano.get('palavra') or plano.get('chamada')):
        erros.append('O convite gráfico precisa da chamada.')
    if len(str(plano.get('chamada', ''))) > 62:
        erros.append('Chamada gráfica de até 62 caracteres.')
    for campo in ('itens', 'rotulos'):
        if campo not in plano:
            continue
        valores = plano[campo]
        if not isinstance(valores, list) or not all(isinstance(v, str) for v in valores):
            erros.append(f'{campo} precisa ser uma lista de textos.')
    itens = plano.get('itens')
    if visual == 'processo' and (not isinstance(itens, list) or not 2 <= len(itens) <= 4):
        erros.append('Processo precisa de duas a quatro etapas em itens.')
    if visual == 'barras':
        barras = plano.get('barras')
        if not isinstance(barras, list) or not 2 <= len(barras) <= 4 or not all(
            isinstance(barra, dict) and barra.keys() <= {'rotulo', 'valor', 'exibicao'}
            and isinstance(barra.get('rotulo'), str)
            and isinstance(barra.get('valor'), (int, float)) and math.isfinite(barra['valor'])
            and barra['valor'] >= 0 and isinstance(barra.get('exibicao', ''), str)
            for barra in barras
        ):
            erros.append('Barras precisa de dois a quatro valores não negativos com rótulo.')
    return erros


def conferir_roteiro(roteiro: dict) -> None:
    erros = []
    for f in roteiro['falas']:
        if PROIBIDO.search(limpa(f['texto'])):
            erros.append(f"{f['id']}: conte direto: {limpa(f['texto'])}")
        if len(f.get('hl', '').split()) > 3:
            erros.append(f"{f['id']}: use no máximo três palavras no destaque.")
    for i, cena in enumerate(roteiro['cenas'], 1):
        if cena.get('tipo') == 'motion' and cena.keys() <= {'tipo', 'falas', 'planos'}:
            planos = cena.get('planos')
        elif cena.get('tipo') == 'ilustracao':
            planos = [{k: v for k, v in cena.items() if k not in ('tipo', 'falas')}]
        else:
            erros.append(f'Cena {i}: use motion com planos desenhados em código. Converta montagens, fotos e clipes em gráficos animados.')
            continue
        if not isinstance(planos, list) or not planos or not all(isinstance(p, dict) for p in planos):
            erros.append(f'Cena {i}: liste os planos de motion como objetos.')
            continue
        anterior = None
        for j, plano in enumerate(planos, 1):
            erros += [f'Cena {i}, plano {j}: {erro}' for erro in conferir_plano(plano)]
            if plano == anterior:
                erros.append(f'Cena {i}, plano {j}: mude a ação, composição ou informação do plano anterior.')
            anterior = plano
    if erros:
        sys.exit('Roteiro da animação (trabalho/animacao.json) precisa de ajuste:\n  ' + '\n  '.join(erros))


def tempos_planos(planos: list[dict], duracao: int) -> list[dict]:
    minimo = math.ceil(duracao / (2 * FPS))
    if len(planos) < minimo:
        raise ValueError(f'Cena com {duracao / FPS:.1f} s: inclua pelo menos {minimo} planos distintos para mudar a tela em até 2 s.')
    if len(planos) > duracao:
        raise ValueError('Há mais planos do que fotogramas nesta cena.')
    return [dict(plano, inicio=i * duracao // len(planos)) for i, plano in enumerate(planos)]


def montar(pasta: Path) -> dict:
    from heygen_voz import validar
    validar(pasta)
    roteiro = json.loads((pasta / 'trabalho' / 'animacao.json').read_text(encoding='utf-8'))
    idioma = roteiro.get('idioma', 'pt')
    dvoz = pasta / 'trabalho' / 'animacao' / 'voz'
    falas = {f['id']: f for f in roteiro['falas']}
    al = {}
    for fid, f in falas.items():
        meta = dvoz / f'{fid}.json'
        if not meta.exists() and (dvoz / f'{fid}.mp3').exists():
            meta.write_text(json.dumps({'texto': f['texto'], 'alignment': alinhamento_estimado(f['texto'], dvoz / f'{fid}.mp3'), 'estimado': True}, ensure_ascii=False), encoding='utf-8')
            print(f'{fid}: sem o tempo de cada letra; estimado pela duração do áudio (legenda pode atrasar uns décimos)')
        al[fid] = json.loads(meta.read_text())['alignment']
    durf = {fid: math.ceil(a['character_end_times_seconds'][-1] * FPS) for fid, a in al.items()}

    for cena in roteiro['cenas']:
        planos = cena.get('planos') if cena.get('tipo') == 'motion' else [cena]
        if isinstance(planos, list):
            for plano in planos:
                if isinstance(plano, dict) and plano.get('visual') == 'convite':
                    plano['chamada'] = CHAMADA_DIRECT
                    plano.pop('palavra', None)
    conferir_roteiro(roteiro)
    from revisao import checar
    checar(pasta, ['animacao'])
    cenas, faladas, legendas, cursor = [], [], [], 0
    for cena in roteiro['cenas']:
        fim_falas = 0
        pos = {}
        for fid in cena.get('falas', []):
            inicio = fim_falas + GAP if pos else LEAD
            fim_falas = inicio + durf[fid]
            pos[fid] = (inicio, fim_falas)

        dur = max(fim_falas + TAIL, 45)
        if cena['tipo'] == 'motion':
            try:
                planos = tempos_planos(cena['planos'], dur)
            except ValueError as exc:
                sys.exit(f'Cena {len(cenas) + 1}: {exc}')
        else:
            planos = [dict(cena, inicio=0)]
        c = {'from': cursor, 'to': cursor + dur, 'planos': planos}
        if len(cenas) == len(roteiro['cenas']) - 1 and planos[-1].get('visual') != 'convite':
            c['chamada_final'] = CHAMADA_DIRECT
        cenas.append(c)
        for fid, (a, b) in pos.items():
            faladas.append({'id': fid, 'from': cursor + a, 'to': cursor + b, 'arquivo': str(dvoz / f'{fid}.mp3')})
            for t in trechos(al[fid]):
                hl = falas[fid].get('hl', '')
                legendas.append({'from': cursor + a + round(t['ini'] * FPS), 'texto': t['texto'],
                                 'hl': hl if hl and hl in t['texto'] else '', 'fimFala': cursor + b})
        cursor += dur

    for i, l in enumerate(legendas):
        nxt = legendas[i + 1]['from'] if i + 1 < len(legendas) else cursor
        l['to'] = min(nxt, max(l['fimFala'] + 12, l['from'] + 30)) if nxt - l['fimFala'] > 20 else nxt
        del l['fimFala']
    if cursor / FPS > 55:
        print(f'Aviso: a animação tem {cursor / FPS:.0f} s. O formato é de 35 a 50 s: corte falas.')
    ctx = ler_contexto()
    return {
        'fps': FPS, 'total': cursor, 'idioma': idioma, 'acento': ctx['cores'].get('acento'), 'instagram': ctx.get('instagram', ''),
        'nome': ctx.get('nome', ''), 'cores': ctx.get('cores', {}),
        'cenas': cenas, 'legendas': legendas, 'falas': faladas,
    }


# ---------------------------------------------------------------- mixagem
def put(buf, t0, sig, g):
    i = int(t0 * SR)
    if i < 0 or i >= len(buf):
        return
    j = min(len(buf), i + len(sig))
    buf[i:j] += sig[: j - i] * g


def mixar(dados: dict, destino: Path) -> Path:
    faixa = destino.parent.parent / 'musica_animacao.wav'
    segundos = dados['total'] / FPS
    n = round(segundos * SR)
    voz = np.zeros(n)
    for f in dados['falas']:
        raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', f['arquivo'], '-ac', '1', '-ar', str(SR),
                              '-f', 's16le', '-'], capture_output=True, check=True).stdout
        put(voz, f['from'] / FPS, np.frombuffer(raw, dtype=np.int16) / 32768.0, 1.0)
    mix = voz
    detalhes = {'musica': None, 'peak_limit': .89}
    if faixa.is_file() and faixa.stat().st_size:
        from scipy.ndimage import uniform_filter1d

        validar_duracao(faixa, segundos)
        audio = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(faixa),
                                '-vn', '-t', f'{segundos:.6f}', '-ac', '1', '-ar', str(SR),
                                '-f', 's16le', '-'], capture_output=True)
        if audio.returncode or len(audio.stdout) != n * 2:
            sys.exit('A faixa da animação está inválida. Baixe novamente a faixa do HeyGen ou escolha outra.')
        musica = np.frombuffer(audio.stdout, dtype=np.int16) / 32768.0
        mrms = np.sqrt(np.mean(musica**2))
        if mrms < 1e-6:
            sys.exit('A faixa da animação está silenciosa. Escolha outra faixa no catálogo do HeyGen.')

        # Ducking suave para a música acompanhar a voz sem cobrir sílabas.
        ativo = uniform_filter1d((np.abs(voz) > .015).astype(float), max(1, int(.18 * SR))) > .015
        duck = uniform_filter1d(np.where(ativo, .42, 1.), max(1, int(.1 * SR)))
        vrms = np.sqrt(np.mean(voz[ativo]**2)) if ativo.any() else .12
        mix_db = -20
        nivel = 10 ** (mix_db / 20)
        fade = min(n // 2, SR // 2)
        musica = musica.copy()
        musica[:fade] *= np.linspace(0, 1, fade)
        musica[n - fade:] *= np.linspace(1, 0, fade)
        mix = voz + musica / mrms * vrms * nivel * duck
        detalhes.update(musica=str(faixa), mix_db_relativo_voz=mix_db, duck_sob_voz=.42)
    peak = max(1., float(np.max(np.abs(mix))) / .89)
    mix /= peak
    pcm = (np.stack([mix, mix], axis=1) * 32767).astype(np.int16)
    with wave.open(str(destino), 'wb') as wav:
        wav.setnchannels(2)
        wav.setsampwidth(2)
        wav.setframerate(SR)
        wav.writeframes(pcm.tobytes())
    (destino.parent / 'mix.json').write_text(json.dumps(detalhes, indent=2), encoding='utf-8')
    return destino


# ---------------------------------------------------------------- render
def modelo_whisper() -> Path | None:
    for p in [Path.home() / 'Library/Application Support/com.seewillow.WillowMac/OfflineModel/ggml-large-v3-turbo.bin',
              *(Path.home() / '.cache').glob('**/ggml-*.bin')]:
        if p.exists():
            return p
    return None


def preparar_animacao(pasta: Path, dados: dict) -> Path:
    trab = pasta / 'trabalho' / 'animacao'
    proj = preparar(trab / 'remotion', dados)
    (trab / 'timeline.json').write_text(json.dumps(dados, ensure_ascii=False, indent=1), encoding='utf-8')
    return proj


def cmd_quadros(pasta: Path, cena: int | None) -> None:
    dados = montar(pasta)
    cenas = list(enumerate(dados['cenas'], 1))
    if cena is not None:
        cenas = [(i, c) for i, c in cenas if i == cena]
        if not cenas:
            sys.exit(f'Cena {cena} fora da timeline.')
    proj = preparar_animacao(pasta, dados)
    destino = pasta / 'entrega' / 'fotogramas'
    destino.mkdir(parents=True, exist_ok=True)
    for i, c in cenas:
        frame = (c['from'] + c['to'] - 1) // 2
        subprocess.run(['npx', 'remotion', 'still', 'src/index.ts', 'Animacao',
                        str(destino / f'animacao-cena-{i:02d}.png'), f'--frame={frame}', '--log=error'],
                       cwd=proj, check=True)


def cmd_render(pasta: Path) -> None:
    dados = montar(pasta)
    proj = preparar_animacao(pasta, dados)
    trab = proj.parent
    trilha = mixar(dados, trab / 'trilha.wav')
    mudo = trab / 'animacao_mudo.mp4'
    subprocess.run(['npx', 'remotion', 'render', 'src/index.ts', 'Animacao', str(mudo), '--log=error', '--crf=14',
                    '--x264-preset=veryfast', f'--concurrency={max(1, min(6, (os.cpu_count() or 2)))}'], cwd=proj, check=True)
    (pasta / 'entrega' / 'fotogramas').mkdir(parents=True, exist_ok=True)
    saida = pasta / 'entrega' / 'animacao.mp4'
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(mudo), '-i', str(trilha), '-map', '0:v', '-map', '1:a', '-c:v', 'copy',
                    '-af', 'loudnorm=I=-14:TP=-1.5:LRA=11', '-ar', '48000', '-c:a', 'aac', '-b:a', '192k', '-shortest', str(saida)], check=True)
    total = dados['total'] / FPS
    for t in (0.15 * total, 0.5 * total, 0.85 * total):
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', f'{t:.2f}', '-i', str(saida), '-frames:v', '1', '-vf', 'scale=540:-1',
                        str(pasta / 'entrega' / 'fotogramas' / f'animacao_{t:.1f}s.png')], check=True)
    m = modelo_whisper()
    if m and shutil.which('whisper-cli'):
        linhas = []
        for f in dados['falas']:
            wav = trab / 'conferencia_16k.wav'
            subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', f['arquivo'], '-ac', '1', '-ar', '16000', str(wav)], check=True)
            r = subprocess.run(['whisper-cli', '-m', str(m), '-l', dados['idioma'], '-f', str(wav), '-np', '-nt'], capture_output=True, text=True)
            linhas.append(f"{f['id']}: {' '.join(r.stdout.split())}")
        wav.unlink(missing_ok=True)
        (pasta / 'trabalho' / 'animacao_transcricao.txt').write_text('\n'.join(linhas) + '\n', encoding='utf-8')
    print(f'Animação: {saida} ({total:.1f}s, {len(dados["cenas"])} cenas, {len(dados["legendas"])} legendas)')


if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    acao = sys.argv[1]
    alvo = Path(sys.argv[2]).resolve()
    if acao == 'duracao':
        print(f"{montar(alvo)['total'] / FPS:.6f}")
    if acao in ('voz', 'tudo'):
        cmd_voz(alvo)
    if acao == 'quadros':
        cmd_quadros(alvo, int(sys.argv[3]) if len(sys.argv) > 3 else None)
    if acao in ('render', 'tudo'):
        cmd_render(alvo)
