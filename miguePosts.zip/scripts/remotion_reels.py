"""Diego Matos: prepara e renderiza o Reels em Remotion.

Uso:
  python3 remotion_reels.py base "<pasta da peça>"   # painel e trilha no tempo do clipe
  python3 remotion_reels.py final "<pasta da peça>"  # Reel editado com a fala original

Precisa de:
  <pasta>/entrega/video/avatar.webm ou avatar.mp4, vídeo falado retornado pelo MCP HeyGen
  <pasta>/trabalho/reels_cenas.json          (escrito pelo Diego), por exemplo:
    {
      "cenas": [
        {"tipo": "texto", "texto": "Seu próximo passo", "icone": "relogio"},
        {"tipo": "texto", "quando": "Os números mostram", "texto": "Quanto mudou",
         "barras": [{"rotulo": "Antes", "valor": 12}, {"rotulo": "Depois", "valor": 18}]}
      ],
      "destaques": ["mudou"]
    }

Cada cena usa um ícone desenhado em código ou duas a quatro barras animadas com dados.
Use "quando" para alinhar a cena a palavras da legenda. Em "batidas", altere visual,
número, texto ou destaque. O painel não aceita fotografias, imagens ou clipes.
Use "avatar_fx" e "avatar_fy" no roteiro para enquadrar o vídeo do apresentador.

Entrega: <pasta>/entrega/reels.mp4 (1080x1920, 30 fps, fala do HeyGen + música quando disponível) e <pasta>/entrega/fotogramas/reels_*.png (3 fotogramas para mostrar).
"""
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
from contexto import CHAMADA_DIRECT, RAIZ, esperar_instalacao, ler_contexto  # noqa: E402
from trilha_heygen import validar_duracao  # noqa: E402

MODELO = AQUI.parent / 'remotion'
FPS = 30
CARD, R = {'x': 40, 'y': 1110, 'w': 1000, 'h': 770}, 48  # card do avatar (igual a remotion/src/config.ts)
# Nomes dos ícones desenhados em código (remotion/src/icones.tsx).
ICONES = re.findall(r'^\t(\w+): \{d:', (MODELO / 'src' / 'icones.tsx').read_text(encoding='utf-8'), re.M)


def copiar_imagem(pasta: Path, caminho: str, pub: Path, nome: str) -> tuple[str, float]:
    """Copia uma imagem da peça (ou de fotos-coach) para public/ e devolve o nome e a proporção."""
    orig = (pasta / caminho) if not Path(caminho).is_absolute() else Path(caminho)
    if not orig.exists():
        orig = RAIZ / caminho
    if not orig.exists():
        sys.exit(f'Imagem não encontrada: {caminho} (caminho dentro da pasta da peça, ex.: trabalho/imagens/carrossel_01.png)')
    with Image.open(orig) as im:
        im = im.convert('RGB')
        if max(im.size) > 2400:
            im.thumbnail((2400, 2400))
        destino = pub / (nome + '.jpg')
        im.save(destino, quality=92)
        return destino.name, im.width / im.height


def preparar_projeto(pasta: Path, ctx: dict, nome: str = 'remotion') -> Path:
    """Copia o modelo Remotion para <pasta>/trabalho/<nome> e liga o node_modules do modelo.

    Cada frente tem o seu projeto (Reels: remotion; carrossel: remotion_carrossel; estático: remotion_estatico),
    para os três renderizarem ao mesmo tempo sem um reescrever os arquivos do outro."""
    esperar_instalacao(MODELO)
    if not (MODELO / 'node_modules' / 'remotion').exists():
        subprocess.run(['npm', 'install', '--silent'], cwd=MODELO, check=True)
    proj = pasta / 'trabalho' / nome
    (proj / 'public').mkdir(parents=True, exist_ok=True)
    shutil.copytree(MODELO / 'src', proj / 'src', dirs_exist_ok=True)
    shutil.copy(MODELO / 'package.json', proj / 'package.json')
    shutil.copy(MODELO / 'stills.mjs', proj / 'stills.mjs')
    nm = proj / 'node_modules'
    if not nm.exists():
        nm.symlink_to(MODELO / 'node_modules')
    if not (proj / 'reels.json').exists():  # o Root regista o Reels, que lê reels.json
        shutil.copy(MODELO / 'reels.exemplo.json', proj / 'reels.json')
    if ctx['selo']:
        shutil.copy(ctx['selo'], proj / 'public' / ('selo' + Path(ctx['selo']).suffix))
    return proj


def nome_selo(ctx: dict) -> str | None:
    return 'selo' + Path(ctx['selo']).suffix if ctx['selo'] else None


def ler_srt(caminho: Path) -> list[dict]:
    def seg(t):
        h, m, r = t.split(':')
        s, ms = r.split(',')
        return int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000

    blocos = []
    for b in re.split(r'\n\s*\n', caminho.read_text(encoding='utf-8-sig').replace('\r', '').strip()):
        linhas = b.split('\n')
        a, z = linhas[1].split(' --> ')
        blocos.append({'n': int(linhas[0]), 'ini': seg(a), 'fim': seg(z), 'texto': ' '.join(linhas[2:])})
    return blocos


def _pal(t: str) -> list[str]:
    import unicodedata
    t = unicodedata.normalize('NFD', t.lower())
    return re.findall(r'[a-z0-9]+', ''.join(ch for ch in t if unicodedata.category(ch) != 'Mn'))


def bloco_da_fala(blocos: list[dict], quando: str, depois_de: int) -> int | None:
    """N.º do bloco do SRT em que começam as palavras `quando` (trecho da fala), procurando depois do bloco `depois_de`."""
    fluxo = [(w, b['n']) for b in blocos if b['n'] > depois_de for w in _pal(b['texto'])]
    alvo = _pal(quando)
    for i in range(len(fluxo) - len(alvo) + 1):
        if [w for w, _ in fluxo[i:i + len(alvo)]] == alvo:
            return fluxo[i][1]
    return None


def achar_avatar(video: Path) -> Path | None:
    for nome in ('avatar.webm', 'avatar.mp4'):
        if (video / nome).exists():
            return video / nome
    return None


def medir_avatar(arq: Path) -> dict:
    """Duração, tamanho e topo da cabeça (mediana) a partir do canal alfa do WebM (MP4 = avatar sem recorte)."""
    dur = float(subprocess.check_output(
        ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', str(arq)]).strip())
    dec = ['-c:v', 'libvpx-vp9'] if arq.suffix == '.webm' else []
    with tempfile.TemporaryDirectory() as tmp:
        subprocess.run(['ffmpeg', '-v', 'error', '-y', *dec, '-i', str(arq), '-vf', 'fps=5',
                        f'{tmp}/f%03d.png'], check=True)
        topos, bases, cheios, tam = [], [], [], None
        for f in sorted(Path(tmp).glob('*.png')):
            im = Image.open(f).convert('RGBA')
            tam = im.size
            a = np.array(im)[:, :, 3] > 20
            cheios.append(a.mean())
            linhas = np.where(a.any(1))[0]
            if len(linhas):
                topos.append(int(linhas.min()))
                bases.append(int(linhas.max()))
    # Avatar sem recorte (fundo do cenário): o vídeo é opaco e vai inteiro dentro do card.
    opaco = not topos or float(np.median(cheios)) > 0.97
    return {'duracao': dur, 'srcW': tam[0], 'srcH': tam[1], 'topoCabeca': int(np.median(topos)) if topos else 0,
            'base': int(np.median(bases)) if bases else tam[1], 'opaco': opaco}


CAMPOS_VISUAIS = {'kicker', 'numero', 'texto', 'destaque', 'icone', 'barras'}
VERSAO_MOTION = 4


def campos_motion(passo: dict, nome: str, extras: set[str]) -> dict:
    desconhecidos = passo.keys() - CAMPOS_VISUAIS - extras
    if desconhecidos:
        sys.exit(f'{nome}: use motion em código. Campos sem suporte: {", ".join(sorted(desconhecidos))}.')
    visual = {k: passo[k] for k in CAMPOS_VISUAIS if k in passo}
    if 'icone' in visual:
        if visual['icone'] not in ICONES:
            sys.exit(f'{nome}: escolha um ícone implementado em código. Opções: {", ".join(ICONES)}.')
        if 'barras' in visual:
            sys.exit(f'{nome}: escolha um ícone ou um gráfico de barras.')
        visual['barras'] = None
    if 'barras' in visual and visual['barras'] is not None:
        barras = visual['barras']
        if not isinstance(barras, list) or not 2 <= len(barras) <= 4 or not all(
            isinstance(barra, dict) and barra.keys() <= {'rotulo', 'valor', 'exibicao'}
            and isinstance(barra.get('rotulo'), str)
            and isinstance(barra.get('valor'), (int, float)) and math.isfinite(barra['valor'])
            and barra['valor'] >= 0 and isinstance(barra.get('exibicao', ''), str)
            for barra in barras
        ):
            sys.exit(f'{nome}: indique de duas a quatro barras com rótulo e valor não negativo.')
        visual['icone'] = None
    return visual


def preparar(pasta: Path) -> tuple[dict, dict, Path, list[dict]]:
    """Alinha as cenas e os destaques à fala do clipe."""
    ctx = ler_contexto()
    plano = json.loads((pasta / 'trabalho' / 'reels_cenas.json').read_text(encoding='utf-8'))
    proj = preparar_projeto(pasta, ctx)
    pub = proj / 'public'
    srt_arq = pasta / 'trabalho' / 'legendas.srt'
    shutil.copy(srt_arq, pub / 'legendas.srt')
    blocos = ler_srt(srt_arq)
    por_n = {b['n']: b for b in blocos}

    cenas, anterior = [], 0
    for i, c in enumerate(plano['cenas']):
        if i == 0:
            n = blocos[0]['n']
        elif c.get('quando'):
            # o jeito seguro: as primeiras palavras da frase em que a cena entra, tal e qual na fala
            n = bloco_da_fala(blocos, c['quando'], anterior)
            if n is None:
                sys.exit(f"Cena {i + 1}: não achei \"{c['quando']}\" na legenda depois do bloco {anterior}. "
                         'Use 2 a 4 palavras seguidas da fala, na ordem em que são ditas.')
        else:
            n = c.get('bloco_srt')
            if n not in por_n:
                sys.exit(f"Cena {i + 1}: o bloco {n} não existe em {srt_arq.name} ({len(blocos)} blocos). "
                         'Prefira "quando": "<primeiras palavras da frase>" em vez do número do bloco.')
        if i and n <= anterior:
            sys.exit(f'Cena {i + 1}: entra no bloco {n}, antes ou junto da cena anterior (bloco {anterior}). As cenas seguem a ordem da fala.')
        anterior = n
        inicio = 0 if i == 0 else round(por_n[n]['ini'] * FPS)
        print(f"cena {i + 1:02d} | {por_n[n]['ini']:5.1f} s | bloco {n:02d} \"{por_n[n]['texto']}\" | {c.get('texto') or c.get('tipo')}")
        nome = f'Cena {i + 1}'
        if c.get('tipo', 'texto') != 'texto':
            sys.exit(f'{nome}: use uma cena de motion com gráfico ou ícone desenhado em código.')
        visual = campos_motion(c, nome, {'tipo', 'quando', 'bloco_srt', 'batidas'})
        if not visual.get('icone') and not visual.get('barras'):
            sys.exit(f'{nome}: indique um ícone animado ou um gráfico de barras.')
        if visual.get('destaque') and visual['destaque'] not in visual.get('texto', ''):
            sys.exit(f'{nome}: o destaque não está no texto.')
        cena = {'tipo': 'texto', 'inicio': inicio, **visual}
        if batidas := c.get('batidas'):
            if not isinstance(batidas, list) or not all(isinstance(b, dict) for b in batidas):
                sys.exit(f'{nome}: batidas precisam ser uma lista de objetos.')
            cena['batidas'] = [campos_motion(b, f'{nome}, batida {j}', set()) for j, b in enumerate(batidas, 1)]
        cenas.append(cena)
    # Destaques: lista de palavras da fala (["noventa", "opinião"]) → o script acha o bloco de cada uma, em ordem.
    if isinstance(plano.get('destaques'), list):
        achados, desde = {}, 0
        for palavra in plano['destaques']:
            alvo = _pal(palavra)
            for b in blocos:
                tokens = b['texto'].split()
                hit = [t for t in tokens if _pal(t) == alvo] if b['n'] >= desde else []
                if hit:
                    achados.setdefault(str(b['n']), []).append(hit[0].upper())
                    desde = b['n']
                    break
            else:
                sys.exit(f'Destaque "{palavra}": não está na legenda (uma palavra só, tal e qual na fala, na ordem em que é dita).')
        plano['destaques'] = achados
    return ctx, plano, proj, cenas


def planos_reels(cenas: list[dict], fim: int) -> list[dict]:
    """Divide cada passagem em cortes de no máximo dois segundos."""
    saida = []
    for i, cena in enumerate(cenas):
        inicio = cena['inicio']
        limite = min(fim, cenas[i + 1]['inicio']) if i + 1 < len(cenas) else fim
        duracao = limite - inicio
        if duracao <= 0:
            break
        principal = {k: v for k, v in cena.items() if k != 'batidas'}
        variacoes = [principal, *cena.get('batidas', [])]
        quantidade = min(duracao, max(len(variacoes), (duracao + 2 * FPS - 1) // (2 * FPS)))
        for j in range(quantidade):
            variacao = dict(principal, **variacoes[min(j, len(variacoes) - 1)])
            variacao.update(inicio=inicio + j * duracao // quantidade, enquadramento=j % 2)
            if variacao.get('destaque') and variacao['destaque'] not in variacao.get('texto', ''):
                variacao.pop('destaque', None)
            saida.append(variacao)
    return saida


def escrever_dados(proj: Path, ctx: dict, plano: dict, cenas: list[dict], duracao: int,
                   av: dict | None, fonte_trilha: str | None, fonte_avatar: str | None = None) -> dict:
    av = av or {'srcW': 720, 'srcH': 1280, 'topoCabeca': 200, 'base': 1280, 'opaco': False}
    # 650 px de largura; se o recorte acaba antes (ex.: corpo cortado na linha da mesa), aumenta até o corte
    # ficar escondido abaixo do card (1880).
    escala = max(650 / av['srcW'], (1880 + 20 - 1090) / max(1, av['base'] - av['topoCabeca']))
    # Avatar opaco: legenda na parte de baixo do card, sobre um degradê.
    # Recortado: no peito, a ~45% da altura do recorte abaixo do topo da cabeça.
    legenda_top = 1640 if av['opaco'] else min(1700, round(1090 + 0.45 * (av['base'] - av['topoCabeca']) * escala))
    fim_inicio = max(1, duracao - round(1.5 * FPS))
    dados = {
        'duracaoFrames': duracao,
        'versaoMotion': VERSAO_MOTION,
        'fontePlano': hash_arquivo(proj.parent / 'reels_cenas.json'),
        'cores': ctx['cores'],
        'fonte': ctx['fonte'],
        'selo': nome_selo(ctx),
        'fonteTrilha': fonte_trilha,
        'fonteAvatar': fonte_avatar,
        'avatar': {'src': 'avatar.webm', 'srt': 'legendas.srt', 'srcW': av['srcW'], 'srcH': av['srcH'],
                   'topoCabeca': av['topoCabeca'], 'opaco': av['opaco'], 'escala': escala,
                   'fx': plano.get('avatar_fx', 0.5), 'fy': plano.get('avatar_fy', 0.3)},
        'legendaTop': legenda_top,
        'cenas': planos_reels(cenas, fim_inicio),
        'destaques': plano['destaques'],
        'fimInicio': fim_inicio,
        'cta': {'botao': CHAMADA_DIRECT, 'instagram': ctx['instagram']},
    }
    (proj / 'reels.json').write_text(json.dumps(dados, ensure_ascii=False, indent=2), encoding='utf-8')
    return dados


def render(proj: Path, comp: str, saida: Path, *extra: str) -> None:
    subprocess.run(['npx', 'remotion', 'render', 'src/index.ts', comp, str(saida), '--overwrite', '--log=error',
                    f'--concurrency={max(1, min(6, os.cpu_count() or 2))}', *extra], cwd=proj, check=True)


def tem_avatar(pasta: Path) -> bool:
    """Não gera substituto nem reutiliza Reels antigo quando o avatar foi dispensado."""
    marca = pasta / 'entrega' / 'reels_omitido.json'
    if not ler_contexto().get('avatar_look'):
        marca.parent.mkdir(parents=True, exist_ok=True)
        if not marca.exists():
            marca.write_text(json.dumps({'status': 'omitido', 'motivo': 'nenhum avatar selecionado'},
                                        ensure_ascii=False, indent=2), encoding='utf-8')
        print('Reels omitido: nenhum avatar selecionado. A animação segue sem avatar.')
        return False
    if marca.exists():
        marca.unlink()
    return True


def hash_arquivo(arquivo: Path) -> str | None:
    if not arquivo.is_file() or not arquivo.stat().st_size:
        return None
    with arquivo.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def base(pasta: Path) -> None:
    """Renderiza painel, cenas e card na duração do clipe já falado."""
    if not tem_avatar(pasta):
        return
    faixa = pasta / 'trabalho' / 'musica_reels.wav'
    fonte_trilha = hash_arquivo(faixa)
    from heygen_avatar import duracao_clipe
    arq = achar_avatar(pasta / 'entrega' / 'video')
    if not arq:
        sys.exit('Importe o clipe HeyGen com a fala incorporada antes de renderizar.')
    dur_s = duracao_clipe(arq)
    from legendas_voz import main as legendar
    legendar(pasta, arq)
    from revisao import checar
    checar(pasta, ['reels'])
    ctx, plano, proj, cenas = preparar(pasta)
    musica = proj / 'public' / 'musica.wav'
    if fonte_trilha is None:
        musica.unlink(missing_ok=True)
    else:
        validar_duracao(faixa, dur_s)
        resultado = subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(faixa),
                                    '-vn', '-t', f'{dur_s:.3f}', '-af', 'loudnorm=I=-18:TP=-2:LRA=11',
                                    '-ar', '48000', '-ac', '2', '-c:a', 'pcm_s16le', str(musica)])
        if resultado.returncode:
            sys.exit('A faixa do Reels está inválida. Baixe novamente a faixa do HeyGen ou escolha outra.')
    arquivo_base = proj / 'reels_base.mp4'
    arquivo_base.unlink(missing_ok=True)
    escrever_dados(proj, ctx, plano, cenas, int(dur_s * FPS + 1e-6), None, fonte_trilha, hash_arquivo(arq))
    temporario = proj / 'reels_base_render.mp4'
    render(proj, 'ReelsBase', temporario, '--codec=h264', '--x264-preset=veryfast')
    temporario.replace(arquivo_base)
    print('Base do Reels pronta (sem avatar):', arquivo_base)


def mascaras(proj: Path, dados: dict) -> tuple[Path, Path | None]:
    """Máscaras do avatar no card: esbatido dos lados e cantos de baixo arredondados (como no Remotion)."""
    av = dados['avatar']
    yy, xx = np.mgrid[0:CARD['y'] + CARD['h'], 0:CARD['w']]
    if av['opaco']:
        h = CARD['h']
        yy, xx = np.mgrid[0:h, 0:CARD['w']]
        cantos = np.ones((h, CARD['w']))
        for cx in (R, CARD['w'] - R):
            for cy in (R, h - R):
                fora = ((xx < R) if cx == R else (xx >= CARD['w'] - R)) & ((yy < R) if cy == R else (yy >= h - R))
                cantos[fora & ((xx - cx) ** 2 + (yy - cy) ** 2 > R * R)] = 0
        grad = np.clip((yy / h - 0.55) / 0.45, 0, 1) * 0.75
        Image.fromarray((cantos * 255).astype(np.uint8), 'L').save(proj / 'mascara_avatar.png')
        rgba = np.zeros((h, CARD['w'], 4), np.uint8)
        rgba[..., 3] = (grad * 255).astype(np.uint8)
        Image.fromarray(rgba, 'RGBA').save(proj / 'degrade_avatar.png')
        return proj / 'mascara_avatar.png', proj / 'degrade_avatar.png'
    esc = av['escala']
    avw = av['srcW'] * esc
    x0 = 540 - av['srcW'] / 2 * esc - CARD['x']
    u = (xx - x0) / avw
    lados = np.clip(np.minimum(u / 0.09, (1 - u) / 0.09), 0, 1)
    baixo = CARD['y'] + CARD['h']
    cantos = np.ones_like(lados)
    for cx in (R, CARD['w'] - R):
        fora = ((xx < R) if cx == R else (xx >= CARD['w'] - R)) & (yy >= baixo - R)
        cantos[fora & ((xx - cx) ** 2 + (yy - (baixo - R)) ** 2 > R * R)] = 0
    Image.fromarray((lados * cantos * 255).astype(np.uint8), 'L').save(proj / 'mascara_avatar.png')
    return proj / 'mascara_avatar.png', None


def final(pasta: Path) -> None:
    """Compõe o clipe e conserva a fala original no MP4 editado."""
    if not tem_avatar(pasta):
        return
    video = pasta / 'entrega' / 'video'
    arq = achar_avatar(video)
    if not arq:
        sys.exit('Importe o clipe HeyGen com a fala incorporada antes de finalizar.')
    fonte_avatar = hash_arquivo(arq)
    proj = pasta / 'trabalho' / 'remotion'
    dados_arq = proj / 'reels.json'
    dados_base = json.loads(dados_arq.read_text(encoding='utf-8')) if dados_arq.is_file() else {}
    faixa = pasta / 'trabalho' / 'musica_reels.wav'
    fonte_trilha = hash_arquivo(faixa)
    if (not (proj / 'reels_base.mp4').is_file() or dados_base.get('fonteTrilha') != fonte_trilha
            or dados_base.get('fonteAvatar') != fonte_avatar or dados_base.get('versaoMotion') != VERSAO_MOTION
            or dados_base.get('fontePlano') != hash_arquivo(pasta / 'trabalho' / 'reels_cenas.json')):
        base(pasta)
        dados_base = json.loads(dados_arq.read_text(encoding='utf-8'))
    if fonte_trilha is not None:
        validar_duracao(faixa, dados_base['duracaoFrames'] / FPS)
    ctx, plano, proj, cenas = preparar(pasta)
    av = medir_avatar(arq)
    if av['opaco']:
        print('Avatar sem fundo transparente: vai inteiro no card, com o cenário.')
    dados = escrever_dados(proj, ctx, plano, cenas, dados_base['duracaoFrames'], av, fonte_trilha, fonte_avatar)
    legendas = proj / 'legendas.mov'
    render(proj, 'ReelsLegendas', legendas, '--codec=prores', '--prores-profile=4444', '--image-format=png',
           '--pixel-format=yuva444p10le')
    mascara, degrade = mascaras(proj, dados)
    a = dados['avatar']
    dur = dados['duracaoFrames'] / FPS
    dec = ['-c:v', 'libvpx-vp9'] if arq.suffix == '.webm' else []
    cx, cy, cw, ch = 40, 1110, 1000, 770
    if a['opaco']:
        k = max(cw / a['srcW'], ch / a['srcH'])
        sw, sh = round(a['srcW'] * k), round(a['srcH'] * k)
        ox, oy = round((sw - cw) * a['fx']), round((sh - ch) * a['fy'])
        grafo = (f"[1:v]scale={sw}:{sh},crop={cw}:{ch}:{ox}:{oy},format=rgba[v];[v][4:v]overlay=0:0[vg];"
                 f"[vg]format=rgba,split[c1][c2];[c2]alphaextract[al];[al][3:v]blend=all_mode=multiply[am];"
                 f"[c1][am]alphamerge[avf];[0:v][avf]overlay={cx}:{cy}[b1];[b1][2:v]overlay={cx}:{cy}:shortest=1[out]")
        extra = ['-loop', '1', '-i', str(mascara), '-loop', '1', '-i', str(degrade)]
    else:
        esc = a['escala']
        aw, ah = round(a['srcW'] * esc / 2) * 2, round(a['srcH'] * esc / 2) * 2
        ax = round(540 - a['srcW'] / 2 * esc) - cx
        ay = round(1090 - a['topoCabeca'] * esc)
        grafo = (f"color=c=black@0:s={cw}x{cy + ch}:r={FPS}:d={dur:.3f},format=rgba[tela];"
                 f"[1:v]scale={aw}:{ah},format=rgba[v];[tela][v]overlay={ax}:{ay}:format=auto[avc];"
                 f"[avc]split[c1][c2];[c2]alphaextract[al];[al][3:v]blend=all_mode=multiply[am];[c1][am]alphamerge[avf];"
                 f"[0:v][avf]overlay={cx}:0[b1];[b1][2:v]overlay={cx}:{cy}:shortest=1[out]")
        extra = ['-loop', '1', '-i', str(mascara)]
    audio = '1:a:0'
    if fonte_trilha is not None:
        grafo += ';[1:a:0][0:a:0]amix=inputs=2:duration=first:normalize=0[audio]'
        audio = '[audio]'
    saida = pasta / 'entrega' / 'reels.mp4'
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(proj / 'reels_base.mp4'), *dec, '-i', str(arq), '-i', str(legendas),
                    *extra, '-filter_complex', grafo, '-map', '[out]', '-map', audio, '-c:v', 'libx264', '-preset', 'veryfast',
                    '-crf', '18', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-t', f'{dur:.3f}', str(saida)], check=True)

    fot = pasta / 'entrega' / 'fotogramas'
    fot.mkdir(parents=True, exist_ok=True)
    meio = cenas[len(cenas) // 2]['inicio'] + 20
    marcas = [0.8, meio / FPS, dur - 25 / FPS]
    for t in marcas:
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', f'{t:.2f}', '-i', str(saida), '-frames:v', '1',
                        str(fot / f'reels_{t:.2f}s.png')], check=True)
    print('Reels:', saida)
    print('Fotogramas:', ', '.join(f'reels_{t:.2f}s.png' for t in marcas))


if __name__ == '__main__':
    args = sys.argv[1:]
    etapa = args.pop(0) if args and args[0] in ('base', 'final') else None
    pasta = Path(args[0]).resolve()
    if etapa == 'base':
        base(pasta)
    else:
        final(pasta)  # faz a base antes, se ainda não existir
