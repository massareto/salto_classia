"""Marina Duarte: monta o post estático 1080x1350 com retrato gerado do apresentador.

Uso:
  python3 remotion_estatico.py "<pasta da peça>"

Precisa de <pasta>/trabalho/estatico.json (a Marina escreve), por exemplo:
  {"imagem": "trabalho/imagens/estatico.png", "focoX": 0.5,
   "texto": "Reunião boa tem objetivo antes de ter horário.", "destaque": "objetivo"}
  - imagem: retrato novo gerado a partir da referência autorizada do apresentador; exige .proveniencia.json.
  - texto e destaque (opcionais): uma frase curta por cima do degradê; sem texto, fica só a fotografia com o selo
    e o Instagram no rodapé. O destaque tem de existir tal e qual no texto.

Entrega: <pasta>/entrega/estatico.png
"""
import json
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
from contexto import ler_contexto  # noqa: E402
from remotion_cartelas import exportar, visual  # noqa: E402
from remotion_reels import nome_selo, preparar_projeto  # noqa: E402


def main(pasta: Path) -> None:
    from revisao import checar
    checar(pasta, ['estatico'])
    ctx = ler_contexto()
    e = json.loads((pasta / 'trabalho' / 'estatico.json').read_text(encoding='utf-8'))
    texto, destaque = e.get('texto', ''), e.get('destaque', '')
    if texto and destaque not in texto:
        sys.exit(f'estatico.json: o destaque "{destaque}" não está no texto.')
    if texto and len(texto.split()) > 12:
        sys.exit('estatico.json: frase longa demais (máximo 12 palavras). Encurte o gancho para leitura rápida.')
    proj = preparar_projeto(pasta, ctx, 'remotion_estatico')
    props = {'n': 1, 'total': 1, 'semNumero': True, 'texto': texto, 'destaque': destaque or '', 'kicker': e.get('kicker'),
             'cores': ctx['cores'], 'fonteTitulo': ctx['fonte'], 'instagram': ctx['instagram'], 'selo': nome_selo(ctx), 'fonte': e.get('fonte'), 'contato': ctx['contato']}
    visual(pasta, proj, e, props, 'estatico', retrato=True)
    png = pasta / 'entrega' / 'estatico.png'
    png.parent.mkdir(parents=True, exist_ok=True)
    ok = exportar(proj, [(props, png)])[0]
    print('Estático:', png, '- ok' if ok else '- TEXTO NA MARGEM (encurtar a frase)')
    if not ok:
        sys.exit(1)


if __name__ == '__main__':
    main(Path(sys.argv[1]).resolve())
