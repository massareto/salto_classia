"""Prepara o Remotion e seu navegador antes da edição. Uso: python3 scripts/aquecer.py."""
import subprocess
from pathlib import Path

from contexto import esperar_instalacao

MODELO = Path(__file__).resolve().parent.parent / 'remotion'
marca = MODELO / '.instalando'
try:
    with marca.open('x', encoding='utf-8') as arquivo:
        arquivo.write('instalando')
except FileExistsError:
    esperar_instalacao(MODELO)
    with marca.open('x', encoding='utf-8') as arquivo:
        arquivo.write('instalando')

try:
    if not (MODELO / 'node_modules' / '.bin' / 'remotion').exists():
        subprocess.run(['npm', 'ci', '--silent', '--no-audit', '--no-fund'], cwd=MODELO, check=True)
    subprocess.run(['npx', 'remotion', 'browser', 'ensure'], cwd=MODELO, check=True)
finally:
    marca.unlink(missing_ok=True)
print('Remotion pronto.')
