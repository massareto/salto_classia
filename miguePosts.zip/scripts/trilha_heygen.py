"""Confere se a faixa baixada do HeyGen cobre a duração da peça."""
import json
from pathlib import Path
import subprocess
import sys


def validar_duracao(faixa: Path, segundos: float) -> None:
    if not faixa.is_file() or not faixa.stat().st_size:
        sys.exit(f'Baixe uma faixa do catálogo do HeyGen em {faixa.name} antes de renderizar.')
    resultado = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'a:0',
                                '-show_entries', 'stream=duration', '-of', 'json', str(faixa)],
                               capture_output=True, text=True)
    try:
        resultado.check_returncode()
        duracao = float(json.loads(resultado.stdout)['streams'][0]['duration'])
    except (subprocess.CalledProcessError, ValueError, TypeError, KeyError, IndexError):
        sys.exit(f'{faixa.name} está inválida. Baixe novamente a faixa do HeyGen ou escolha outra.')
    if not duracao >= round(segundos, 6):
        sys.exit(f'{faixa.name} dura {duracao:.2f} s. Escolha no HeyGen uma faixa de pelo menos {segundos:.2f} s.')
