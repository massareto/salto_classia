"""Entrada antiga desativada. Use heygen_voz.py e o conector HeyGen."""
raise RuntimeError("O miguePosts usa voz HeyGen. Prepare o pedido com heygen_voz.py, gere pelo conector e importe o áudio. Não há fallback automático.")
