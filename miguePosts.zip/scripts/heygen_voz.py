"""Prepara e importa a narração HeyGen da animação."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

from contexto import ler_contexto, para_voz


def _roteiro_animacao(pasta):
    return json.loads((pasta / 'trabalho' / 'animacao.json').read_text(encoding='utf-8'))


def _texto(pasta):
    return '\n\n'.join(para_voz(f['texto']) for f in _roteiro_animacao(pasta)['falas']) + '\n'


def _salvar_json(arquivo, dados):
    arquivo.write_text(json.dumps(dados, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def preparar(pasta):
    voz = ler_contexto().get('voz')
    if not voz:
        raise ValueError('Guarde no contexto o voice_id da voz escolhida no HeyGen.')
    destino = pasta / 'trabalho'
    destino.mkdir(parents=True, exist_ok=True)
    pedido = {
        'voiceId': voz,
        'text': _texto(pasta),
        'language': 'pt',
        'expressivenessBoost': .85,
        'withTimestamps': True,
    }
    _salvar_json(destino / 'heygen-pedido-voz.json', pedido)
    (destino / 'direcao-voz.md').write_text(
        'Conte como numa conversa com uma pessoa. Abra com uma situação concreta do nicho e curiosidade. '
        'Faça uma pausa curta antes da virada, dê peso ao detalhe que resolve a história e termine com um convite direto. '
        'Use esta orientação apenas no controle de estilo se a ferramenta oferecer esse campo. '
        'No texto falado, use ritmo de frases, pausas e pontuação natural.\n',
        encoding='utf-8',
    )
    return pedido


def _importar_animacao(pasta, falas, chars, bruto, duracao, audio, metadados):
    destino = pasta / 'trabalho' / 'animacao' / 'voz'
    destino.mkdir(parents=True, exist_ok=True)
    spans = []
    cursor = 0
    for f in falas:
        texto = para_voz(f['texto'])
        start = bruto.find(texto, cursor)
        if start < 0:
            raise ValueError(f"Tempos não correspondem a {f['id']}.")
        cursor = start + len(texto)
        spans.append((f, start, cursor))

    # Os tempos do provedor correspondem aos caracteres do texto.
    if len(chars) != len(bruto):
        raise ValueError('Formato de tempos inesperado. Confira o retorno do HeyGen.')
    for index, (f, a, b) in enumerate(spans):
        inicio = max(0, chars[a]['start_time'] - .08)
        fim = min(duracao, chars[b - 1]['end_time'] + .08)
        if index + 1 < len(spans):
            fim = min(fim, chars[spans[index + 1][1]]['start_time'])
        saida = destino / (f['id'] + '.mp3')
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', str(inicio), '-i', str(audio),
                        '-t', str(fim - inicio), '-ar', '48000', '-codec:a', 'libmp3lame',
                        '-b:a', '192k', str(saida)], check=True)
        alinhamento = {
            'characters': [c['text'] for c in chars[a:b]],
            'character_start_times_seconds': [round(max(0, c['start_time'] - inicio), 4) for c in chars[a:b]],
            'character_end_times_seconds': [round(max(0, c['end_time'] - inicio), 4) for c in chars[a:b]],
        }
        meta = dict(metadados, texto=f['texto'], audio_sha256=hashlib.sha256(saida.read_bytes()).hexdigest(),
                    alignment=alinhamento)
        _salvar_json(saida.with_suffix('.json'), meta)
    _salvar_json(pasta / 'trabalho' / 'heygen-voz-proveniencia.json', metadados)
    print(f'Tomada da animação importada, {len(spans)} trechos com tempos reais.')


def importar(pasta, resultado, audio):
    pedido = preparar(pasta)
    dados = json.loads(resultado.read_text(encoding='utf-8'))
    if 'content' in dados:
        dados = json.loads(next(x['text'] for x in dados['content'] if x['type'] == 'text'))
    chars = dados.get('original_characters') or []
    if not chars:
        raise ValueError('O HeyGen não devolveu tempos. Solicite withTimestamps.')
    bruto = ''.join(c['text'] for c in chars)
    if bruto.strip() != pedido['text'].strip():
        raise ValueError('O áudio não corresponde ao roteiro desta peça.')
    if not audio.is_file():
        raise ValueError('Baixe o áudio retornado pelo HeyGen antes da importação.')

    metadados = {
        'provedor': 'heygen',
        'voice_id': pedido['voiceId'],
        'expressivenessBoost': pedido['expressivenessBoost'],
        'duration': dados['duration'],
        'source_sha256': hashlib.sha256(audio.read_bytes()).hexdigest(),
        'tempos': 'retornados pelo HeyGen',
        'modelo': 'selecionado pelo serviço',
    }
    _importar_animacao(pasta, _roteiro_animacao(pasta)['falas'], chars, bruto, dados['duration'], audio, metadados)


def validar(pasta):
    voz = ler_contexto().get('voz')
    for f in _roteiro_animacao(pasta)['falas']:
        arquivo = pasta / 'trabalho' / 'animacao' / 'voz' / (f['id'] + '.mp3')
        meta = arquivo.with_suffix('.json')
        dados = json.loads(meta.read_text(encoding='utf-8')) if meta.exists() else {}
        if (not arquivo.is_file() or dados.get('provedor') != 'heygen'
                or dados.get('texto') != f['texto'] or dados.get('voice_id') != voz
                or dados.get('audio_sha256') != hashlib.sha256(arquivo.read_bytes()).hexdigest()):
            raise ValueError(f"Narração HeyGen atual ausente em {f['id']}. Gere e importe a voz da animação.")
    return True


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('acao', choices=('preparar', 'importar', 'validar'))
    parser.add_argument('pasta', type=Path)
    parser.add_argument('resultado', type=Path, nargs='?')
    parser.add_argument('audio', type=Path, nargs='?')
    parser.add_argument('--peca', choices=('animacao',), default='animacao')
    args = parser.parse_args()
    try:
        if args.acao == 'preparar':
            preparar(args.pasta.resolve())
            destino = args.pasta / 'trabalho'
            print(f'Pedido salvo em {destino / "heygen-pedido-voz.json"}.')
        elif args.acao == 'importar':
            if args.resultado is None or args.audio is None:
                parser.error('Informe o JSON de retorno e o áudio para importar.')
            importar(args.pasta.resolve(), args.resultado, args.audio)
        else:
            validar(args.pasta.resolve())
            print('Voz HeyGen da animação validada.')
    except (ValueError, KeyError, OSError, StopIteration) as error:
        parser.exit(2, f'{error}\n')
