"""Validate generated artwork and keep the presenter reference out of finished media."""
import hashlib
import json
from pathlib import Path


def validar(pasta, caminho, *, retrato=False):
    arquivo = (Path(pasta) / caminho).resolve()
    meta = arquivo.with_suffix('.proveniencia.json')
    dados = json.loads(meta.read_text(encoding='utf-8')) if meta.is_file() else {}
    heygen_ok = dados.get('provedor') != 'heygen' or (
        dados.get('referencia_origem') == 'heygen' or dados.get('fallback_motivo'))
    if (not arquivo.is_file() or dados.get('provedor') not in ('chatgpt', 'nativo', 'heygen')
            or not heygen_ok or dados.get('gerada') is not True
            or dados.get('revisao_identidade') != 'aprovada' or not dados.get('generation_id')
            or dados.get('sha256') != hashlib.sha256(arquivo.read_bytes()).hexdigest()):
        raise ValueError(f'Imagem sem geração e revisão registradas: {arquivo}.')
    if retrato and (dados.get('uso') != 'retrato_apresentador'
                    or dados.get('referencia_origem') not in ('heygen', 'usuario')
                    or not dados.get('referencia')):
        raise ValueError(f'Inclua um retrato gerado a partir da referência autorizada do apresentador: {arquivo}.')
    return arquivo
