"""Prepare o pedido de vídeo falado do Reel para o MCP e importe o clipe concluído."""
import argparse
import json
import math
import shutil
import subprocess
import tempfile
from pathlib import Path

from contexto import ler_contexto, para_voz


def preparar(pasta: Path) -> dict | None:
    """Produz os argumentos de create_video_from_avatar, sem chamar o HeyGen."""
    ctx = ler_contexto()
    avatar = ctx.get('avatar_look')
    marca = pasta / 'entrega' / 'reels_omitido.json'
    if not avatar:
        marca.parent.mkdir(parents=True, exist_ok=True)
        if not marca.exists():
            marca.write_text('{"status":"omitido","motivo":"sem_avatar"}\n', encoding='utf-8')
        return None
    marca.unlink(missing_ok=True)
    roteiro = pasta / 'trabalho' / 'fala.txt'
    script = para_voz(roteiro.read_text(encoding='utf-8')).strip()
    if not script:
        raise ValueError('O texto do Reel está vazio.')
    vertical = ctx['avatar_formato'] == '9:16'
    pedido = {
        'avatarId': avatar,
        'script': script,
        'title': f'Reel {pasta.name}',
        'aspectRatio': ctx['avatar_formato'],
        'resolution': '720p' if vertical else '1080p',
        'outputFormat': 'webm' if vertical else 'mp4',
        'caption': {'file_format': 'srt'},
    }
    if ctx['voz']:
        pedido['voiceId'] = ctx['voz']
    return pedido


def sondar(clipe: Path) -> dict:
    dados = json.loads(subprocess.check_output([
        'ffprobe', '-v', 'error', '-show_entries',
        'format=format_name,duration:stream=codec_type,duration', '-of', 'json', str(clipe),
    ]))
    tipos = {fluxo['codec_type'] for fluxo in dados.get('streams', [])}
    if not {'video', 'audio'} <= tipos:
        raise ValueError('O Reel precisa do vídeo do HeyGen com a fala na própria faixa de áudio.')
    return dados


def duracao_clipe(clipe: Path) -> float:
    dados = sondar(clipe)
    imagem = next(fluxo for fluxo in dados['streams'] if fluxo['codec_type'] == 'video')
    segundos = imagem.get('duration') or dados['format']['duration']
    duracao = float(segundos if segundos != 'N/A' else dados['format']['duration'])
    if not math.isfinite(duracao) or duracao < 1 / 30:
        raise ValueError('Duração inválida no clipe do Reel.')
    return duracao


def importar(pasta: Path, clipe: Path, legenda: Path | None = None) -> Path:
    """Conserva o vídeo e sua faixa de áudio tal como foram entregues pelo HeyGen."""
    formato = sondar(clipe)['format']['format_name'].split(',')
    extensao = '.webm' if 'webm' in formato else '.mp4' if 'mp4' in formato else None
    if extensao is None:
        raise ValueError('Importe o MP4 ou WebM retornado pelo HeyGen.')
    destino = pasta / 'entrega' / 'video'
    destino.mkdir(parents=True, exist_ok=True)
    avatar = destino / f'avatar{extensao}'
    srt = destino / 'avatar.srt'
    with tempfile.TemporaryDirectory(dir=destino) as temporario:
        tmp = Path(temporario)
        shutil.copyfile(clipe, tmp / avatar.name)
        if legenda:
            shutil.copyfile(legenda, tmp / srt.name)
            (tmp / srt.name).replace(srt)
        else:
            srt.unlink(missing_ok=True)
        (tmp / avatar.name).replace(avatar)
    outro = avatar.with_suffix('.mp4' if extensao == '.webm' else '.webm')
    outro.unlink(missing_ok=True)
    return avatar


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    comandos = parser.add_subparsers(dest='acao', required=True)
    comandos.add_parser('preparar').add_argument('pasta', type=Path)
    entrada = comandos.add_parser('importar')
    entrada.add_argument('pasta', type=Path)
    entrada.add_argument('clipe', type=Path)
    entrada.add_argument('--srt', type=Path)
    args = parser.parse_args()
    try:
        if args.acao == 'preparar':
            if (pedido := preparar(args.pasta)) is not None:
                print(json.dumps(pedido, ensure_ascii=False, indent=2))
            else:
                print('Reel omitido: nenhum avatar selecionado.')
        else:
            print(importar(args.pasta, args.clipe, args.srt))
    except (OSError, ValueError, subprocess.CalledProcessError) as erro:
        parser.exit(2, f'{erro}\n')
