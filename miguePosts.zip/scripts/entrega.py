"""Mostre uma peça revisada assim que estiver pronta ou consolide as entregas no fim."""
import argparse
import base64
import datetime as dt
import json
from pathlib import Path

from PIL import Image

from revisao import checar

PECAS = {
    'reels': ('Reels', 'reels.mp4', 'reels'),
    'animacao': ('Animação', 'animacao.mp4', 'animacao'),
    'carrossel': ('Carrossel', 'carrossel.html', 'cartelas'),
    'estatico': ('Estático', 'estatico.png', 'estatico'),
}


def prontas(entrega: Path) -> list[str]:
    cartelas = [entrega / 'carrossel' / f'{i:02}.png' for i in range(1, 8)]
    return [
        peca for peca, pronta in (
            ('reels', (entrega / 'reels.mp4').is_file() and not (entrega / 'reels_omitido.json').exists()),
            ('animacao', (entrega / 'animacao.mp4').is_file()),
            ('carrossel', all(cartela.is_file() for cartela in cartelas)),
            ('estatico', (entrega / 'estatico.png').is_file()),
        ) if pronta
    ]


def montar_carrossel(entrega: Path) -> None:
    cartelas = [entrega / 'carrossel' / f'{i:02}.png' for i in range(1, 8)]
    imgs = ''.join(
        f'<img src="data:image/png;base64,{base64.b64encode(p.read_bytes()).decode()}" alt="Cartela {i}">'
        for i, p in enumerate(cartelas, 1))
    (entrega / 'carrossel.html').write_text(
        '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1"><title>Carrossel</title>'
        '<style>body{margin:0;background:#111;display:flex;flex-direction:column;align-items:center;gap:16px;padding:16px}'
        'img{width:100%;max-width:540px;height:auto;display:block}</style></head>'
        f'<body>{imgs}</body></html>', encoding='utf-8')
    paginas = []
    for cartela in cartelas:
        with Image.open(cartela) as imagem:
            paginas.append(imagem.convert('RGB'))
    paginas[0].save(entrega / 'carrossel.pdf', save_all=True, append_images=paginas[1:], resolution=144)


def main(pasta: Path, peca: str | None = None) -> None:
    entrega = pasta / 'entrega'
    entrega.mkdir(parents=True, exist_ok=True)
    selecionadas = prontas(entrega)
    if peca:
        if peca not in selecionadas:
            raise ValueError(f'{PECAS[peca][0]} ainda não está disponível para entrega.')
        selecionadas = [peca]
    if selecionadas:
        checar(pasta, [PECAS[item][2] for item in selecionadas])
    if 'carrossel' in selecionadas:
        montar_carrossel(entrega)
    links = [(PECAS[item][0], PECAS[item][1]) for item in selecionadas]
    for nome, arquivo in links:
        print(f'- [{nome}](<{entrega / arquivo}>)')
    if peca:
        return

    aviso = ''
    omissao = entrega / 'reels_omitido.json'
    if omissao.is_file() and json.loads(omissao.read_text(encoding='utf-8')).get('motivo') == 'sem_avatar':
        aviso = 'Não há avatar disponível para gerar o Reel.'
        print(aviso)
    texto = ''.join(f'- [{nome}]({arquivo})\n' for nome, arquivo in links)
    (entrega / 'LINKS.md').write_text(texto + (f'\n{aviso}\n' if aviso else ''), encoding='utf-8')
    inicio = pasta / 'trabalho' / 'inicio.txt'
    if inicio.is_file():
        t0 = dt.datetime.fromisoformat(inicio.read_text().strip())
        agora = dt.datetime.now(t0.tzinfo)
        seg = int((agora - t0).total_seconds())
        (entrega / 'TEMPO.txt').write_text(f'Pedido: {t0.isoformat(timespec="seconds")}\nEntregas prontas: '
                                          f'{agora.isoformat(timespec="seconds")}\nTempo: {seg // 60} min {seg % 60:02d} s\n',
                                          encoding='utf-8')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pasta', type=Path)
    parser.add_argument('--peca', choices=PECAS)
    args = parser.parse_args()
    try:
        main(args.pasta.resolve(), args.peca)
    except ValueError as erro:
        parser.exit(2, f'{erro}\n')
