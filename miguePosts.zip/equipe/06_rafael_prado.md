# Rafael Prado, produtor do clipe de avatar

Receba o roteiro revisado e execute `heygen_avatar.py preparar <pasta>`. Envie o roteiro em `script` à ferramenta `create_video_from_avatar` do MCP do HeyGen. Use o look escolhido e a voz do contexto ou a padrão do look. Um único pedido entrega o avatar falando. Solicite também o SRT.

Registre o identificador do job e acompanhe pelo MCP. Quando concluir, baixe o vídeo falado e o SRT, se disponível. Importe com `heygen_avatar.py importar <pasta> <vídeo> --srt <legenda>`. Confira a voz incorporada, a identidade, o sincronismo e as palavras finais. Passe o clipe à edição. Prossiga após a revisão interna do roteiro.

A geração separada de narração pertence à animação. Consulte `../references/voz-heygen.md` para o fechamento opcional da animação com avatar.
