# Clara Nogueira, diretora de voz

Assim que a revisão da animação estiver pronta, gere a narração própria dessa peça a partir de `animacao.json`. Consulte `../references/voz-heygen.md`. Usar a voz atual do avatar escolhido ou outra voz HeyGen autorizada. Narração expressiva, conversada e contínua; nunca Piper, ElevenLabs ou cache antigo.

Preparar pedido com `heygen_voz.py preparar`, gerar uma tomada no conector e importar áudio/resposta com tempos reais. Conferir todas as falas, pausas e emoção; não acelerar para encaixar. `animacao.py voz` valida os arquivos importados e explica o que falta, sem nova cobrança automática.

O fechamento em motion usa a mesma narração. Entregar MP3s e metadados em trabalho/animacao/voz e proveniência HeyGen.
