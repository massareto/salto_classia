# Regras comuns

1. Ler `CONTEXTO.md`, briefing, notícia e ganchos da peça. Dados `[a confirmar]` não entram em público. Não transferir contexto de outro negócio.
2. Produto/serviço, público e convite precisam estar informados ou ter escolhas expressamente autorizadas. Perguntar apenas lacunas, aguardar resposta; silêncio não confirma.
3. Português do Brasil, “você”, frases claras, sem travessões. Quem publica fala em primeira pessoa.
4. **Sem siglas nos textos públicos e narração.** “Inteligência artificial” por extenso, nunca “IA”, “I.A.” ou “AI”. Expandir siglas específicas pelo significado correto, sem mexer em URLs/identificadores.
5. Não inventar dado, credencial, depoimento, cliente, repercussão ou resultado. Fatos precisam de fonte; separar opinião do dono e oferta. Nada de promessa garantida ou urgência falsa.
6. A notícia é conferida em duas fontes, com data e links. Não chamar notícia antiga de nova nem sugerir endosso de uma instituição ao serviço.
7. Saúde e diagnóstico ficam fora desta equipe. Não apresentar coaching como tratamento.
8. Gancho específico primeiro; depois notícia, relevância, leitura/ação do dono e convite. Sem cumprimento e apresentação genérica na abertura. Um mesmo argumento nas peças.
9. Convite segue o briefing. Pode oferecer informações de uma sessão ou outro material; **não forçar guia**. Se oferece material, ele deve existir antes da publicação.
10. **Animação padrão é ilustração do próprio roteiro**, com cenas temáticas. Defina imagens, objetos, ações e ícones para a história e o nicho atuais. Inclua mudanças visíveis em até dois segundos nos dois vídeos. Pessoas da notícia não viram caricatura sem pedido.
11. Buscar no catálogo do HeyGen uma faixa instrumental dinâmica por vídeo, com entrada rápida e batida definida. Mixar abaixo da voz. Se nenhuma faixa adequada estiver disponível, renderizar com a voz HeyGen. Ver `../references/configuracao.md`.
12. Resolver o avatar pelo procedimento em `../references/voz-heygen.md`. Escolher automaticamente um avatar privado pronto de vídeo, ou de foto quando não houver de vídeo. Avatar serve ao Reel. A animação é toda desenhada em código.
13. Voz expressiva HeyGen, priorizando a voz atual do avatar escolhido; sem fallback local/ElevenLabs. Sem nenhuma voz disponível, carrossel e estático seguem. Chaves nunca no chat, ZIP ou documentos da peça.
14. Estático, capa e fechamento do carrossel levam um retrato gerado com a referência autorizada do apresentador. Busque a referência primeiro no HeyGen.
15. Todas as cenas/cartelas têm um visual ligado ao conteúdo. Cor/fonte/perfil seguem contexto; um acento visual por cena. Sem logotipo de instituição como selo de endosso.
16. Grave arquivos próprios para cada frente e revise cada roteiro antes de sua voz. Inicie as quatro frentes juntas e faça cada revisão e render assim que a própria peça estiver pronta. Gere o clipe falado do Reel e a narração separada da animação pelo MCP do HeyGen. Siga para a edição após a revisão interna. Revisões invalidam caches de texto, voz e alinhamento quando necessário.
17. Validar quadros críticos antes do render completo; depois abrir imagens e quadros finais. Não usar só o retorno de sucesso do programa como revisão visual.
18. Mostre cada peça na conversa assim que renderizar e passar pela revisão. Continue a execução das outras, em paralelo.
19. Publicar e enviar a terceiros somente quando pedido. Entrega local não é publicação nem aprovação do dono.

## Estrutura

`<pasta>/trabalho/`: briefing, noticias.json, noticia.json, ganchos por peça, fala.txt, fala_voz.txt, reels_cenas.json, animacao.json, musica_reels.wav, musica_animacao.wav, cartelas.json, estatico.json, legendas, imagens e relatórios.

`<pasta>/entrega/`: formatos efetivamente gerados, carrossel/01.png…07.png, RESUMO.md e fotogramas de conferência. Vídeos opcionais não devem ser falsamente listados quando omitidos.

Imagens podem ser geradas por ferramenta disponível em lote: uma ideia por cena, sem texto embutido nem dados reais de terceiros. Use HeyGen Image ou Look Remix para os retratos, com geração nativa como alternativa. Inclua “Me chama no Direct” no fechamento e na legenda das quatro peças.
