# Helena Prado: briefing e configuração

O orquestrador faz este papel. Ler o pedido e `CONTEXTO.md` primeiro.

## Perguntar só o que falta

Conferir **produto/serviço** e **público**. Use o convite para o Direct nas quatro peças. Se já estão no pedido ou contexto confirmado, não perguntar novamente. Para lacunas, fazer uma única rodada objetiva, podendo sugerir opções, e aguardar resposta. Sugestão, silêncio e opção pré-selecionada não são aprovação. Não preencher público por conhecer genericamente o dono. Se o dono autorizar “pode escolher”, usar essa autorização e registrar a escolha editorial.

Campos opcionais como preço, modalidade e ferramentas específicas podem ficar `[a confirmar]` e não entrar nas peças. Não pedir dados que não afetam a produção atual.

## Configuração técnica

1. Conferir as dependências no início do `SKILL.md` e iniciar o preparo do Remotion antes da produção. Verificar conexão HeyGen e resolver a voz e o avatar seguindo `../references/voz-heygen.md`.
2. Resolver o look pela ordem de prioridade da referência e registrar os dados no contexto de trabalho. Quando a conta não tiver avatar pronto, registrar a omissão do Reel e continuar as demais entregas. Sem voz HeyGen, registrar a pendência e produzir os formatos visuais viáveis.
3. Busque primeiro a referência privada da pessoa no HeyGen e compartilhe-a com as duas frentes visuais. Use HeyGen Image ou Look Remix para gerar os retratos, com geração nativa como alternativa. Ver `../references/imagens-identidade.md`.
4. Abrir e avaliar a referência. Se faltar boa foto, pedir; se ruim, dizer “Essa foto não está muito boa” e explicar. Nunca usar a foto crua. Gerar novo retrato mantendo identidade e revisar. Sem referência suficiente, não inventar rosto.
5. Conferir acesso ao catálogo de música do HeyGen e seguir `../references/configuracao.md`. Encaminhar a busca e o download de uma faixa para cada vídeo que será produzido.

## Registrar

Criar contexto próprio para novo negócio. Em `trabalho/00_briefing.md`:

```
# Briefing da peça
**Serviço:** ...
**Nicho:** ...
**Público:** ...
**Convite:** Quer resolver esse problema? Me chama no Direct.
**Assuntos que não entram:** ...
**Avatar e voz:** avatar resolvido ou motivo da ausência, voz HeyGen selecionada ou pendente
**Áudio dos vídeos:** voz HeyGen e trilha do catálogo por peça
**Confirmado pelo usuário:** ...
**Escolhas editoriais autorizadas:** ...
**[a confirmar]:** ...
```

Sincronize no contexto as chamadas das quatro peças com o convite para o Direct. Confirmar leitura com `scripts/contexto.py`, usando `MARKETING_COACHES_PROJETO`.
