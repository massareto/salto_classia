// Fontes de título aceitas no CONTEXTO.md ("Fonte de título"). Todas carregam do Google Fonts.
import {loadFont as poppins} from '@remotion/google-fonts/Poppins';
import {loadFont as montserrat} from '@remotion/google-fonts/Montserrat';
import {loadFont as inter} from '@remotion/google-fonts/Inter';

const opcoes = {weights: ['600', '700', '800', '900'], subsets: ['latin', 'latin-ext']};
const carregadas = {
	Poppins: poppins('normal', opcoes),
	Montserrat: montserrat('normal', opcoes),
	Inter: inter('normal', opcoes),
};

export type NomeFonte = keyof typeof carregadas;
export const fonte = (nome?: string) => carregadas[(nome as NomeFonte) in carregadas ? (nome as NomeFonte) : 'Poppins'];
