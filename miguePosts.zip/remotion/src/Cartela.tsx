import React, {useLayoutEffect, useRef, useState} from 'react';
import {flushSync} from 'react-dom';
import {AbsoluteFill, Img, continueRender, delayRender, staticFile} from 'remotion';
import {fonte} from './fontes';
import {Icone} from './icones';

// Cartela de carrossel 1080x1350 para coaches: imagem (gerada por IA ou foto do coach) de ponta a ponta com degradê
// por baixo do texto, ou ícone grande desenhado em código. Também serve para o post estático (semNumero, sem texto).
// Grelha: margem igual de 80 px nos quatro lados; nenhuma letra entra nos 72 px da borda.
export const CW = 1080;
export const CH = 1350;
const M = 80;

export type Cores = {
	fundo: string;
	cartao: string;
	texto: string;
	'marca-texto': string;
	'texto-marca-texto': string;
	acento: string;
};
const CORES_PADRAO: Cores = {
	fundo: '#111114',
	cartao: '#1C1C22',
	texto: '#F5F4EF',
	'marca-texto': '#F5F4EF',
	'texto-marca-texto': '#111114',
	acento: '#2FBF71',
};

// Capa (n=1) 100 px; cartelas interiores 70 px. Mesma entrelinha.
const tamanho = (n: number) => (n === 1 ? 100 : 70);
const ENTRELINHA = 1.16;
// Número-chave numa linha só: encolhe com o comprimento ("23 MIN" 190 px; "3 HORÁRIOS" ~120 px).
const tamanhoNumero = (s: string) => Math.min(190, Math.floor(1500 / Math.max(1, s.length)));
// Barra do destaque só na altura das letras (a caixa da fonte é mais alta e cobria a linha de cima).
const barra = (cor: string) => `linear-gradient(to bottom, transparent 16%, ${cor} 16%, ${cor} 90%, transparent 90%)`;

const RODAPE_H = 48;
const RODAPE_TOP = CH - M - RODAPE_H;
const GAP_TEXTO_RODAPE = 64;

export type CartelaProps = {
	n: number;
	total?: number;
	kicker?: string; // rótulo curto em caixa alta, em cima (ex.: "PRODUTIVIDADE · 01")
	numero?: string; // número-chave opcional, grande, na cor de acento (ex.: "23 MIN")
	fonte?: string | null; // fonte curta do dado, em letra pequena acima do rodapé (ex.: "Mark et al., 2005")
	texto: string;
	destaque: string;
	foto?: string | null; // imagem de ponta a ponta (public/): gerada por IA ou foto do coach
	icone?: string | null; // ícone grande em cima (ver icones.tsx), quando não há imagem
	semNumero?: boolean; // post estático: rodapé sem a numeração
	focoX?: number;
	ratio?: number;
	contato?: string | null; // só na última cartela: vai para o botão
	cores?: Cores;
	fonteTitulo?: string;
	instagram?: string;
	selo?: string | null; // arquivo em public/
	// 'final' = cartela; 'mascara' = só letras a branco sobre preto (mede as margens)
	modo?: 'final' | 'mascara';
};

// Microtipografia (só quebras de linha, as palavras não mudam): palavras de uma ou duas letras
// presas à seguinte, número preso à unidade e sem viúva no fim.
const NBSP = ' ';
const prende = (t: string) =>
	t
		.replace(/(?<=^|[\s ])([A-Za-zÀ-ÿ]{1,2}) (?=\S)/g, `$1${NBSP}`)
		.replace(/(\d) (?=%|h\b|min\b|horas?\b|minutos?\b|dias?\b|semanas?\b)/g, `$1${NBSP}`);
const semViuva = (t: string) => t.replace(/ (\S{1,10})$/, `${NBSP}$1`);

export const Cartela: React.FC<CartelaProps> = ({
	n,
	total = 5,
	kicker,
	numero,
	fonte: fonteDado = null,
	texto,
	destaque,
	foto = null,
	icone = null,
	semNumero = false,
	focoX = 0.5,
	ratio = 4 / 5,
	contato = null,
	cores = CORES_PADRAO,
	fonteTitulo = 'Poppins',
	instagram = '',
	selo = null,
	modo = 'final',
}) => {
	const {fontFamily, waitUntilDone} = fonte(fonteTitulo);
	const blocoRef = useRef<HTMLDivElement>(null);
	const [topoTexto, setTopoTexto] = useState<number | null>(null);
	const [handle] = useState(() => delayRender('medir texto'));

	useLayoutEffect(() => {
		let disposed = false;
		let observer: ResizeObserver | null = null;
		waitUntilDone().then(() => {
			if (disposed) return;
			requestAnimationFrame(() => {
				if (disposed) return;
				const el = blocoRef.current;
				if (el) {
					flushSync(() => setTopoTexto(el.offsetTop));
					observer = new ResizeObserver(() => setTopoTexto(el.offsetTop));
					observer.observe(el);
				}
				continueRender(handle);
			});
		});
		return () => { disposed = true; observer?.disconnect(); };
	}, [handle, waitUntilDone]);

	const i = texto ? texto.indexOf(destaque) : 0;
	if (texto && i < 0) throw new Error(`Destaque "${destaque}" não encontrado no texto.`);
	const antes = prende(texto.slice(0, i));
	const depois = semViuva(prende(texto.slice(i + destaque.length)));

	const mascara = modo === 'mascara';
	const fs = tamanho(n);
	const TEXTO = mascara ? '#FFFFFF' : cores.texto;
	const ACENTO = mascara ? '#FFFFFF' : cores.acento;

	// Foto em "cover", sem esticar: só se recorta.
	const IMG_W = Math.max(CW, Math.round(ratio * CH));
	const IMG_H = Math.round(IMG_W / ratio);
	const left = Math.min(0, Math.max(CW - IMG_W, CW / 2 - focoX * IMG_W));
	const t = topoTexto ?? CH * 0.5;
	const p = (y: number) => `${((Math.max(0, Math.min(CH, y)) / CH) * 100).toFixed(2)}%`;
	const degrade = texto
		? `linear-gradient(to bottom, rgba(0,0,0,0.5) 0%, rgba(0,0,0,0) 16%, rgba(0,0,0,0) ${p(t - 320)}, rgba(0,0,0,0.55) ${p(t - 80)}, rgba(0,0,0,0.82) ${p(t + 160)}, rgba(0,0,0,0.88) 100%)`
		: 'linear-gradient(to bottom, rgba(0,0,0,0.35) 0%, rgba(0,0,0,0) 14%, rgba(0,0,0,0) 80%, rgba(0,0,0,0.7) 100%)';
	// Ícone: ocupa o espaço livre entre o kicker e o texto.
	const icTopo = M + (kicker ? 90 : 10);
	const icTam = Math.max(0, Math.min(440, t - 70 - icTopo));

	return (
		<AbsoluteFill style={{backgroundColor: mascara ? '#000' : cores.fundo, fontFamily, overflow: 'hidden'}}>
			{!mascara && !foto && (
				// Grade de pontos discreta, que some nas bordas
				<AbsoluteFill
					style={{
						backgroundImage: `radial-gradient(${cores.texto}22 1.6px, transparent 1.7px)`,
						backgroundSize: '36px 36px',
						maskImage: 'radial-gradient(ellipse at 50% 45%, black 30%, transparent 78%)',
						WebkitMaskImage: 'radial-gradient(ellipse at 50% 45%, black 30%, transparent 78%)',
					}}
				/>
			)}
			{!mascara && foto && (
				<>
					<Img src={staticFile(foto)} style={{position: 'absolute', left, top: Math.round((CH - IMG_H) / 2), width: IMG_W, height: IMG_H}} />
					<AbsoluteFill style={{background: degrade}} />
				</>
			)}

			{!mascara && !foto && icone && icTam > 120 && (
				<>
					<div
						style={{
							position: 'absolute',
							left: M - icTam * 0.25,
							top: icTopo - icTam * 0.25,
							width: icTam * 1.5,
							height: icTam * 1.5,
							borderRadius: '50%',
							background: numero ? 'none' : `radial-gradient(circle, ${cores.acento}2E 0%, ${cores.acento}00 65%)`,
						}}
					/>
					{/* Um só acento por cartela: com número-chave verde, o ícone fica todo na cor do texto. */}
					<Icone nome={icone} tamanho={icTam} cor={cores.texto} acento={numero ? cores.texto : cores.acento} style={{position: 'absolute', left: M - icTam * 0.06, top: icTopo}} />
				</>
			)}

			{/* Kicker em cima, à esquerda, com o quadradinho de acento */}
			{kicker && (
				<div
					style={{
						position: 'absolute',
						left: M,
						right: M,
						top: M,
						display: 'flex',
						alignItems: 'center',
						gap: 18,
						color: TEXTO,
						fontSize: 30,
						fontWeight: 700,
						letterSpacing: '0.22em',
						textTransform: 'uppercase',
						opacity: mascara ? 1 : 0.82,
					}}
				>
					<span style={{width: 18, height: 18, background: TEXTO, display: 'inline-block', flex: 'none'}} />
					{kicker}
				</div>
			)}

			{/* Bloco principal, ancorado em baixo e alinhado à margem esquerda */}
			<div ref={blocoRef} style={{position: 'absolute', left: M, right: M, bottom: CH - RODAPE_TOP + GAP_TEXTO_RODAPE}}>
				{numero && (
					<div style={{color: ACENTO, fontSize: tamanhoNumero(numero), fontWeight: 900, lineHeight: 0.95, letterSpacing: '-0.03em', marginBottom: 28, whiteSpace: 'nowrap'}}>
						{numero}
					</div>
				)}
				{texto ? <div style={{color: TEXTO, fontSize: fs, fontWeight: 800, lineHeight: ENTRELINHA, letterSpacing: '-0.02em', textWrap: 'pretty', textShadow: foto && !mascara ? '0 2px 18px rgba(0,0,0,0.45)' : 'none'}}>
					{antes}
					<span
						style={{
							whiteSpace: 'nowrap',
							backgroundImage: mascara ? 'none' : barra(cores['marca-texto']),
							color: mascara ? '#FFFFFF' : cores['texto-marca-texto'],
							padding: '0 8px 0.02em',
							margin: '0 -1px',
							borderRadius: 6,
							boxDecorationBreak: 'clone',
							WebkitBoxDecorationBreak: 'clone',
						}}
					>
						{destaque}
					</span>
					{depois}
				</div> : null}
				{contato && (
					<div
						style={{
							display: 'inline-flex',
							alignItems: 'center',
							gap: 16,
							marginTop: 48,
							background: mascara ? 'transparent' : cores.acento,
							color: mascara ? '#FFFFFF' : cores.fundo,
							borderRadius: 999,
							padding: '22px 40px',
							fontSize: 42,
							fontWeight: 800,
						}}
					>
						{contato}
					</div>
				)}
			</div>

			{/* Fonte do dado, pequena, entre o texto e o rodapé */}
			{fonteDado && (
				<div style={{position: 'absolute', left: M, right: M, top: RODAPE_TOP - 46, color: TEXTO, opacity: mascara ? 1 : 0.6, fontSize: 24, fontWeight: 600}}>
					Fonte: {fonteDado}
				</div>
			)}

			{/* Rodapé: selo e Instagram à esquerda, numeração à direita */}
			<div
				style={{
					position: 'absolute',
					left: M,
					right: M,
					top: RODAPE_TOP,
					height: RODAPE_H,
					display: 'flex',
					alignItems: 'center',
					justifyContent: 'space-between',
					color: TEXTO,
					fontSize: 28,
					fontWeight: 700,
				}}
			>
				<div style={{display: 'flex', alignItems: 'center', gap: 14}}>
					{selo && !mascara && <Img src={staticFile(selo)} style={{width: RODAPE_H, height: RODAPE_H, borderRadius: 10}} />}
					<span>{instagram}</span>
				</div>
				{semNumero ? null : (
					<span style={{fontVariantNumeric: 'tabular-nums', letterSpacing: '0.1em'}}>
						{String(n).padStart(2, '0')} / {String(total).padStart(2, '0')}
					</span>
				)}
			</div>
		</AbsoluteFill>
	);
};
