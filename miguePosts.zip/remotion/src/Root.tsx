import React from 'react';
import {Composition} from 'remotion';
import {Reels, ReelsBase, ReelsLegendas} from './Reels';
import {CARD, FPS, DURATION_FRAMES, W, H} from './config';
import {Cartela, CartelaProps, CW, CH} from './Cartela';

const cartelaDefault: CartelaProps = {
	n: 1,
	kicker: 'PRODUTIVIDADE',
	texto: 'Texto de exemplo com destaque.',
	destaque: 'destaque',
};

export const RemotionRoot: React.FC = () => (
	<>
		<Composition id="Reels" component={Reels} durationInFrames={DURATION_FRAMES} fps={FPS} width={W} height={H} />
		<Composition id="ReelsBase" component={ReelsBase} durationInFrames={DURATION_FRAMES} fps={FPS} width={W} height={H} />
		<Composition id="ReelsLegendas" component={ReelsLegendas} durationInFrames={DURATION_FRAMES} fps={FPS} width={CARD.w} height={CARD.h} />
		<Composition id="Cartela" component={Cartela} durationInFrames={1} fps={30} width={CW} height={CH} defaultProps={cartelaDefault} />
	</>
);
