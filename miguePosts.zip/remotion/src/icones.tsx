import React from 'react';

// Ícones de traço (grade 24x24), desenhados em código: entram nas cartelas e no Reels quando não há imagem,
// ou por cima de uma imagem. Cada ícone tem no máximo um traço na cor de acento (índice em `acento`).
type Def = {d: string[]; acento?: number};
export const ICONES: Record<string, Def> = {
	calendario: {d: ['M4 6h16v14H4z', 'M4 10h16', 'M8 3v5', 'M16 3v5', 'M8 14h2', 'M14 14h2', 'M8 17h2'], acento: 5},
	relogio: {d: ['M12 3a9 9 0 1 1 0 18a9 9 0 1 1 0-18', 'M12 7v5l3 2'], acento: 1},
	celular: {d: ['M8 2h8a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z', 'M10.5 18.5h3', 'M16 6.5h5'], acento: 2},
	conversa: {d: ['M4 5h16v11H9l-5 4z', 'M8 9h8', 'M8 12h5'], acento: 1},
	email: {d: ['M3 6h18v12H3z', 'M3 7l9 6 9-6'], acento: 1},
	reuniao: {d: ['M5 8a3 3 0 1 1 6 0a3 3 0 1 1-6 0', 'M13 8a3 3 0 1 1 6 0a3 3 0 1 1-6 0', 'M2 20c0-3.5 2.7-6 6-6s6 2.5 6 6', 'M14.5 14.2c3.6-.6 7.5 1.8 7.5 5.8'], acento: 1},
	pessoa: {d: ['M9 7a3 3 0 1 1 6 0a3 3 0 1 1-6 0', 'M5 21c0-4 3-7 7-7s7 3 7 7']},
	alvo: {d: ['M12 3a9 9 0 1 1 0 18a9 9 0 1 1 0-18', 'M12 7a5 5 0 1 1 0 10a5 5 0 1 1 0-10', 'M12 11a1 1 0 1 1 0 2a1 1 0 1 1 0-2'], acento: 2},
	check: {d: ['M12 3a9 9 0 1 1 0 18a9 9 0 1 1 0-18', 'M8 12.5l3 3 5-6'], acento: 1},
	lista: {d: ['M10 6h10', 'M10 12h10', 'M10 18h10', 'M3.5 5.5l1.5 1.5 3-3', 'M3.5 11.5l1.5 1.5 3-3', 'M4 18h3'], acento: 4},
	raio: {d: ['M13 2L4 14h7l-1 8 9-12h-7z'], acento: 0},
	cafe: {d: ['M4 9h12v6a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5z', 'M16 11h2a2 2 0 0 1 0 4h-2', 'M8 3v3', 'M12 3v3'], acento: 3},
	laptop: {d: ['M5 5h14v10H5z', 'M2 19h20l-2-4H4z', 'M9 10l2 2 4-4'], acento: 2},
	grafico: {d: ['M4 20h16', 'M5 14l5-5 3 3 6-6', 'M15 6h4v4'], acento: 1},
	lampada: {d: ['M12 3a6 6 0 0 1 3.5 10.9c-.9.7-1.5 1.6-1.5 2.6V17h-4v-.5c0-1-.6-1.9-1.5-2.6A6 6 0 0 1 12 3z', 'M9.5 20h5', 'M12 7v4'], acento: 2},
	ampulheta: {d: ['M6 3h12', 'M6 21h12', 'M7 3c0 4.5 4 6 5 9c1-3 5-4.5 5-9', 'M7 21c0-4.5 4-6 5-9c1 3 5 4.5 5 9'], acento: 3},
	pergunta: {d: ['M9 9a3 3 0 1 1 4.5 2.6c-.9.5-1.5 1.2-1.5 2.4v1', 'M12 18.5v.5'], acento: 1},
	olho: {d: ['M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z', 'M12 9a3 3 0 1 1 0 6a3 3 0 1 1 0-6'], acento: 1},
	bloqueio: {d: ['M12 3a9 9 0 1 1 0 18a9 9 0 1 1 0-18', 'M5.6 5.6l12.8 12.8'], acento: 1},
	seta: {d: ['M4 12h15', 'M13 6l6 6-6 6'], acento: 1},
	pilha: {d: ['M4 6h16v4H4z', 'M4 10h16v4H4z', 'M4 14h16v4H4z', 'M17 3l3 3'], acento: 3},
	casa: {d: ['M3 11l9-7 9 7', 'M5 10v10h14V10', 'M10 20v-5h4v5'], acento: 2},
	cerebro: {d: ['M12 5a3 3 0 0 0-5.8 1A3 3 0 0 0 4 11a3 3 0 0 0 2 5 3 3 0 0 0 6 1V5z', 'M12 5a3 3 0 0 1 5.8 1A3 3 0 0 1 20 11a3 3 0 0 1-2 5 3 3 0 0 1-6 1', 'M9 10h3', 'M12 13h3'], acento: 3},
	pausa: {d: ['M12 3a9 9 0 1 1 0 18a9 9 0 1 1 0-18', 'M10 9v6', 'M14 9v6'], acento: 2},
};
export const NOMES_ICONES = Object.keys(ICONES);

// progresso 0..1 desenha o traço (para animar); 1 = ícone completo.
export const Icone: React.FC<{nome: string; tamanho: number; cor: string; acento: string; progresso?: number; espessura?: number; style?: React.CSSProperties}> = ({
	nome,
	tamanho,
	cor,
	acento,
	progresso = 1,
	espessura = 1.6,
	style,
}) => {
	const def = ICONES[nome];
	if (!def) throw new Error(`Ícone "${nome}" não existe. Use um destes: ${NOMES_ICONES.join(', ')}`);
	const n = def.d.length;
	return (
		<svg width={tamanho} height={tamanho} viewBox="0 0 24 24" fill="none" strokeLinecap="round" strokeLinejoin="round" style={style}>
			{def.d.map((d, i) => {
				// cada traço desenha na sua vez; o de acento por último
				const ini = i / (n + 1);
				const p = Math.max(0, Math.min(1, (progresso - ini) / (1.6 / (n + 1))));
				return (
					<path
						key={i}
						d={d}
						pathLength={1}
						stroke={i === def.acento ? acento : cor}
						strokeWidth={i === def.acento ? espessura * 1.15 : espessura}
						strokeDasharray="1 1"
						strokeDashoffset={1 - p}
					/>
				);
			})}
		</svg>
	);
};
