// Composição do Reels: 1080x1920 @ 30 fps. Tudo em píxeis.
// Os dados de cada peça vêm de reels.json (gerado por scripts/remotion_reels.py).
import dados from '../reels.json';
import type {Cores} from './Cartela';

export const W = 1080;
export const H = 1920;
export const FPS = 30;

export const DURATION_FRAMES: number = dados.duracaoFrames;
export const CORES: Cores = dados.cores as Cores;
export const FONTE: string = (dados as {fonte?: string}).fonte ?? 'Poppins';
export const SELO: string | null = ((dados as {selo?: string | null}).selo ?? null) as string | null;

// Painel das cenas (em cima, cantos arredondados até y=1080)
export const PANEL = {x: 40, y: 40, w: 1000, h: 1040, r: 48};
// Card do avatar (em baixo, a partir de y=1110, até y=1880)
export const CARD = {x: 40, y: 1110, w: 1000, h: 770, r: 48};

// Avatar: fotograma mostrado com 650 px de largura, centrado.
// srcAnchorY = topo da cabeça medido no WebM; fica em anchorY (1090): só o topo da cabeça passa a borda (1110).
export const AVATAR = {
	src: dados.avatar.src as string,
	srt: dados.avatar.srt as string,
	srcW: dados.avatar.srcW as number,
	srcH: dados.avatar.srcH as number,
	scale: ((dados.avatar as {escala?: number}).escala ?? 650 / (dados.avatar.srcW as number)) as number,
	srcHeadX: (dados.avatar.srcW as number) / 2,
	srcAnchorY: dados.avatar.topoCabeca as number,
	anchorX: 540,
	anchorY: 1090,
	// Sem recorte: o vídeo é opaco (com o cenário) e preenche o card, centrado na cara (fx, fy em fração).
	opaco: Boolean((dados.avatar as {opaco?: boolean}).opaco),
	fx: ((dados.avatar as {fx?: number}).fx ?? 0.5) as number,
	fy: ((dados.avatar as {fy?: number}).fy ?? 0.3) as number,
};
// Legendas no peito, abaixo do queixo
export const LEGENDA_TOP: number = dados.legendaTop;

export const TRANSICAO = 12; // fotogramas do deslize entre cenas

// Dados de um plano de motion do painel. As formas são desenhadas no Remotion.
export type Barra = {rotulo: string; valor: number; exibicao?: string};
export type Cena = {
  tipo: 'texto';
  inicio: number;
  kicker?: string;
  numero?: string;
  texto?: string;
  destaque?: string;
  icone?: string | null;
  barras?: Barra[] | null;
  enquadramento?: number;
};
export const CENAS: Cena[] = dados.cenas as Cena[];

// Palavra(s) em marca-texto por bloco do SRT (em maiúsculas, com a pontuação como no SRT)
export const DESTAQUES: Record<string, string[]> = dados.destaques;

// Fecho: botão e Instagram a partir de FIM_INICIO
export const FIM_INICIO: number = dados.fimInicio;
export const CTA: {botao: string; instagram: string} = dados.cta;

// A composição de exemplo não traz arquivos de áudio do catálogo.
export const TEM_TRILHA = Boolean((dados as {fonteTrilha?: string}).fonteTrilha);
export const MUSICA_VOLUME = 0.14;
