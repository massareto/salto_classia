import React, {useEffect, useState} from 'react';
import {
	AbsoluteFill,
	Audio,
	Img,
	OffthreadVideo,
	continueRender,
	delayRender,
	Easing,
	interpolate,
	spring,
	staticFile,
	useCurrentFrame,
	useVideoConfig,
} from 'remotion';
import {fonte} from './fontes';
import type {Barra} from './config';
import {Icone} from './icones';
import {
	AVATAR,
	CARD,
	CENAS,
	CORES,
	CTA,
	DESTAQUES,
	DURATION_FRAMES,
	FIM_INICIO,
	FONTE,
	LEGENDA_TOP,
	MUSICA_VOLUME,
	PANEL,
	SELO,
	TEM_TRILHA,
	TRANSICAO,
} from './config';

const {fontFamily} = fonte(FONTE);
const ease = Easing.bezier(0.65, 0, 0.35, 1);
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// Progresso do deslize que leva à cena i (0..1).
const slideP = (frame: number, i: number) =>
	interpolate(frame, [CENAS[i].inicio, CENAS[i].inicio + TRANSICAO], [0, 1], {...clamp, easing: ease});

const Grafico: React.FC<{barras: Barra[]; frame: number; altura: number}> = ({barras, frame, altura}) => {
  const maior = Math.max(1, ...barras.map(({valor}) => valor));
  const coluna = 800 / barras.length;
  return (
    <svg width="100%" height={altura} viewBox="0 0 800 340" style={{position: 'relative', marginBottom: 24}}>
      <path d="M0 296 H800" stroke={CORES.texto} strokeOpacity=".45" strokeWidth="3" />
      {barras.map(({rotulo, valor, exibicao}, i) => {
        const entrada = interpolate(frame, [i * 4, i * 4 + 23], [0, 1], {...clamp, easing: ease});
        const x = coluna * (i + .5);
        const h = entrada * 220 * valor / maior;
        return (
          <g key={i}>
            <rect x={x - coluna * .29} y={296 - h} width={coluna * .58} height={h} rx="12" fill={i === barras.length - 1 ? CORES.acento : CORES.texto} />
            <text x={x} y={278 - h} textAnchor="middle" fill={CORES.texto} fontSize="34" fontWeight="800">{exibicao ?? valor}</text>
            <text x={x} y="332" textAnchor="middle" fill={CORES.texto} fontSize="25">{rotulo}</text>
          </g>
        );
      })}
    </svg>
  );
};

// Número-chave que conta de 0 até ao valor ("23 MIN" conta 0..23).
const conta = (numero: string, p: number) => {
	const m = numero.match(/^(\d+)(.*)$/);
	return m ? `${Math.round(+m[1] * p)}${m[2]}` : numero;
};

const CartaoTexto: React.FC<{i: number; frame: number; fps: number}> = ({i, frame, fps}) => {
	const c = CENAS[i];
	// A 1.ª cena (o gancho) já está montada no primeiro fotograma.
	const local = frame - c.inicio + (i === 0 ? 60 : 0);
	const texto = c.texto ?? '';
	const destaque = c.destaque ?? '';
	const k = destaque ? texto.indexOf(destaque) : -1;
	// Pedaços: palavras normais e o destaque inteiro como uma peça só.
	const pecas: {t: string; hl: boolean; cola?: boolean; pos?: string}[] = [];
	const empurra = (s: string) =>
		s.split(' ').forEach((w, j) => {
			if (!w) return;
			// Pontuação colada à peça anterior ("some" + "?") fica junto dela, sem espaço no meio.
			if (j === 0 && !s.startsWith(' ') && pecas.length && /^[?!.,:;]+$/.test(w)) pecas.push({t: w, hl: false, cola: true});
			else pecas.push({t: w, hl: false});
		});
	if (k >= 0) {
		empurra(texto.slice(0, k));
		// Pontuação logo depois do destaque ("amanhã" + "?") vai na mesma peça, para nunca cair sozinha na linha de baixo.
		const resto = texto.slice(k + destaque.length);
		const pont = resto.match(/^[?!.,:;]+/)?.[0] ?? '';
		pecas.push({t: destaque, hl: true, pos: pont});
		empurra(resto.slice(pont.length));
	} else empurra(texto);
	const n = pecas.length + (c.numero ? 1 : 0);
	const passo = Math.max(2, Math.min(4, Math.floor(18 / Math.max(1, n))));
	const entra = (j: number) => spring({frame: local - 4 - j * passo, fps, config: {damping: 15, stiffness: 180}});
	let tamanho = texto.length > 70 ? 74 : texto.length > 40 ? 88 : 104;
	// Ícone: desenha-se em ~20 fotogramas e depois flutua.
	const desenho = interpolate(frame - c.inicio, [0, 22], [0, 1], {...clamp, easing: ease});
	const flutua = Math.sin((frame - c.inicio) / 14) * 10;
	const pulso = 1 + 0.04 * Math.sin((frame - c.inicio) / 9);
	// O ícone entra no bloco, por cima do número e do texto, com o tamanho que sobra (some se sobrar pouco).
	// Com ícone e pouco espaço, a letra desce de tamanho (até 64 px) para o ícone caber com pelo menos 200 px.
	const livreCom = (tm: number) =>
		PANEL.h - 96 - (c.kicker ? 150 : 90) - (Math.ceil(texto.length / Math.max(1, Math.floor(856 / (tm * 0.6)))) + 1) * tm * 1.16 - (c.numero ? 224 : 0) - 36;
	while ((c.icone || c.barras) && livreCom(tamanho) < 220 && tamanho > 64) tamanho -= 6;
	const livre = livreCom(tamanho);
	const ic = c.icone ? Math.min(380, Math.max(150, livre)) : 0;

	return (
		<AbsoluteFill style={{background: CORES.fundo, padding: c.enquadramento ? '0 88px 152px' : '0 72px 96px', justifyContent: 'flex-end', fontFamily}}>

			<AbsoluteFill
				style={{
					backgroundImage: `radial-gradient(${CORES.texto}22 1.6px, transparent 1.7px)`,
					backgroundSize: '36px 36px',
					backgroundPosition: `${(frame * 0.6) % 36}px ${(frame * 0.35) % 36}px`,
					maskImage: 'radial-gradient(ellipse at 50% 45%, black 30%, transparent 78%)',
					WebkitMaskImage: 'radial-gradient(ellipse at 50% 45%, black 30%, transparent 78%)',
				}}
			/>
			{c.kicker && (
				<div
					style={{
						position: 'absolute',
						top: 72,
						left: 72,
						right: SELO ? 196 : 72,
						display: 'flex',
						alignItems: 'center',
						gap: 16,
						color: CORES.texto,
						opacity: 0.82 * entra(0),
						fontSize: c.kicker.length > 34 ? 24 : 30,
						fontWeight: 700,
						letterSpacing: c.kicker.length > 34 ? '0.10em' : '0.22em',
						lineHeight: 1.35,
					}}
				>
					<span style={{width: 18, height: 18, flexShrink: 0, background: CORES.texto, display: 'inline-block'}} />
					<span style={{minWidth: 0, overflowWrap: 'anywhere'}}>{c.kicker.toUpperCase()}</span>
				</div>
			)}
			{ic >= 150 ? (
				<div style={{position: 'relative', width: ic, height: ic, marginBottom: 28, marginLeft: -8, transform: `translateY(${flutua}px)`}}>
					<div
						style={{
							position: 'absolute',
							inset: -ic * 0.3,
							borderRadius: '50%',
							background: c.numero ? `radial-gradient(circle, ${CORES.texto}1A 0%, ${CORES.texto}00 62%)` : `radial-gradient(circle, ${CORES.acento}33 0%, ${CORES.acento}00 62%)`,
							transform: `scale(${pulso})`,
						}}
					/>
					{/* Um só acento por cena: com número-chave verde, o ícone fica todo na cor do texto. */}
					<Icone nome={c.icone as string} tamanho={ic} cor={CORES.texto} acento={c.numero ? CORES.texto : CORES.acento} progresso={desenho} style={{position: 'absolute', left: 0, top: 0}} />
				</div>
			) : null}
			{c.barras && <Grafico barras={c.barras} frame={frame - c.inicio} altura={Math.min(420, Math.max(175, livre))} />}
			{c.numero && (
				<div
					style={{
						color: CORES.acento,
						fontSize: 210,
						fontWeight: 900,
						lineHeight: 0.95,
						letterSpacing: '-0.03em',
						marginBottom: 24,
						transform: `translateY(${(1 - entra(0)) * 60}px) scale(${0.85 + 0.15 * entra(0)})`,
						transformOrigin: 'left bottom',
						opacity: entra(0),
						position: 'relative',
					}}
				>
					{conta(c.numero, interpolate(local, [0, 20], [0, 1], {...clamp, easing: ease}))}
				</div>
			)}
			<div style={{color: CORES.texto, fontSize: tamanho, fontWeight: 800, lineHeight: 1.16, letterSpacing: '-0.02em', position: 'relative'}}>
				{pecas.map((p, j) => {
					const e = entra(j + (c.numero ? 1 : 0));
					const varre = interpolate(local, [8 + j * passo + 6, 8 + j * passo + 16], [0, 100], {...clamp, easing: ease});
					return (
						<span
							key={j}
							style={{
								display: 'inline-block',
								marginRight: pecas[j + 1]?.cola ? 0 : '0.24em',
								transform: `translateY(${(1 - e) * 50}px)`,
								opacity: e,
							}}
						>
							{p.hl ? (
								// A barra varre e, por baixo dela, a letra troca de cor no mesmo ponto (texto recortado pelo degradê).
								<span
									style={{
										// 1.ª camada (por cima) apara a barra à altura das letras; 2.ª é a barra que varre.
										backgroundImage: `linear-gradient(to bottom, ${CORES.fundo} 16%, transparent 16%, transparent 90%, ${CORES.fundo} 90%), linear-gradient(to right, ${CORES['marca-texto']} ${varre}%, transparent ${varre}%)`,
										padding: '0 7px',
										margin: '0 -7px',
										borderRadius: 8,
									}}
								>
									<span
										style={{
											backgroundImage: `linear-gradient(to right, ${CORES['texto-marca-texto']} ${varre}%, ${CORES.texto} ${varre}%)`,
											WebkitBackgroundClip: 'text',
											backgroundClip: 'text',
											color: 'transparent',
										}}
									>
										{p.t}
									</span>
								</span>
							) : (
								p.t
							)}
							{p.pos ?? null}
						</span>
					);
				})}
			</div>
		</AbsoluteFill>
	);
};

const Cena: React.FC<{i: number; frame: number; fps: number}> = ({i, frame, fps}) => {
	const c = CENAS[i];
	let x = 0;
	if (i > 0 && frame < c.inicio + TRANSICAO) x = (1 - slideP(frame, i)) * PANEL.w;
	else if (i < CENAS.length - 1 && frame >= CENAS[i + 1].inicio) x = -slideP(frame, i + 1) * PANEL.w;
	return (
		<AbsoluteFill style={{transform: `translateX(${x}px)`, overflow: 'hidden'}}>
			<CartaoTexto i={i} frame={frame} fps={fps} />
		</AbsoluteFill>
	);
};

// Linha de acento na junção das duas cenas durante o deslize.
const Junta: React.FC<{frame: number}> = ({frame}) => {
	const i = CENAS.findIndex((c, k) => k > 0 && frame >= c.inicio && frame < c.inicio + TRANSICAO);
	if (i < 0) return null;
	const x = (1 - slideP(frame, i)) * PANEL.w;
	return <div style={{position: 'absolute', left: x - 3, top: 0, width: 6, height: PANEL.h, background: CORES.acento, boxShadow: `0 0 24px 4px ${CORES.acento}88`}} />;
};

type Cue = {n: number; start: number; end: number; text: string};
const toSec = (s: string) => {
	const [h, m, rest] = s.split(':');
	const [sec, ms] = rest.split(',');
	return +h * 3600 + +m * 60 + +sec + +ms / 1000;
};
const parseSrt = (srt: string): Cue[] =>
	srt
		.replace(/\r/g, '')
		.trim()
		.split(/\n\n+/)
		.map((b) => {
			const [n, time, ...txt] = b.split('\n');
			const [a, z] = time.split(' --> ');
			return {n: +n, start: toSec(a), end: toSec(z), text: txt.join(' ')};
		});

const Legendas: React.FC<{cues: Cue[]; frame: number; fps: number}> = ({cues, frame, fps}) => {
	const t = frame / fps;
	const k = cues.findIndex((c, j) => t >= c.start && t < (j < cues.length - 1 ? cues[j + 1].start : c.end + 0.4));
	if (k < 0) return null;
	const cue = cues[k];
	const entrada = spring({frame: frame - Math.round(cue.start * fps), fps, config: {damping: 14, stiffness: 220}});
	const destaques = DESTAQUES[String(cue.n)] ?? [];
	return (
		<div
			style={{
				position: 'absolute',
				top: LEGENDA_TOP,
				left: CARD.x + 60,
				width: CARD.w - 120,
				textAlign: 'center',
				fontFamily,
				fontWeight: 900,
				fontSize: 64,
				lineHeight: 1.25,
				color: CORES.texto,
				textShadow: '0 4px 14px rgba(0,0,0,0.8), 0 0 3px rgba(0,0,0,0.95)',
				transform: `scale(${0.85 + 0.15 * entrada})`,
				opacity: entrada,
			}}
		>
			{cue.text
				.toUpperCase()
				.split(' ')
				.map((w, j) => (
					<span key={j}>
						<span
							style={
								destaques.includes(w)
									? {background: CORES['marca-texto'], color: CORES['texto-marca-texto'], padding: '0 14px', borderRadius: 8, textShadow: 'none'}
									: {}
							}
						>
							{w}
						</span>{' '}
					</span>
				))}
		</div>
	);
};

// Fecho: o painel vira a chamada (botão em acento + Instagram).
const Fim: React.FC<{frame: number; fps: number}> = ({frame, fps}) => {
	if (frame < FIM_INICIO) return null;
	const e = spring({frame: frame - FIM_INICIO, fps, config: {damping: 14}});
	const pulso = 1 + 0.035 * Math.sin((frame - FIM_INICIO) / 5);
	return (
		<AbsoluteFill style={{background: CORES.fundo, justifyContent: 'center', alignItems: 'center', opacity: e, fontFamily}}>
      <svg width={PANEL.w} height={PANEL.h} style={{position: 'absolute'}}>
        {[245, 310, 380].map((r, i) => (
          <circle key={r} cx={PANEL.w / 2} cy={PANEL.h / 2} r={r * (.7 + .3 * e)}
            fill="none" stroke={CORES.acento} strokeWidth="2" opacity={(.18 - i * .035) * e} />
        ))}
      </svg>
			<div
				style={{
					background: CORES.acento,
					color: CORES.fundo,
					fontWeight: 900,
					fontSize: CTA.botao.length > 16 ? 58 : 70,
					padding: '24px 52px',
					whiteSpace: 'nowrap',
					borderRadius: 999,
					transform: `scale(${(0.7 + 0.3 * e) * pulso})`,
					boxShadow: `0 0 ${30 + 20 * (pulso - 1) * 28}px ${CORES.acento}66`,
					textAlign: 'center',
				}}
			>
				{CTA.botao}
			</div>
			<div style={{color: CORES.texto, fontWeight: 800, fontSize: 60, marginTop: 30, transform: `translateY(${(1 - e) * 30}px)`}}>
				{CTA.instagram}
			</div>
		</AbsoluteFill>
	);
};

// A base contém painel, card e música. O clipe HeyGen já traz sua própria fala.
export type Camada = 'tudo' | 'base' | 'legendas';

export const ReelsLegendas: React.FC = () => <Reels camada="legendas" />;
export const ReelsBase: React.FC = () => <Reels camada="base" />;

export const Reels: React.FC<{camada?: Camada}> = ({camada = 'tudo'}) => {
	const frame = useCurrentFrame();
	const {fps} = useVideoConfig();
	const [cues, setCues] = useState<Cue[] | null>(null);
	const [handle] = useState(() => delayRender('legendas'));

	useEffect(() => {
		fetch(staticFile(AVATAR.srt))
			.then((r) => r.text())
			.then((t) => {
				setCues(parseSrt(t));
				continueRender(handle);
			});
	}, [handle]);

	const avW = AVATAR.srcW * AVATAR.scale;
	const avH = AVATAR.srcH * AVATAR.scale;
	const avLeft = AVATAR.anchorX - AVATAR.srcHeadX * AVATAR.scale;
	const avTop = AVATAR.anchorY - AVATAR.srcAnchorY * AVATAR.scale;
	const cardBottom = CARD.y + CARD.h;

	if (camada === 'legendas') {
		return (
			<AbsoluteFill style={{background: 'transparent'}}>
				<div style={{position: 'absolute', left: -CARD.x, top: -CARD.y, width: 1080, height: 1920}}>
					{cues ? <Legendas cues={cues} frame={frame} fps={fps} /> : null}
				</div>
			</AbsoluteFill>
		);
	}
	const base = camada === 'base';

	return (
		<AbsoluteFill style={{background: CORES.fundo}}>
			{/* Painel das cenas */}
			<div
				style={{
					position: 'absolute',
					left: PANEL.x,
					top: PANEL.y,
					width: PANEL.w,
					height: PANEL.h,
					borderRadius: PANEL.r,
					overflow: 'hidden',
					background: CORES.fundo,
					border: `2px solid ${CORES.texto}26`,
				}}
			>
				{CENAS.map((c, i) => {
					const visivel = frame < FIM_INICIO && frame >= c.inicio && (i === CENAS.length - 1 || frame < CENAS[i + 1].inicio + TRANSICAO);
					return visivel ? <Cena key={i} i={i} frame={frame} fps={fps} /> : null;
				})}
				<Junta frame={frame} />
				<Fim frame={frame} fps={fps} />
				{SELO && <Img src={staticFile(SELO)} style={{position: 'absolute', top: 56, right: 56, width: 72, height: 72, borderRadius: 16}} />}
			</div>

			{/* Card do avatar */}
			<div style={{position: 'absolute', left: CARD.x, top: CARD.y, width: CARD.w, height: CARD.h, borderRadius: CARD.r, background: CORES.cartao}} />

			{/* Avatar sem recorte: preenche o card com o cenário, degradê embaixo para a legenda */}
			{!base && AVATAR.opaco && (
				<div style={{position: 'absolute', left: CARD.x, top: CARD.y, width: CARD.w, height: CARD.h, borderRadius: CARD.r, overflow: 'hidden'}}>
					<OffthreadVideo
						src={staticFile(AVATAR.src)}
						style={{width: '100%', height: '100%', objectFit: 'cover', objectPosition: `${AVATAR.fx * 100}% ${AVATAR.fy * 100}%`}}
					/>
					<AbsoluteFill style={{background: 'linear-gradient(to bottom, rgba(0,0,0,0) 55%, rgba(0,0,0,0.75) 100%)'}} />
				</div>
			)}

			{/* Avatar recortado: só o topo da cabeça passa a borda de cima do card */}
			{!base && !AVATAR.opaco && <div
				style={{
					position: 'absolute',
					left: CARD.x,
					top: 0,
					width: CARD.w,
					height: cardBottom,
					overflow: 'hidden',
					borderBottomLeftRadius: CARD.r,
					borderBottomRightRadius: CARD.r,
				}}
			>
				<OffthreadVideo
					src={staticFile(AVATAR.src)}
					transparent
					style={{
						position: 'absolute',
						left: avLeft - CARD.x,
						top: avTop,
						width: avW,
						height: avH,
						maskImage: 'linear-gradient(to right, transparent 0%, black 9%, black 91%, transparent 100%)',
						WebkitMaskImage: 'linear-gradient(to right, transparent 0%, black 9%, black 91%, transparent 100%)',
					}}
				/>
			</div>}

			{cues && !base ? <Legendas cues={cues} frame={frame} fps={fps} /> : null}

			{TEM_TRILHA ? <Audio
				src={staticFile('musica.wav')}
				volume={(f) => MUSICA_VOLUME * interpolate(f, [0, 9, DURATION_FRAMES - 30, DURATION_FRAMES], [0, 1, 1, 0], clamp)}
			/> : null}
		</AbsoluteFill>
	);
};
