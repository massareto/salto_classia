// Renderiza várias imagens paradas (cartelas, máscaras, estático) com um só bundle e um só navegador.
// Bem mais rápido do que chamar `npx remotion still` uma vez por imagem (cada chamada refaz o bundle e abre o Chrome).
// Uso: node stills.mjs src/index.ts trabalhos.json   (trabalhos.json = [{"id": "Cartela", "props": {...}, "out": "/x/01.png"}, ...])
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {bundle} from '@remotion/bundler';
import {openBrowser, renderStill, selectComposition} from '@remotion/renderer';

const [, , entrada, arquivo] = process.argv;
const trabalhos = JSON.parse(fs.readFileSync(arquivo, 'utf8'));
const serveUrl = await bundle({entryPoint: path.resolve(entrada)});
const browser = await openBrowser('chrome');
const paralelo = Math.max(1, Math.min(4, os.cpus().length));
let i = 0;
const fila = async () => {
	while (i < trabalhos.length) {
		const t = trabalhos[i++];
		const composition = await selectComposition({serveUrl, id: t.id, inputProps: t.props, puppeteerInstance: browser, logLevel: 'error'});
		await renderStill({composition, serveUrl, output: t.out, inputProps: t.props, puppeteerInstance: browser, logLevel: 'error'});
	}
};
await Promise.all(Array.from({length: paralelo}, fila));
await browser.close({silent: true});
