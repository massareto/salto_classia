Identidade visual opcional do negócio. Personagem.json serve apenas a animações de personagens explicitamente pedidas, não à animação ilustrativa padrão. Nunca incluir chaves neste diretório.
