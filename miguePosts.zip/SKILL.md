---
name: migueposts
description: "Criar posts de venda para serviços a partir de uma notícia recente: animação narrada com motion graphics feito em código, carrossel, estático e Reels editado com avatar HeyGen quando disponível. Usar para rodar o miguePosts ou criar conteúdo para divulgar um serviço."
---

# miguePosts

Equipe de conteúdo para quem vende um serviço. Usa uma notícia real do nicho para explicar um conceito, mostrar a leitura do dono e convidar o público para uma ação concreta. As peças compartilham o mesmo argumento: gancho → notícia → relevância para o público → o que eu faria → convite.

## Dependências e instalação

1. Antes de produzir, conferir **Python 3.12+**, **Node.js com npm** e **FFmpeg com ffprobe** no PATH. Instalar o que faltar com o gerenciador de pacotes do ambiente.
2. Na pasta da skill, criar o ambiente Python se ainda não existir e instalar os pacotes de `requirements.txt`. Instalar o **Remotion local do projeto e seu navegador de renderização** com `scripts/aquecer.py`, que usa o lockfile do npm. Aguardar o preparo terminar antes de renderizar.

   ```bash
   python3 -m venv .venv
   .venv/bin/python -m pip install -r requirements.txt
   .venv/bin/python scripts/aquecer.py
   ```

3. Enquanto a pauta é pesquisada, preparar o render local e verificar a conexão **HeyGen** para as frentes de vídeo. Ver [configuração e conexões](references/configuracao.md).

## Entregas e dependências

| Peça | Entrega | Requisito |
|---|---|---|
| Animação em motion graphics | `entrega/animacao.mp4`, vertical 1080×1920, aproximadamente 35–50 segundos | narração HeyGen, com trilha do catálogo quando disponível |
| Carrossel | sete PNGs 1080×1350, HTML e PDF | retrato gerado do apresentador na capa e no fechamento |
| Estático | `entrega/estatico.png`, 1080×1350 e legenda | retrato gerado do apresentador |
| Reels | `entrega/reels.mp4`, vertical 1080×1920, aproximadamente 35–45 segundos | avatar HeyGen, edição concluída e trilha do catálogo quando disponível |
| Resumo | `entrega/RESUMO.md` | fontes, legendas, decisões, peças omitidas e revisão |

Resolva o avatar automaticamente pelo procedimento em [voz e avatar no HeyGen](references/voz-heygen.md). Priorize um avatar privado de vídeo pronto. Use um avatar privado de foto pronto caso nenhum de vídeo esteja disponível. Se a conta não tiver avatar utilizável, omita o Reel, informe o motivo e conclua as demais peças viáveis. Se a voz HeyGen estiver indisponível, entregue os formatos visuais viáveis.

## Caminhos

- `<habilidade>`: esta pasta, que contém `SKILL.md`, `equipe/`, `scripts/`, `remotion/` e `animacao/`.
- `<projeto>`: pasta do negócio com `CONTEXTO.md`. Para outro serviço, criar contexto próprio a partir de `CONTEXTO-modelo.md`, sem substituir o negócio anterior.
- Definir `MARKETING_COACHES_PROJETO=<projeto>` em **todas** as chamadas de scripts. Evita ler o contexto errado em instalações globais ou por link simbólico.
- `<pasta>`: `<projeto>/conteudos/<AAAA-MM-DD>_<Servico>_Noticia/`, com `trabalho/` e `entrega/`.
- Guarde a referência autorizada do apresentador na área privada do projeto. Use `fotos-coach/` para fotos já fornecidas.

Em projetos da aula, use o contexto e a pesquisa de público como fontes. Leia `CONTEXTO.md` e `PUBLICO.md` ou `CONTEXT.md` e `AUDIENCE.md`, conforme os arquivos do projeto. Adapte os dados confirmados ao `CONTEXTO-modelo.md` em uma cópia de trabalho privada com o nome `CONTEXTO.md` para os scripts. Preserve os arquivos de origem e descarte os dados de exemplo.

## Início obrigatório: conferir e perguntar apenas o que faltar

O orquestrador faz Helena (`equipe/22_helena_prado.md`) e Paula (`equipe/01_paula_teixeira.md`). Leia o pedido e o contexto antes de perguntar.

1. Conferir **produto/serviço** e **público**. O convite das quatro peças é conversar no Direct.
2. Perguntar somente os campos que não foram respondidos. Reunir as lacunas numa única mensagem e aguardar as respostas. Não tratar silêncio, passagem do tempo, opção pré-selecionada ou conhecimento genérico do dono como confirmação.
3. Se tudo já foi informado, não repetir perguntas. Se o usuário autorizar expressamente sugestões/assunções, usar essa autorização e distinguir escolhas editoriais de dados confirmados.
4. Encaminhar a consulta de avatar e voz à frente de vídeo enquanto a pauta é preparada. Este preparo técnico não bloqueia a escrita nem as peças visuais.
5. Salvar `CONTEXTO.md` e `trabalho/00_briefing.md`. Não pesquisar, sintetizar ou renderizar com público ainda inventado sem autorização.

## Voz, avatar e imagens

- **Voz e avatar: MCP do HeyGen.** Envie o roteiro à ferramenta de vídeo de avatar para receber o Reel já falado. Use a ferramenta de narração só para a animação. Use a voz resolvida e a cadência de conversa. Ver `references/voz-heygen.md`. Sem substituição automática por Piper, ElevenLabs ou uma gravação antiga. Voz diferente só se autorizada pelo usuário.
- **Retratos para carrossel e estático:** extraia uma referência nítida do look privado autorizado da própria pessoa no HeyGen. Gere novas fotografias com HeyGen Image ou Look Remix quando disponível. Use geração nativa com a mesma referência como alternativa. Produza uma composição própria para a capa, o fechamento do carrossel e o estático. Harmonize ambiente, luz e ação com a pauta. Compare rosto, idade, cabelo, pele e proporções com a referência antes de exportar. Siga [a referência de imagens](references/imagens-identidade.md).
- Busque a foto no HeyGen durante o preparo e disponibilize a referência às duas frentes. Se o look não fornecer referência utilizável, procure uma foto autorizada já anexada ou no projeto. Se faltar uma referência ou um gerador capaz de usá-la, registre o bloqueio dessas peças e siga com as entregas viáveis.
- Preferir conexão nativa/MCP. Configuração segura em `references/configuracao.md`; não colocar chaves em chat, contexto, ZIP ou logs.
- Na animação, o HeyGen fornece a narração e a trilha. O Remotion gera todo o visual em código, do gancho ao fechamento.

## Textos sem siglas

**Escrever por extenso em roteiro, narração, legendas, cartelas, estático e textos na tela.** Escrever “inteligência artificial”, nunca “IA”, “I.A.” ou “AI”. Expandir também outras siglas do tema com seu significado correto; se não souber o significado, conferir ou reformular. Não basta inserir pontos para forçar a pronúncia.

Nomes próprios, palavras de convite e rótulos técnicos de configuração não são siglas a expandir. Preservar identificadores e URLs. `para_voz` expande algumas siglas conhecidas como defesa adicional; a revisão editorial continua responsável pelas demais. Adaptar o comprimento do texto para manter leitura e duração naturais.

## Animação 100% em motion graphics

Henrique (`equipe/16_henrique_sato.md`) escreve o roteiro e descreve a ação gráfica de cada plano. Bruno implementa e anima os gráficos no Remotion/React com elementos SVG, formas, texto e propriedades CSS. Escolha linguagem visual e movimentos ligados ao nicho e à história.

- Use cenas `tipo: "motion"` com `planos` definidos por dados e visuais implementados em código. Em até dois segundos, faça uma mudança perceptível que acompanhe a fala: desenhar conexões, animar dados, fazer etapas entrarem ou transformar formas. Toda a peça, inclusive a capa e o convite final, é renderizada em código. Proíba imagens geradas, fotos, banco de imagens, recortes, clipes, avatares e slideshows na animação.
- Abra com um momento reconhecível pelo público, faça a notícia mudar a leitura do problema e entregue uma saída em tom de conversa. Use a tomada HeyGen da própria peça. O fechamento gráfico é narrado e convida ao Direct.
- Selecione trilhas instrumentais com entrada rápida e batida marcada no [catálogo do HeyGen](references/trilhas-dinamicas.md). Combine gênero, andamento e acentos com o nicho e com a edição. Mixe abaixo da voz e registre a faixa escolhida.

## Equipe e fluxo

Leia `equipe/00_regras_comuns.md`. Helena confirma o briefing e Paula prepara os recursos técnicos. Marcos pesquisa e Beatriz salva a notícia verificada em `trabalho/noticia.json`. A notícia, o contexto e o convite são a base comum. O aquecimento do Remotion e a consulta ao HeyGen podem avançar enquanto a notícia é pesquisada.

Assim que a pauta estiver disponível, **acione as quatro frentes em paralelo, na mesma rodada**. Comece as tarefas independentes de cada frente assim que seus insumos existirem. Aproveite o processamento externo para avançar arte, montagem, revisão ou entrega das outras frentes. Entregue a cada subagente a pauta, o contexto, a pasta da peça e os papéis que ele deve executar. Cada frente escreve seu gancho, desenvolve seu próprio texto ou roteiro, revisa, produz e finaliza usando os arquivos daquela peça. Gustavo apoia os ganchos em paralelo à escrita, sem centralizar a liberação das aberturas num arquivo único.

- **Reel · Caio, Rafael, Diego e Tiago.** Caio escreve a fala em tom de história e detalha as mudanças visuais. Faça a revisão interna de Isabel apenas sobre o Reel. Rafael envia o roteiro ao MCP do HeyGen em um único pedido de vídeo de avatar. Diego programa o motion e prepara o plano das cenas enquanto o clipe é processado e monta a base na duração real do vídeo. Tiago finaliza com a fala incorporada ao clipe.
- **Animação · Henrique, Clara e Bruno.** Henrique escreve as falas e define as cenas a partir da notícia. Faça a revisão interna de Isabel apenas sobre a animação. Clara gera a tomada própria da animação com `heygen_voz.py`; Bruno compõe as cenas e finaliza quando receber essa narração. A animação já pode terminar enquanto o Reel aguarda o avatar.
- **Carrossel · Juliana e Larissa.** Juliana escreve capa, cartelas e legenda. Larissa desenvolve a arte e exporta as cartelas após a revisão do carrossel, sem aguardar voz ou edição de vídeo.
- **Post estático · Marina.** Marina escreve a manchete e a legenda, compõe a arte e exporta o post após a revisão da própria peça.

A revisão de texto e áudio é interna. Prossiga da escrita à geração e à edição sem pedir aprovação ao aluno. Cada vídeo procura e valida sua trilha conforme [a configuração](references/configuracao.md) e segue com a voz se não houver faixa utilizável. Vera revisa cada peça assim que o render dela termina. O orquestrador mostra o arquivo ao usuário na mesma conversa assim que a peça passa pela revisão. Continue o trabalho das outras frentes depois de cada entrega.

Use vagas de subagentes para manter frentes independentes simultaneamente. Se as vagas forem limitadas, o orquestrador assume uma frente e distribui as demais; enquanto um serviço processa um job, avance trabalho disponível nas outras. Registre a limitação do ambiente se a concorrência não for possível. Não execute todo um formato antes de iniciar os outros como estratégia padrão.

## Notícias e conteúdo

- Notícia real de até sete dias, data/veículo/link e conferência em duas fontes. Se só houver notícia de até quatorze dias, declarar no resumo e não chamar de “esta semana”. Se não houver notícia verificável, explicar e propor conteúdo autoral sem simular atualidade.
- Não inventar repercussão, endosso, credencial, depoimento ou resultado. Distinguir fato, leitura pessoal e oferta.
- Quem publica fala em primeira pessoa. Gancho específico e curto, frase inicial sem cumprimento. Nada de promessas garantidas ou urgência falsa.
- Feche fala e legenda com “Quer resolver esse problema? Me chama no Direct.” Adapte a pergunta ao problema mostrado. Use “Me chama no Direct” no encerramento dos dois vídeos, na cartela final e no estático. Mantenha “Me chama no Direct” nas peças que usam os scripts deste pacote.
- **Reels editado:** use o clipe HeyGen como apresentador. Componha o painel e o fechamento em Remotion com gráficos, ícones e tipografia animados em código. Abra com o gancho no primeiro quadro, sincronize as legendas e faça uma mudança visual relevante em até dois segundos. O roteiro e o render do painel aceitam apenas visuais desenhados em código. Confira início, meio e fim do MP4 final. Reutilize o job quando a fala for a mesma.
- Inclua os retratos gerados na capa, na cartela final e no estático. Escolha imagens e ícones das cartelas intermediárias conforme o conteúdo de cada uma.

## Verificação e entrega

- Conferir fatos, CTA, expansão de siglas, texto/voz, durações e margens. Abra as sete imagens e o estático. Verifique o rosto e o convite. Teste o início, as trocas visuais e o encerramento dos vídeos antes de render completo.
- Na animação, conferir movimento dentro dos planos e transições nos trechos de abertura, desenvolvimento e fechamento. O render usa apenas componentes gráficos e tipografia feitos em código.
- Não confundir aceite de job com arquivo pronto. Não dizer que houve audição humana se só houve transcrição automática.
- **Entrega durante a execução:** rode `scripts/entrega.py <pasta> --peca reels|animacao|carrossel|estatico` assim que uma peça estiver revisada. Use o recurso de mensagem de progresso da plataforma para mostrar o arquivo ou link clicável naquele momento. Para o carrossel, mostre o link da galeria com as sete cartelas. Cada peça tem seu próprio momento de entrega.
- **No encerramento:** rode `scripts/entrega.py <pasta>` para consolidar `entrega/LINKS.md`. Registre fontes, legendas e pendências em `entrega/RESUMO.md`. Mostre os links das peças ainda não apresentadas e informe bloqueios concretos em uma frase curta. Se a plataforma só exibir arquivos na resposta final, mande o link de cada peça por mensagem de progresso assim que ficar disponível e reúna os arquivos na resposta final.
- Publicação e envio a terceiros só quando o usuário pedir. Este fluxo cria os arquivos.
