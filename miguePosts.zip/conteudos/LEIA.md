Cada peça ganha uma pasta aqui: AAAA-MM-DD_Tema_Angulo/.
