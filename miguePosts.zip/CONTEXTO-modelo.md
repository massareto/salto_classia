# CONTEXTO: <seu nome>, <seu serviço>

> Modelo para quem vende um serviço online (coach, mentor, consultor, professor, especialista). Copie este arquivo como `CONTEXTO.md` e preencha.
> O que você ainda não decidiu, marque **[a confirmar]**: a equipe não usa em público.

---

## Quem é o coach

- **Nome:** <seu nome ou nome da marca>
- **Nicho:** <é nele que a equipe procura as notícias da semana; ex.: produtividade, carreira, emagrecimento, finanças pessoais, liderança, relacionamentos>
- **Ramo de atuação:** <o que você faz, para quem>
- **Em uma frase:** ajudo <quem> a <resultado que busca> sem <o que a pessoa quer evitar>.
- **Credenciais que podem ser citadas:** <formação, certificações, carreira>. Só o que estiver aqui aparece nas peças.
- **Frase de autoridade (primeira pessoa):** <ex.: Eu estudo produtividade há mais de dez anos e já ajudei muitos donos de negócio a resolver esses problemas.> Só fatos seus: a equipe usa esta frase tal como está.
- **O que você NÃO é:** <ex.: psicólogo, nutricionista, médico, consultor financeiro registrado>. A equipe nunca fala como se fosse.

---

## Oferta

- **O que vende:** <mentoria, coaching individual, programa em grupo, curso>
- **Formato:** <individual ou grupo, online ou presencial, n.º de encontros>
- **Preço:** <valor> (só entra no conteúdo público se você autorizar)
- **Porta de entrada:** <ex.: conversa de diagnóstico de 30 minutos, gratuita>
- **Resultado que a oferta busca (sem garantia):** <o que muda para o cliente>

---

## Cliente ideal

- **Quem é:** <idade, profissão, momento de vida>
- **Dor principal:** <a dor dita do jeito do cliente>
- **Tensões:** <o que pesa no dia a dia>
- **Objeções comuns:** <"não tenho tempo", "já tentei", "é caro", "coaching é papo motivacional">
- **Desejo profundo:** <o que ele quer de verdade>

---

## Tom de voz

- **Língua:** português do Brasil, tratando o leitor por "você".
- **Registro:** <ex.: direto e caloroso; técnico e calmo; bem-humorado>
- **Sem travessões** nos textos.

### Palavras que usa
- <palavra ou expressão>

### Palavras que nunca usa
- "garantido", "em 7 dias", qualquer promessa de resultado
- "corra", "últimas vagas", "só hoje", "não perca" (urgência ou escassez falsa)
- <outras>

---

## Marca

### Cores

| Papel | Nome | HEX | Uso |
|---|---|---|---|
| `fundo` | <nome> | `#111114` | fundo das cartelas e do painel do Reels |
| `cartao` | <nome> | `#1C1C22` | card do avatar no Reels |
| `texto` | <nome> | `#F5F4EF` | texto principal |
| `marca-texto` | <nome> | `#F5F4EF` | barra do destaque |
| `texto-marca-texto` | <nome> | `#111114` | letra sobre a barra do destaque |
| `acento` | <nome> | `#2FBF71` | um elemento por cartela ou cena (número-chave, botão) |

> Confira o contraste: `texto` sobre `fundo` e `texto-marca-texto` sobre `marca-texto` precisam ser bem legíveis.

- **Fonte de título:** Poppins (ou Montserrat, ou Inter)
- **Selo:** `marca/selo.svg` (seu logo ou rosto em ícone quadrado; opcional)
- **Estilo das imagens:** `<ex.: fotografia realista e editorial, luz natural suave, tons neutros, um detalhe na cor de acento>`. As imagens geradas por IA (cartelas, cenas do Reels, post estático) seguem isto.

### Canais e contatos

- **Instagram:** [@seuperfil](https://instagram.com/seuperfil)
- **Contato no carrossel e no estático:** Me chama no Direct
- **Chamada do Reels:** Quer resolver esse problema? Me chama no Direct.
- **Chamada da animação:** Quer resolver esse problema? Me chama no Direct.

### Voz HeyGen e avatar opcional

- **Usar avatar no Reels:** sim
  A equipe resolve automaticamente um avatar privado de vídeo pronto ou, se não houver, um avatar privado de foto pronto. Marque não para dispensar o avatar e o Reels.
- **Provedor de voz:** heygen
- **Avatar HeyGen (avatar_id):** `<identificador resolvido pela equipe no HeyGen>`
- **Formato do avatar:** 9:16 ou 16:9, conforme o avatar disponível
- **Voz HeyGen (voice_id):** `<identificador da voz atual do avatar ou da voz autorizada>`
- **Interpretação:** expressiva, conversada, com pausas naturais

### Referências visuais

- **Gerador de imagens:** HeyGen Image ou Look Remix com a referência do apresentador; geração nativa como alternativa
- **Foto de referência:** <caminho privado da imagem do look HeyGen ou da foto autorizada já fornecida>
- **Avaliação da foto:** <nitidez, luz, resolução, rosto e obstruções; pedir melhor foto se necessário>
- **Retrato gerado:** <caminho do novo retrato com identidade conferida e proveniência>

### Animação ilustrativa

- Escolher imagens, objetos, ícones e mudanças de quadro a partir do roteiro e do nicho da pauta. Mudar algo relevante na tela em até dois segundos.
- Não exige foto nem ficha de personagem.
- A equipe escolhe para cada vídeo uma faixa instrumental dinâmica do HeyGen com duração suficiente e batida que acompanhe o corte. A voz segue mesmo sem trilha.
- Nenhuma sigla em fala ou texto público: escrever inteligência artificial por extenso.
