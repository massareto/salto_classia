# Trilhas dinâmicas no HeyGen

Use esta seleção do catálogo como ponto de partida. Busque pelo identificador na conta conectada e confira a adequação à história e ao público. Os quatro arquivos da lista já têm áudio no primeiro segundo.

| Faixa no catálogo | Identificador | Duração | Onde experimentar |
|---|---|---:|---|
| Astral Generated Music: 4208b279 | `4208b279cf3340fb8bfb53974c144524` | 56 s | Groove pop moderno com percussão marcada. Ação cotidiana, comércio, atendimento. |
| Astral Generated Music: 4cd13a71 | `4cd13a718efb4b9ebb2419bcbb4c8653` | 60 s | Eletrônica enérgica. Tecnologia, demonstrações e mudanças rápidas. |
| Astral Generated Music: 1c77b065 | `1c77b065805e4ea695855208f6e32321` | 69 s | Batida leve de hip-hop com clima documental. Histórias de bastidor, descoberta ou mudança de rotina. |
| Astral Generated Music: c305ca1d | `c305ca1d33a542c295f231922bc1a5e4` | 55 s | Beat enérgico de perfil comercial. Pequenos negócios, vendas e decisões de operação. |

Escolha a trilha de cada vídeo junto com a direção de arte. Teste a faixa sob a voz, com entrada rápida, pulso marcado e acentos úteis para os cortes. Busque outra opção com termos do nicho e do gênero se a lista não combinar. Descarte lounge, trilhas sem dinâmica, vocais que disputem a narração e introduções longas. Alinhe alguns acentos às mudanças da tela, abaixe a faixa sob a fala e finalize o áudio com o CTA claro. Obtenha um link de download atualizado no catálogo. Siga [configuração](configuracao.md) para salvar e conferir a duração.
