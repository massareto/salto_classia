# Imagens e identidade do apresentador

## Busca e geração

1. Consulte os looks privados prontos do apresentador autorizado no HeyGen. Use o arquivo de referência ou a prévia do look em resolução suficiente. Veja se o rosto está nítido, com olhos visíveis, luz adequada e espaço para recorte. Use a mesma pessoa nas duas frentes. O retrato pode sair de um look de foto mesmo quando ele não for usado no Reel.
2. Se o HeyGen não expuser uma referência utilizável, use uma foto autorizada já no projeto ou nos anexos. Peça uma foto somente quando as duas fontes falharem. Guarde os arquivos e identificadores do look na área privada do projeto.
3. Gere novas fotografias com HeyGen. Use Look Remix quando houver uma referência de composição adequada ao nicho. Envie o retrato como referência de identidade e a referência de composição em seu campo próprio. Para editar a referência com instruções de cena, use HeyGen Image. Importe a foto por um asset autorizado se o conector exigir um asset ID. Se a geração HeyGen estiver indisponível ou não aceitar a referência, use o gerador nativo da plataforma com a mesma foto como entrada.
4. Gere retratos próprios para a capa, o fechamento do carrossel e o estático. Use ambiente, figurino, objetos, expressão e pose ligados à pauta do dia. Preserve idade, rosto, tom de pele, cabelo e proporções. Gere em 4:5 quando possível ou enquadre para recorte em 4:5. Deixe área para a tipografia e enquadre o rosto de modo que continue visível na arte final.
5. Compare o resultado com a referência. Descarte desvio de identidade, recorte ruim e deformações. Se faltar referência utilizável ou geração com referência, registre o bloqueio e prossiga nas outras frentes. Nunca publique a foto original nem apresente a imagem gerada como registro de uma ocasião real.

## Guardar a proveniência

Ao lado de cada PNG, grave o JSON com o mesmo nome e a extensão `.proveniencia.json`:

```json
{
  "uso": "retrato_apresentador",
  "provedor": "heygen",
  "gerada": true,
  "generation_id": "<identificador da geração ou do artefato>",
  "referencia_origem": "heygen",
  "referencia": "<nome do arquivo privado ou do look>",
  "referencia_avaliada": "<nitidez, luz, resolução e obstruções>",
  "revisao_identidade": "aprovada",
  "sha256": "<hash real da imagem usada>"
}
```

Use `referencia_origem: "usuario"` quando usar uma foto autorizada já fornecida. Para geração nativa, use `provedor: "chatgpt"` ou `"nativo"` e registre a ferramenta. Se gerar no HeyGen a partir de uma foto fornecida porque a referência do look não está disponível, registre a razão em `fallback_motivo`. Use `imagem` nas props de cada peça. Os renders do carrossel e do estático exigem proveniência revisada nos retratos. As imagens ilustrativas das demais cartelas mantêm a proveniência de geração; os ícones desenhados pelo render podem ser usados nas cartelas intermediárias.
