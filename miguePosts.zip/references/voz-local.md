# Fluxo descontinuado

O miguePosts usa narração HeyGen. Não instalar Piper nem usar fallback ElevenLabs. Consulte [voz-heygen.md](voz-heygen.md).
