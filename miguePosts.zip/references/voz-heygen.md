# Narração expressiva pelo HeyGen

## Resolver o avatar antes de produzir

1. Respeite a dispensa explícita do avatar. Para o Reel, consulte os looks privados da conta conectada com `list_avatar_looks` (ou pelos grupos privados e seus looks) e percorra a paginação. Inclua apenas looks prontos, com identidade autorizada e um motor de vídeo utilizável. Deixe de fora o catálogo público, looks em treinamento e jobs com falha.
2. Classifique os looks pela origem que o catálogo confirma. **Escolha primeiro um avatar de vídeo pronto**, criado a partir de vídeo, como um Digital Twin gravado. **Se não houver nenhum pronto de vídeo, escolha um avatar de foto pronto.** Não trate a miniatura ou a orientação do look como prova de origem. Consulte os detalhes do look ou do grupo se o tipo estiver em dúvida.
3. Se o aluno pedir explicitamente a troca para um look específico em uma revisão, use o look solicitado após conferir se está pronto. Na seleção automática, use o look salvo no contexto somente se pertencer ao tipo prioritário. Em seguida, prefira o padrão da conta ou um look vertical. Empate restante sai pelo ID do look em ordem estável. Selecione automaticamente, inclusive se houver vários looks. Use o ID do look, em vez do ID do grupo. Para o clipe de foto, use um motor que o catálogo indique como compatível e siga com a edição do MP4.
4. Se a consulta tiver sucesso e não encontrar nenhum avatar utilizável, remova o identificador antigo da cópia de trabalho do contexto, sem alterar o arquivo original. Grave `entrega/reels_omitido.json` com `{"status":"omitido","motivo":"sem_avatar"}`. Pule a geração e a edição do Reel. Entregue as demais peças viáveis e diga que a conta está sem avatar disponível para gerar o Reel. Diferencie essa situação de uma falha de acesso ou do plano.
5. Registre `Avatar HeyGen (avatar_id)`, `Formato do avatar` e `Voz HeyGen (voice_id)` no contexto privado de trabalho. Confira a voz padrão do look ou grupo. Se ela estiver indisponível, use uma voz HeyGen compatível já configurada ou autorizada. Para a narração da animação, use a voz HeyGen configurada ou selecione uma voz disponível do catálogo público no idioma do negócio. Preserve o fechamento gráfico da animação.

## Reel: gerar o vídeo falado pelo MCP

1. Após a revisão interna, execute `python3 scripts/heygen_avatar.py preparar <pasta>` com `MARKETING_COACHES_PROJETO=<projeto>` para montar os argumentos do MCP. Use o texto de `trabalho/fala.txt`, o look autorizado e a voz resolvida ou a padrão do look.
2. Chame `create_video_from_avatar` no MCP do HeyGen com `avatarId`, `script` e os parâmetros do pedido. O clipe já vem com a fala sincronizada. Use texto como entrada única da fala e solicite o SRT. Escolha MP4 quando o look não suportar WebM com recorte. Configure a interpretação separadamente se a voz oferecer esse controle.
3. Guarde o `video_id` e acompanhe o mesmo job com `get_video`. Enquanto processa, prepare os gráficos e as cenas em motion do Reel e avance as outras frentes. Consulte jobs em andamento antes de repetir uma geração.
4. Quando concluir, baixe o vídeo original de `video_url` e o SRT de `subtitle_url`, se disponível. Importe com `python3 scripts/heygen_avatar.py importar <pasta> <vídeo> --srt <legenda>`. Omita `--srt` se o job não trouxer legenda. A edição usa a voz do próprio clipe e deriva os tempos dela se o SRT não vier. Confira sincronismo labial, pronúncia, volume e palavras finais.

## Animação: gerar só a narração pelo MCP

1. Rode `heygen_voz.py preparar <pasta>` e envie o pedido de `trabalho/heygen-pedido-voz.json` à ferramenta de síntese de fala no MCP do HeyGen. Peça tempos por caractere. Consulte `trabalho/direcao-voz.md` para a interpretação.
2. Baixe o áudio e o JSON retornados. Importe com `heygen_voz.py importar <pasta> <resultado.json> <audio>`. Renderize com as falas segmentadas em `trabalho/animacao/voz/`. Use o fechamento gráfico narrado.
3. Use a própria narração no fechamento em motion e mantenha o vídeo de avatar na frente do Reel.

O fluxo padrão tem um job de vídeo falado do Reel e um job de narração da animação. As duas frentes avançam independentemente. Registre uma eventual falha de conexão e prossiga com as peças viáveis.
