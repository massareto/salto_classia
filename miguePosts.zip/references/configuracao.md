# Configuração independente do miguePosts

Este ZIP contém instruções, equipe, código e modelos. Não depende de arquivo de ensaio, conta do autor, avatar pessoal ou contexto predefinido. Instalar a pasta como skill e copiar `CONTEXTO-modelo.md` para o projeto como `CONTEXTO.md`. Definir `MARKETING_COACHES_PROJETO` nas chamadas de scripts.

Para render local, use Python 3.12 ou superior (validado com 3.14), Node.js com npm e ffmpeg/ffprobe no PATH. Dentro da pasta da habilidade:

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
ffmpeg -version
ffprobe -version
python scripts/aquecer.py
```

Aquecimento instala os pacotes Remotion conforme o lockfile e prepara o navegador. Use o Python do ambiente virtual nas próximas chamadas.

Primeiro verificar conectores nativos disponíveis. Voz e avatar usam HeyGen. Para retratos do apresentador, obtenha a referência no HeyGen e gere com HeyGen Image ou Look Remix. Use um gerador nativo com referência como alternativa. Ler `voz-heygen.md` e `imagens-identidade.md`.

Se falta HeyGen, orientar a conexão disponível na plataforma. Só usar navegador se a integração não resolver; pelo controle de navegador autorizado, abrir a área de conta/avatares e guiar o usuário. O helper `configurar.py abrir heygen` é para execução manual pelo usuário. Nunca pedir chave no chat.

Para uma CLI autenticada que realmente necessite de chave: variável `HEYGEN_API_KEY`, gerenciador de segredos ou `~/.config/heygen/api_key` com permissão 600. O usuário pode rodar `python3 scripts/configurar.py guardar-chave heygen` no terminal interativo. Não gerar ou revogar chave automaticamente. `diagnostico` informa presença, nunca o valor; ausência de chave local não implica ausência de conector autenticado.

Resolver avatar e voz pelo procedimento em [voz-heygen.md](voz-heygen.md). A equipe registra o avatar resolvido automaticamente na ordem vídeo, depois foto. Com avatar dispensado ou indisponível, a animação segue com narração HeyGen e final gráfico. Sem voz HeyGen, entregar os formatos visuais viáveis e registrar os vídeos pendentes no resumo.

## Buscar e baixar a trilha de cada vídeo

Comece pela [seleção de trilhas dinâmicas](trilhas-dinamicas.md). Busque uma faixa diferente quando a pauta ou o andamento da outra peça pedirem.

O HeyGen gera o clipe falado do Reel e a narração da animação pelo MCP. A [busca de música do HeyGen](https://developers.heygen.com/background-music) consulta faixas prontas e funciona sem conexão com o ElevenLabs.

1. Para o Reel, confira com `ffprobe` a duração do clipe falado em `entrega/video/avatar.mp4` ou `avatar.webm`. Para a animação, rodar `python scripts/animacao.py duracao "<pasta>"` após importar a voz e os tempos. O último valor que o comando imprime é a duração da timeline em segundos.
2. Buscar no conector HeyGen (`search_audio_sounds`, tipo `music`) ou na [API de catálogo](https://developers.heygen.com/background-music). Descrever o nicho, o tom e o ritmo. Examinar o campo `duration` em segundos e escolher uma faixa instrumental cuja duração seja maior ou igual à do vídeo. Buscar outra faixa para a segunda peça se ela tiver um ritmo diferente.
3. Baixar a faixa escolhida durante a produção e salvar em `trabalho/musica_reels.wav` ou `trabalho/musica_animacao.wav`. Conferir a duração real com `ffprobe`. Registrar título e origem no resumo. A edição corta o excedente e mantém a música abaixo da voz.
4. Se a faixa for curta ou o link tiver expirado, buscar outra opção ou renovar o link no catálogo. Se o conector não expuser a busca, usar a API autenticada do HeyGen. Se nenhuma faixa servir ou o catálogo estiver indisponível, remova a faixa inválida da pasta de trabalho da peça, renderize com a voz HeyGen e registre que a peça saiu sem trilha.
