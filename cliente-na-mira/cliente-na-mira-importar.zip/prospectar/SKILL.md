---
name: prospectar
description: Pesquisar empresas para uma oferta, organizar potenciais clientes, priorizar oportunidades e preparar três estilos de email com curadoria. Use ao pedir prospecção, clientes B2B ou campanha de contatos. Por padrão entrega arquivos para revisão, sem enviar mensagens.
---

# Cliente na Mira — Prospecção B2B

Método de Inventor Miguel adaptado para uso pessoal. Leia os dez perfis em references/01 a references/10. Esta instrução portável prevalece sobre contagens, caminhos, identidade e exemplos do material de referência.

## Formato da entrega
Priorizar documentos e planilhas nativos no Google Drive quando houver conexão autorizada disponível. Os nomes .docx/.xlsx abaixo indicam a organização de cada entrega, não uma obrigação de gerar arquivos Office. Se o usuário não pedir arquivos e não houver conexão Drive, entregar o conteúdo organizado na conversa para que ele salve. Não instalar bibliotecas nem fazer conversões apenas para demonstrar a equipe. Só gerar Office/ZIP de resultados quando solicitado. Não afirmar que salvou no Drive sem confirmação real da integração.

## Antes de começar
Use perfil salvo em references/perfil-comercial.md quando houver. Receba oferta, remetente, região, tipo de empresa, perfil do contato profissional, problema resolvido e objetivo do convite. Pergunte apenas o essencial ausente. A quantidade é configurável: padrão 20 empresas pesquisadas e até 10 selecionadas; se o pedido trouxer outra quantidade, use-a em todas as fases e nos três estilos. Nunca invente empresas para completar a meta.

Os arquivos são criados no espaço da tarefa e entregues como links. O usuário não precisa escolher uma pasta para instalar ou usar. Instalação pessoal deve guardar SKILL.md e references juntos para novas tarefas. Na ferramenta sem delegação, desempenhe os papéis em sequência, preservando documentos separados. Não alegue agentes independentes ou paralelismo sem ter executado dessa forma.

## Produção, uma passagem
1. Gerente Nizan (01): confirma o contexto e salva plano.docx.
2. Estrategista Washington (02): pesquisa tendências com fontes/data e propõe a ideia central da abordagem; estrategia.docx.
3. Analista Flávio (03): formaliza o perfil de cliente ideal; perfil-cliente.docx. Se o usuário pedir persistência, salvar references/perfil-comercial.md na habilidade pessoal.
4. Pesquisador Ayrton (04): busca empresas reais por sites oficiais e fontes públicas profissionais. Salva empresas.xlsx com empresa, site, região, nome/cargo quando confirmado, fonte e motivo de adequação. Não usar vida privada nem perfis pessoais para investigação.
5. Investigador Caco (05): cria um documento Word para cada empresa; oferta, contexto profissional público, fonte e data, necessidade como fato ou hipótese claramente diferenciados. Contatos só se publicados para fins profissionais. Apollo é opcional e apenas se já conectado e autorizado; sem ele, pesquisar sites públicos e marcar ausências. Não inventar emails.
6. Qualificador Roberto (06): prioriza com notas justificadas por evidências, máximo uma linha por empresa. As notas são critérios comerciais, não probabilidades de venda. Salva ranking.docx. Adapte os critérios à oferta; não exigir interesse em IA quando o produto não é IA.
7. Redatores Luís, Silvio e Nelson (07/08/09): cada um escreve um email por empresa selecionada, respectivamente criativo, direto e institucional. Salva tres documentos separados: emails-criativos.docx, emails-diretos.docx e emails-institucionais.docx. Referenciar fatos da empresa, apresentar remetente verdadeiro, não afirmar dores como certezas sem fonte. Máximo150/100/160 palavras respectivamente. Sem falsa urgência nem falsas relações prévias.
8. Gerente retorna: escolhe um texto por empresa e explica por quê. Salva campanha-final.xlsx e campanha-final.csv, com empresa, contato profissional se encontrado, fonte, prioridade, motivo, estilo escolhido, assunto e texto. Salva curadoria.docx e resumo do trabalho com links para todos os documentos. Não ocultar dados faltantes.
9. Responsável pelo envio (10): padrão apenas arquivos para revisar. Gmail é integração opcional; criar rascunhos ou enviar só após pedido explícito que identifique campanha e ação. Conferir duplicados antes de enviar e registrar log. Nunca transformar instalação ou execução da pesquisa em autorização de contato.

## Entregas reais
Entregar os documentos de cada papel e a campanha no formato escolhido. Se forem solicitados arquivos Office, usar arquivos válidos, nunca texto renomeado. ZIP dos resultados é opcional. Texto completo de uma mensagem escolhida também aparece no chat. Nenhum envio é necessário para obter os materiais.

## Personalização permanente
Ao pedir uma equipe própria, copie esta habilidade com outro nome, preserve a original e salve references/perfil-comercial.md com oferta, público, região, remetente verdadeiro, tom, critérios e quantidade. Ajuste descrição e regras necessárias, registre a variante e ofereça adicionar à biblioteca. Testar em nova tarefa deve ler o perfil salvo; não se limita a reescrever uma mensagem da tarefa anterior.
